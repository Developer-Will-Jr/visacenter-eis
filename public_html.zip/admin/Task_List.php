<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] !== 2){
  header("location: ../index.php");
  exit;
}

// Include config file
require_once "../db/DBConn.php";

?>

    <title>Tasks</title>
    <?php $currentPage = 'Tasks'; ?>
    <?php $currentSub = ''; ?>
    <?php include '../plugins.php'; ?>
	<?php require_once('AdminNavbar.php'); ?>


<div class="container rounded bg-white" style="padding: 0.5em;">
<div class="col-lg-13">
	<div class="card card-outline card-success">
		<div class="card-header">
			<?php if ($_SESSION['access'] != 1) : ?>
				<div class="card-tools">
					<a class="btn btn-primary bg-gradient-primary btn-sm float-right" href="./New_Task.php"><i class="fa fa-plus"></i> Start New Project</a>
				</div>
			<?php endif; ?>
			<h3 class="text-center"><b>PROJECTS</b></h3>
		</div>
		
		<div class="card-body">
			<table class="table table-hover" id="list">
				<thead>
					<tr class="text-center">
						<th>Project Name</th>
						<th>Date Started</th>
						<th>Due Date</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$stat = array("Pending", "Started", "On-Progress", "On-Hold", "Over Due", "Done");
					$where = "";
					if ($_SESSION['access'] == 2) {
						$where = " where manager_id = '{$_SESSION['id']}' ";
					} elseif ($_SESSION['access'] == 1) {
						$where = " where concat('[',REPLACE(user_ids,',','],['),']') LIKE '%[{$_SESSION['id']}]%' ";
					}
					$qry = $conn->query("SELECT * FROM project_list $where order by start_date desc");
					while ($row = $qry->fetch_assoc()) :
						$trans = get_html_translation_table(HTML_ENTITIES, ENT_QUOTES);
						unset($trans["\""], $trans["<"], $trans[">"], $trans["<h2"]);
						$desc = strtr(html_entity_decode($row['description']), $trans);
						$desc = str_replace(array("<li>", "</li>"), array("", ", "), $desc);

						$tprog = $conn->query("SELECT * FROM task_list where project_id = {$row['id']}")->num_rows;
						$cprog = $conn->query("SELECT * FROM task_list where project_id = {$row['id']} and status = 3")->num_rows;
						$prog = $tprog > 0 ? ($cprog / $tprog) * 100 : 0;
						$prog = $prog > 0 ?  number_format($prog, 2) : $prog;
						$prod = $conn->query("SELECT * FROM user_productivity where project_id = {$row['id']}")->num_rows;
						if ($row['status'] == 0 && strtotime(date('Y-m-d')) >= strtotime($row['start_date'])) :
							if ($prod  > 0  || $cprog > 0)
								$row['status'] = 2;
							else
								$row['status'] = 1;
						elseif ($row['status'] == 0 && strtotime(date('Y-m-d')) > strtotime($row['end_date'])) :
							$row['status'] = 4;
						endif;
					?>
						<tr class="text-center">
							<td class="text-left">
								<h6><b><?php echo ucwords($row['name']) ?></b></h6>
								<span class="truncate"><?php echo strip_tags($desc) ?></span>
							</td>
							<td><b><?php echo date("M d, Y", strtotime($row['start_date'])) ?></b></td>
							<td><b><?php echo date("M d, Y", strtotime($row['end_date'])) ?></b></td>
							<td class="project_progress text-center">
                                                        <div class="progress progress-sm">
                                                            <div class="progress-bar bg-green" role="progressbar" aria-valuenow="57" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $prog ?>%">
                                                            </div>
                                                        </div>
                                                        <b>
                                                            <?php
                                                                echo $prog
                                                            ?>% Complete
                                                        </b>
                                                    </td>
							<td class="text-center">
									<a class="btn btn-outline-primary"  title="View Project Details" href="./View_Task.php?id=<?php echo $row['id'] ?>" data-id="<?php echo $row['id'] ?>"><i class="fas fa-eye"></i></a>

									<?php if ($_SESSION['access'] != 1) : ?>
										<a class="btn btn-outline-success"  title="Edit Project" href="./Edit_Task.php?id=<?php echo $row['id'] ?>"><i class="fas fa-pencil-alt"></i></a>

										<a class="btn btn-outline-danger delete_project"  title="Delete Project" href="javascript:void(0)" data-id="<?php echo $row['id'] ?>"><i class="fas fa-trash-alt"></i></a>
									<?php endif; ?>
							</td>
						</tr>
					<?php endwhile; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
</div>

<style>
	table p {
		margin: unset !important;
	}

	table td {
		vertical-align: middle !important
	}
</style>
<script>
	$(document).ready(function() {
		$('#list').dataTable({"order": [],
              "aoColumns": [
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": false }
          ]
            })

		$('.delete_project').click(function() {
			_conf("Are you sure to delete this project?", "delete_project", [$(this).attr('data-id')])
		})
	})

	function delete_project($id) {
		start_load()
		$.ajax({
			url: '../ajax.php?action=delete_project',
			method: 'POST',
			data: {
				id: $id
			},
			success: function(resp) {
				if (resp == 1) {
					alert_toast("Data successfully deleted", 'success')
					setTimeout(function() {
						location.reload()
					}, 1500)

				}
			}
		})
	}
</script>

<?php include '../footer.php'; ?>