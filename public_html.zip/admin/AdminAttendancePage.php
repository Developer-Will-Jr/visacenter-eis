<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] !== 2){
  header("location: ../index.php");
  exit;
}

// Include config file
require_once "../db/DBConn.php";

$sql = "SELECT * FROM user u INNER JOIN emp_attendance e ON u.UserID = e.emp_num WHERE u.Branch = '{$_SESSION["branch"]}' AND e.emp_num != '{$_SESSION["id"]}'";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Page</title>
    <?php $currentPage = 'Employee'; ?>
    <?php $currentSub = 'EmployeeSubMenu2'; ?>
    
    <?php include '../plugins.php'; ?>

</head>
<body>

    <?php require_once('AdminNavbar.php'); ?>
    <div class="container rounded bg-white" style="padding: 1em;">
    <div class="col-lg-13">
    <div class="card card-outline card-success">
		<div class="card-header">
			<h4 class="text-center">Employees Attendance</h4>
		</div>
    
    <div class="card-body">
            
    <?php if($result = mysqli_query($conn, $sql)){ ?>
        <table class="table table-hover text-center" id="empattendance">
                    <thead>
                    <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Date</th>
                        <th scope="col">Time IN</th>
                        <th scope="col">Time OUT</th>
                        <th scope="col">Location</th>
                    </tr>
                    </thead>        
                    <tbody>
                        
              <?php while($row = mysqli_fetch_array($result)){ ?>
                    <tr>
                        <td><?php echo $row['last_name'] . ", " . $row['first_name'] . " " . $row['middle_name'] ?></td>
                        <td><?php echo $row['curr_date'] ?></td>
                        <td><?php echo $row['time_in'] ?></td>
                        <td><?php echo $row['time_out'] ?></td>
                        <td><?php echo $row['Location'] ?></td>
                    </tr>
            
                    <?php }} ?>
                    </tbody>
                </table>
    
          </div>
    </div>
    </div>
            </div>

            <?php include '../footer.php'; ?>
        <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });

        $(document).ready(function() {
		        $('#empattendance').dataTable({"order": [],
              "aoColumns": [
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": false }
          ]
            })
          })
    </script>
</body>
</html>