<?php
// Initialize the session
session_start();

// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] !== 2){
  header("location: ../index.php");
  exit;
}

// Include config file
require_once "../db/DBConn.php";

$usedV = "";
$usedS = "";

$userid = $_SESSION["id"];
// For Table
$sql = "SELECT *, DATE_FORMAT(StartLeave, '%M %d, %Y') as StartL, DATE_FORMAT(EndLeave, '%M %d, %Y') as EndL FROM `leavelist` WHERE UserID = $userid";
$result = $conn->query($sql);

$leaveVal = "";
if(isset($_GET['v']) && !empty($_GET['v'])){
  $leaveVal = base64_decode($_GET['v']);
} elseif(isset($_GET['e']) && !empty($_GET['e'])){
  $leaveVal = base64_decode($_GET['e']);
} elseif(isset($_GET['r']) && !empty($_GET['r'])){
   $leaveVal = base64_decode($_GET['r']);
}

$sql2 = "SELECT SUM((DATEDIFF(EndLeave, StartLeave) + 1)) as totaldays FROM `leavelist` WHERE UserID = '{$_SESSION['id']}' AND Status = 'Approved' AND Category = 'Vacation Leave'";
$result2 = $conn->query($sql2);
if($result2 = mysqli_query($conn, $sql2)){
  if(mysqli_num_rows($result2) > 0 ){
    while($row2 = mysqli_fetch_array($result2)){
      $usedV = $row2['totaldays'];
       }
  }
}

$sql3 = "SELECT SUM((DATEDIFF(EndLeave, StartLeave) + 1)) as totaldays FROM `leavelist` WHERE UserID = '{$_SESSION['id']}' AND Status = 'Approved' AND Category = 'Sick Leave'";
$result3 = $conn->query($sql3);
if($result3 = mysqli_query($conn, $sql3)){
  if(mysqli_num_rows($result3) > 0 ){
    while($row3 = mysqli_fetch_array($result3)){
      $usedS = $row3['totaldays'];
       }
  }
}

if ($usedV == ""){
  $usedV = "0";
}

if ($usedS == ""){
  $usedS = "0";
}
$date = date('Y-m-d');
$date = date('Y-m-d', strtotime($date . ' +1 day'));
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave/s</title>
    <?php $currentPage = 'MyLeave'; ?>
    <?php $currentSub = ""; ?>
    <?php include '../plugins.php'; ?>

</head>
<body>
<?php require_once('AdminNavbar.php'); ?>
    <div class="container rounded bg-white" style="padding: 0.5em;">
    
<div class="col-lg-13">
    <div class="card card-outline card-success">
		<div class="card-header">
			<h3 class="text-center"><b>MY LEAVE</b></h3>
          <h5 class="float-left">Leave Used: <?php echo $usedV ?> Vacation Leave, <?php echo $usedS ?> Sick Leave</h5>
				<div class="card-tools">
					<button class="btn btn-primary bg-gradient-primary btn-sm float-right" data-toggle="modal" data-target="#request"><i class="fa fa-plus"></i> Request Leave</button>
				</div>
		</div>
		
		<div class="card-body">
    <?php

if($result = mysqli_query($conn, $sql)){
    if(mysqli_num_rows($result) > 0){
echo  '<table class="table table-hover" id="myleave">';
echo '<thead>';
echo      '<tr class="text-center">';
echo        '<th scope="col">Category</th>';
echo        '<th scope="col">Date</th>';
echo        '<th scope="col">Details</th>';
echo        '<th scope="col">Status</th>';
echo        '<th scope="col">Action</th>';
echo '</thead>';
echo    '<tbody>';
echo      '</tr>';
while($row = mysqli_fetch_array($result)){
echo      '<tr class="text-center">';
echo        '<td>' . $row['Category'] . '</td>';
echo        '<td>' . $row['StartL'] . ' to ' . $row['EndL'] .'</td>';
echo        '<td style="max-width:25em">' . $row['Details'] . '</td>';
echo        '<td>' . $row['Status'] . '</td>';
echo        '<td class="text-center">';
echo            '<button id="' . base64_encode($row['LeaveID']) . '" class="btn btn-outline-primary" name="view1" title="View Details" onClick="leaveV(this.id)"><i class="fas fa-eye"></i></button>';
if ($row['Status'] == "Pending"){
echo            '<button id="' . base64_encode($row['LeaveID']) . '" class="btn btn-outline-success" data-toggle="modal" data-target="#edit" title="Edit" onClick="leaveE(this.id)"><i class="fas fa-pencil-alt"></i></button>';
echo            '<button id="' . base64_encode($row['LeaveID']) . '" class="btn btn-outline-danger" data-toggle="modal" data-target="#cancel" title="Remove" onClick="leaveR(this.id)"><i class="fa">&#xf00d;</i></button>';
}
echo        '</td>';
echo      '</tr>';
}
echo    '</tbody>';
echo  '</table>';
// Free result set
mysqli_free_result($result);
} else{
  echo  '<table class="table table-bordered">';
  echo        '<tr>';
  echo          '<td colspan="4">';
  echo          '<div class="alert alert-danger"><em>No records were found.</em></div>';
  echo            '</div>';
  echo          '</td>';
  echo '</table>';
}
} else{
echo "Oops! Something went wrong. Please try again later.";
}
?>
    </div>
  </div>
</div>
<style>
	table p {
		margin: unset !important;
	}

	table td {
		vertical-align: middle !important
	}
</style>
           <!-- Success -->
           <div class="modal fade" id="success" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Notice</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
          <h4><i class="fa fa-check" style="color:green"></i> Successfully Saved!</h4>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
      <!-- End -->

      <!-- Request -->
      <div class="modal fade bd-example-modal-lg" id="request" tabindex="-1" role="dialog" aria-labelledby="requestLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="requestLabel">Request Leave Form</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body text-center">
            <form method="post" action="../db/adminleave.php" enctype="multipart/form-data" onsubmit="return validateForm()">
                    <div class="form-group">
                        <label for="from">From:</label>
                        <input type="date" class="form-control text-center" name="from" id="firstdate" min="<?php echo $date ?>" onkeydown="return false" required>
                      </div>
                      <div class="form-group">
                        <label for="to">To:</label>
                        <input type="date" class="form-control text-center" id="seconddate" name="to" min="<?php echo $date ?>" onkeydown="return false" required>
                      </div>
            
                    <div class="form-row">
                        <div class="form-group">
                            <label for="reason">Reason:</label>
                            <textarea class="form-control" name="reason" rows="6" cols="100" placeholder="Please Be Specific..."></textarea>
                        </div>
                      </div>
                    
                      <div class="form-row">
                        <div class="form-group col-md-12">
                        <label for="inputState">Leave Type:</label>
                        <select name="type" class="form-control text-center" required>
                          <option selected="true" disabled="disabled" value="">Choose Category</option>
                          <?php if($usedV >= '7') { echo "<option disabled='disabled'>Vacation Leave (No Available Leave Left)</option>" ?><?php } else { echo "<option>Vacation Leave</option>" ?><?php } ?>
                          <?php if($usedS >= '7') { echo "<option disabled='disabled'>Sick Leave (No Available Leave Left)</option>" ?><?php } else { echo "<option>Sick Leave</option>" ?><?php } ?>
                        </select> 
                        <div class="form-group">
                          <label class="form-label">Attachment</label>
                          <input type="file" class="form-control text-center" name="attach">
                          <small class="text-left">Only accept .jpg .jpeg .png .pdf .doc or .docx file</small>
                        </div>
                        </div>
                      </div>
                      
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary" name="addleave">Submit Request</button>
            </div>
          </form>
          </div>
        </div>
      </div>
      <!-- End of Request -->


      <!-- My Personal Leave -->

      <!-- My Leave View -->
  <div class="modal fade" id="view" tabindex="-1" role="dialog" aria-labelledby="viewLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="viewLabel">Leave Full Details</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <table class="table table-bordered">
            <?php $resulta = mysqli_query($conn, "SELECT *, DATE_FORMAT(StartLeave, '%M %d, %Y') as StartL, DATE_FORMAT(EndLeave, '%M %d, %Y') as EndL FROM `leavelist` WHERE LeaveID = '$leaveVal'"); ?>
                <tbody>
                <?php while ($row2 = mysqli_fetch_array($resulta)) { ?>
                    <tr>
                      <th>Start of Leave</th>
                      <td><?php echo $row2['StartL'] ?></td>
                    </tr>
                    <tr>
                      <th>End of Leave</th>
                      <td><?php echo $row2['EndL'] ?></td>
                    </tr>
                    <tr>
                      <th>Type</th>
                      <td><?php echo $row2['Category'] ?></td>
                    </tr>
                    <tr>
                      <th>Reason of Leave</th>
                      <td><?php echo $row2['Details'] ?></td>
                    </tr>
                    <tr>
                      <th>Attachment</th>
                      <td><?php if ($row2['Attachment'] != ""){ ?>
                        <a style="color: blue; text-decoration: underline;" target="_blank" href="../Files/leave/<?php echo $row2['Attachment'] ?>"> <?php echo $row2['Attachment'] ?> </a><?php } ?></td>
                    </tr>
                    <tr>
                      <th>Note</th>
                      <td><?php echo $row2['Note'] ?></td>
                    </tr>
                    <tr>
                      <th>Status</th>
                      <td><?php echo $row2['Status'] ?></td>
                    </tr>
                    <tr>
                      <th>Approved/Declined By: </th>
                      <td><?php if($row2['Decided_by'] == "") {echo $row2['Decided_by'];} else {echo 'Still Pending';} ?></td>
                    </tr>
                  </tbody>
                  <?php }?>
              </table>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  <!-- End of My Leave View -->

  <!-- Edit My Leave -->

<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="editLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="editLabel">Edit Leave Request</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <?php $resulte = mysqli_query($conn, "SELECT * FROM `leavelist` WHERE LeaveID = '$leaveVal'"); ?>
        <form method="post" action="../db/adminleave.php" enctype="multipart/form-data" onsubmit="return validate2()">
            <?php while ($row1 = mysqli_fetch_array($resulte)) { ?>
                <div class="form-row text-center">
                  <div class="form-group col-md-12">
                    <label for="inputEmail4">Category</label>
                    <input type="text" class="form-control text-center" name="type" value="<?php echo $row1['Category'] ?>">
                  </div>
                  </div>
                  <div class="form-row text-center">
                  <div class="form-group col-md-12">
                    <label for="inputEmail4">Start</label>
                    <input type="date" class="form-control text-center" name="from" id="first" min="<?php echo $date ?>" onkeydown="return false" value="<?php echo $row1['StartLeave'] ?>" required>
                  </div>
                  </div>
                  <div class="form-row text-center">
                  <div class="form-group col-md-12">
                    <label for="inputEmail4">End</label>
                    <input type="date" class="form-control text-center" name="to" id="second" min="<?php echo $date ?>" onkeydown="return false" required value="<?php echo $row1['EndLeave'] ?>">
                  </div>
                  </div>
                  <div class="form-row text-center">
                  <div class="form-group col-md-12">
                    <label for="inputEmail4">Details</label>
                    <textarea class="form-control" name="reason" rows="6" cols="100"><?php echo $row1['Details'] ?></textarea>
                  </div>
                  </div>
                  <div class="form-group">
                          <label class="form-label">Current Attachment: </label>
                          <a style="color: blue; text-decoration: underline;" target="_blank" href="../Files/leave/<?php echo $row1['Attachment'] ?>"> <?php echo $row1['Attachment'] ?></a> <br>
                          <input type="hidden" name="currattach" value="<?php echo $row1['Attachment'] ?>">

                          <label class="form-label">Edit Attachment</label>
                          <input type="file" class="form-control text-center" name="newattach">
                          <small class="text-left">Only accept .jpg .jpeg .png .pdf .doc or .docx file</small>
                        </div>
            </div>
        <div class="modal-footer">
          <input type="number" name="leaveID" value="<?php echo $row1['LeaveID'] ?>" hidden>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-success" name="editleave">Save Changes</button>
        </div>
      </form>
      <?php } ?>
      </div>
    </div>
  </div>
  <!-- End of Edit Leave -->

  <!-- Cancel -->
  <div class="modal fade" id="cancel" tabindex="-1" role="dialog" aria-labelledby="declineLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="viewLabel">Cancel This Request?</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                    <table class="table table-bordered">
                    <?php $resulto = mysqli_query($conn, "SELECT * FROM `leavelist` WHERE LeaveID = '$leaveVal'"); ?>
                <tbody>
                <?php while ($row4 = mysqli_fetch_array($resulto)) { ?>
                    <tr>
                      <th>Start of Leave</th>
                      <td><?php echo $row4['StartLeave'] ?></td>
                    </tr>
                    <tr>
                      <th>End of Leave</th>
                      <td><?php echo $row4['EndLeave'] ?></td>
                    </tr>
                    <tr>
                      <th>Type</th>
                      <td><?php echo $row4['Category'] ?></td>
                    </tr>
                    <tr>
                      <th>Reason of Leave</th>
                      <td><?php echo $row4['Details'] ?></td>
                    </tr>
                    <tr>
                      <th>Status</th>
                      <td><?php echo $row4['Status'] ?></td>
                    </tr>
                    <tr>
                      <th>Approved/Declined By: </th>
                      <td><?php if($row4['Decided_by'] == "") {echo $row4['Decided_by'];} else {echo 'Still Pending';} ?></td>
                    </tr>
                  </tbody>
                  
              </table>
                </div>
                <div class="modal-footer">
                <form method="post" action="../db/adminleave.php">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <input type="text" name="leaveID" value="<?php echo $row4['LeaveID'] ?>" hidden>
                  <button type="submit" class="btn btn-danger" name="cancelleave">Cancel Request</button>
                </form>
                <?php }?>
                </div>
              </div>
            </div>
          </div>
          <!-- Cancel -->

          <?php include '../footer.php'; ?>
        <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
        $(function () {
        $('[data-toggle="tooltip"]').tooltip()
        })

        $(document).ready(function() {
		        $('#myleave').dataTable({"order": [],
              "aoColumns": [
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": false }
          ]
            })
          })
    </script>

    <?php if (isset($_SESSION["success"])){ ?>
      <script>$('#success').modal('show');</script>
    <?php unset($_SESSION['success']) ?>

    <?php } ?>

    <script type="text/javascript">

      //For Showing Modal
      var urlcheck = window.location.href;
      var url = new URL(urlcheck);
      if (url.searchParams.get("v")!=null){
          $('#view').modal('show');
      } else if (url.searchParams.get("e")!=null){
          $('#edit').modal('show');
      }else if (url.searchParams.get("r")!=null){
          $('#cancel').modal('show');
      }else if (url.searchParams.get("s")!=null){
          $('#success').modal('show');
      }

      // For Putting a Value in URL
      function leaveV(clicked_id)
      { 
        if (clicked_id != null){
          var val = clicked_id;
          window.location.href="?v=" + val;
        }
        
      };

      function leaveE(clicked_id)
      { 
        if (clicked_id != null){
          var val = clicked_id;
          window.location.href="?e=" + val;
        }
      };

      function leaveR(clicked_id)
      { 
        if (clicked_id != null){
          var val = clicked_id;
          window.location.href="?r=" + val;
        }
      };
    </script>
    <script>
      function validateForm() {
        var aDate = document.getElementById("firstdate").value;
        var bDate = document.getElementById("seconddate").value;

        if (aDate >= bDate) {
              alert("Please select a correct date");
              firstdate.focus();
              return false;
            }
      }

      function validate2() {
        var aDate = document.getElementById("first").value;
        var bDate = document.getElementById("second").value;

        if (aDate >= bDate) {
              alert("Please select a correct date");
              first.focus();
              return false;
            }
      }
    </script>
    
</body>
</html>