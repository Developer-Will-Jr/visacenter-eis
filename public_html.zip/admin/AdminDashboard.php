<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] !== 2){
  header("location: ../index.php");
  exit;
}

// Include config file
require_once "../db/DBConn.php";

$onsite = "No";
$time_in = "No";
$date = date('Y-m-d');
$done = "No";
$onleave = "NO";
$endleave = "";
$leavetype = "";
$absent = "No";

$mon = $tue = $wed = $thu = $fri = $sat = $sun = $scheduled = "";

$show_modal1 = false;
if ($_SESSION["password"] == "123"){
    $show_modal1 = true;
}

$sql = "SELECT COUNT(*) AS Total FROM user WHERE Branch = '{$_SESSION["branch"]}'";
$result = $conn->query($sql);


$sql2 = "SELECT COUNT(*) AS TotalLeave FROM leavelist INNER JOIN user ON leavelist.UserID = user.UserID WHERE leavelist.Status = 'Pending' AND user.Branch = '{$_SESSION["branch"]}'";
$result2 = $conn->query($sql2);

$sql4 = "SELECT COUNT(*) AS TotalProjects, SUM(project_list.status = 0) AS TotalProgress, SUM(project_list.status = 5) AS TotalDone FROM project_list INNER JOIN user ON project_list.manager_id = user.UserID WHERE user.Branch = '{$_SESSION["branch"]}'";
$result4 = $conn->query($sql4);

$sql5 = "SELECT * FROM branch_ipaddress WHERE IPAddress = '{$_SESSION["ip"]}'";
$result5 = $conn->query($sql5);
if($result5 = mysqli_query($conn, $sql5)){
    if(mysqli_num_rows($result5) > 0){
        $onsite = "Yes";
        while($row5 = mysqli_fetch_array($result5)){
        $loc = $row5['Branch'];
         }
    } else {
        $loc = "WFH";
    }
}


$sql6 = "SELECT * FROM `emp_attendance` WHERE emp_num = '{$_SESSION["id"]}' AND curr_date = '$date'";
$result6 = $conn->query($sql6);
if($result6 = mysqli_query($conn, $sql6)){
    if(mysqli_num_rows($result6) > 0){
        $time_in = "Yes";
    }
}

$sql7 = "SELECT * FROM `emp_attendance` WHERE emp_num = '{$_SESSION["id"]}' AND curr_date = '$date' AND time_out != ''";
$result7 = $conn->query($sql7);
if($result7 = mysqli_query($conn, $sql7)){
    if(mysqli_num_rows($result7) > 0){
        $done = "Yes";
    }
}

$sql8 = "SELECT Category, DATE_FORMAT(EndLeave, '%M %d, %Y') as EndLeave, IF(CURDATE() >= StartLeave AND CURDATE() <= EndLeave, 'YES', 'NO') as value FROM `leavelist` WHERE UserID = '{$_SESSION["id"]}' AND Status = 'Approved'";
$result8 = $conn->query($sql8);
if($result8 = mysqli_query($conn, $sql8)){
    if(mysqli_num_rows($result8) > 0){
        while($row8 = mysqli_fetch_array($result8)){
        $onleave = $row8['value'];
        $endleave = $row8['EndLeave'];
        $leavetype = $row8['Category'];
         }
    }
}

$sql9 = "SELECT * FROM work_schedule WHERE UserID = '{$_SESSION["id"]}'";
$result9 = $conn->query($sql9);
if($result9 = mysqli_query($conn, $sql9)){
    if(mysqli_num_rows($result9) > 0){
        while($row9 = mysqli_fetch_array($result9)){
            $mon = $row9['Monday'];
            $tue = $row9['Tuesday'];
            $wed = $row9['Wednesday'];
            $thu = $row9['Thursday'];
            $fri = $row9['Friday'];
            $sat = $row9['Saturday'];
            $sun = $row9['Sunday'];
            $scheduled = $row9[date('l')];
         }
    }
}

$sql10 = "SELECT CONCAT(u.Last_Name, ', ',u.First_Name,' ',u.Suffix, ' ',u.Middle_Name) AS Fullname, u.Position, u.Branch, u.UserID, SUM(Sales_Gain) as sales_per_employee FROM user u INNER JOIN sales s USING (UserID) WHERE u.Branch = '{$_SESSION["branch"]}' Group by u.UserID ORDER BY s.Sales_Gain DESC LIMIT 3";
$result10 = $conn->query($sql10);


$sql11 = "SELECT * FROM emp_absent WHERE UserID = '{$_SESSION["id"]}' AND DATE(Date) = '$date'";
$result11 = $conn->query($sql11);
if($result11 = mysqli_query($conn, $sql11)){
    if(mysqli_num_rows($result11) > 0){
        while($row11 = mysqli_fetch_array($result11)){
            $absent = "Yes";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <?php $currentPage = 'Dashboard'; ?>
    <?php $currentSub = ""; ?>
    <!-- Stylesheets -->
    
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="../Styles/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Styles/style.css">
    <link rel="stylesheet" href="../Styles/dashboard.css">
    
    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
</head>
<body>
<?php require_once('AdminNavbar.php'); ?>

        <div class="cards">
            <a class="card stretched-link text-decoration-none" href="EmployeeList.php">
                <div class="card-content" style="text-align: center;">
                <div class="number"> <?php while($row = mysqli_fetch_array($result)){ echo $row['Total']; }?></div>
                    <div class="card-name">Number of Employees in <?php echo $_SESSION['branch'] ?> Branch</div>
                </div>
            </a>
            <a class="card stretched-link text-decoration-none" href="AttendancePage.php">
                <div class="card-content">
                    <div class="number">95%</div>
                    <div class="card-name">My Attendance</div>
                </div>
            </a>
            
            <a class="card stretched-link text-decoration-none" href="AdminLeavePage.php">
                <div class="card-content">
                    <div class="number"><?php while($row2 = mysqli_fetch_array($result2)){ echo $row2['TotalLeave']; }?></div>
                    <div class="card-name">Pending Leave/s in <?php echo $_SESSION['branch'] ?> Branch</div>
                </div>
            </a>
        </div>
        <div class="charts">
        <a class="chart stretched-link text-decoration-none" href="AdminReport.php">
                <h2>Top Sales in <?php echo $_SESSION['branch'] ?> Branch</h2>
                <table class="table table-bordered">     
            <tbody>
              <?php if(mysqli_num_rows($result10) > 0){ $i = 1; while($row10 = mysqli_fetch_array($result10)){ ?>
            <tr class="text-center">
                <th scope="col">Rank</th>
                <th scope="col">Name</th>
                <th scope="col">Position</th>
                <th scope="col">Overall Score</th>
              </tr>
              <tr class="text-center">
                <td><?php echo $i; $i++; ?></td>
                <td><?php echo $row10['Fullname'];  ?></td>
                <td><?php echo $row10['Position'];  ?></td>
                <td><?php if($row10['sales_per_employee'] != ""){ echo $row10['sales_per_employee'];  }else { echo '0'?><?php }?></td>
              </tr>
              <?php }} else {?>
                    <tr class="text-center">
                        <th>No Records Available</th>
                    </tr>
                    <?php } ?>
                
            </tbody>
          </table>
            </a>
            <a class="chart stretched-link text-decoration-none" href="Task_List.php" style="text-align:center;">
                <h2><u><?php echo $_SESSION['branch'] ?> Branch </u></h2>
            <?php while($row4 = mysqli_fetch_array($result4)){ ?>
                <h2>Total Project/s</h2>
                <div class="number mb-3"><?php echo $row4['TotalProjects'];  ?></div>
                <h2>On-Progress Project/s</h2>
                <div class="number mb-3"><?php echo $row4['TotalProgress'];  ?></div>
               <?php }?>
            </a>
            <?php if ($onleave == "NO"){ ?>
            <?php if ($_SESSION["WORK_OFFSITE"] == "Yes" || $onsite == "Yes"){ ?>
            <?php if ($scheduled == 1){?>
            <?php if ($absent == "No"){ ?>
            <div class="cardtime">
                <a class="timebutt stretched-link text-decoration-none" href="AttendancePage.php">
                    <h2 style="color: #888;">Attendance</h2>
                    <span id="time" class="mb-2" style="color: #299b63;"></span>
                    <div class="container d-flex justify-content-center">
        <div class="row">
            <div class="col">
                <form action="../Attendance/save.php" method="post">
                
                <input type="hidden" name="id_num" value="<?php echo $_SESSION["id"]; ?>">
                <input type="hidden" name="location" id="location" value="<?php echo $loc ?>">
             
                <?php if ($time_in == "No"){ ?>
                    <input type="submit" value="Time in" class="btn btn-lg btn-success" id="id_num1"> 
                    <?php } elseif ($time_in == "Yes" && $done == "No") { ?>
                    <input type="submit" value="Time out" class="btn btn-lg btn-danger" id="id_num2">
                    <?php } else { ?>
                    <h5>Attendance Done for Today!</h5>
                    <?php } ?>
                </form>
            </div>
        </div>
    </div>
                </a>
            </div>
            <?php } else { ?>
            <div class="cardtime">
            <a class="timebutt stretched-link text-decoration-none" href="AttendancePage.php">
                <h2 style="color: #888;">Attendance Not Available</h2>
                <div class="container d-flex justify-content-center">
            <div class="row">
            <div class="col" style="color: #299b63;">
                <h5>You are mark as absent today.</h5>
            </div>
            </div>
            </div>
        </a>
        </div>
        <?php }?>
        <?php } else { ?>
            <div class="cardtime">
            <a class="timebutt stretched-link text-decoration-none" href="AdminProfile.php">
                <h2 style="color: #888;">Attendance Not Available</h2>
                <div class="container d-flex justify-content-center">
            <div class="row">
            <div class="col" style="color: #299b63;">
                <h5>You are not scheduled today</h5>
            </div>
            </div>
            </div>
        </a>
        </div>
        <?php }?>
        <?php } else { ?>
        <div class="cardtime">
            <a class="timebutt stretched-link text-decoration-none" href="#">
                <h2 style="color: #888;">Attendance Not Available</h2>
                <div class="container d-flex justify-content-center">
            <div class="row">
            <div class="col" style="color: #299b63;">
                <h5>We've detected that you are not onsite today</h5>
                <h6>For any problem or inquiries kindly contact HR Manager or System Administrator</h6>
            </div>
            </div>
            </div>
        </a>
        </div>
        <?php } ?>
        
        <?php } else { ?>

            <div class="cardtime">
            <a class="timebutt stretched-link text-decoration-none" href="MyLeave.php">
                <h2 style="color: #888;">You Are On-Leave</h2>
                <div class="container d-flex justify-content-center">
            <div class="row">
            <div class="col" style="color: #299b63;">
                <h5>Your Leave Will End on <?php echo $endleave ?></h5>
                <h5>Type: <?php echo $leavetype ?></h5>
            </div>
            </div>
            </div>
        </a>
        </div>
        <?php } ?>

        
        <!-- Modal1 Alert -->

   <div class="modal fade" id="modal1" tabindex="-1" role="dialog" aria-labelledby="payrollLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="payrollLabel"><b> Welcome to Employee Information System!</b></h5>
        </div>
        <div class="modal-body">
            <h5>Since this is your first time using the system, we recommend to change your Password first for security and set up your profile.</h5>
        </div>
        <div class="modal-footer">
          <a href="../Logout.php" class="btn btn-danger">Logout</a>
          <a href="AdminProfile.php" class="btn btn-primary">Proceed to Profile Page</a>
        </div>
      </div>
    </div>
  </div>
        
    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    
    <!-- Bootstrap JS -->
    <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

    <?php if($show_modal1):?>
            <script> 
                $('#modal1').modal({backdrop: 'static', keyboard: false})  
                $('#modal1').modal('show');
                </script>
            <?php endif;?>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
        var datetime = new Date();
        console.log(datetime);
        document.getElementById("time").textContent = datetime;
        function refreshTime() {
        const timeDisplay = document.getElementById("time");
        const dateString = new Date().toLocaleString();
        const formattedString = dateString.replace(", ", " - ");
        timeDisplay.textContent = formattedString;
        }
        setInterval(refreshTime, 1000);
    </script>

    
</body>
</html>