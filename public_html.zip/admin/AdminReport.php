<?php
// Initialize the session
session_start();

// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] !== 2){
  header("location: ../index.php");
  exit;
}
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] !== 2){
  header("location: ../index.php");
  exit;
}

// Include config file
require_once "../db/DBConn.php";

//SQL
$sql = "SELECT COUNT(*) AS Total, SUM(Employed_Date LIKE '2019%') AS FirstYear, SUM(Employed_Date LIKE '2020%') AS SecondYear, SUM(Employed_Date LIKE '2021%') AS ThirdYear, SUM(Employed_Date LIKE '2022%') AS FourthYear, SUM(Employed_Date LIKE '2023%') AS CurrentYear, SUM(Employed_Date LIKE '2023-01-%') AS January, SUM(Employed_Date LIKE '2023-02-%') AS February, SUM(Employed_Date LIKE '2023-03-%') AS March, SUM(Employed_Date LIKE '2023-04-%') AS April, SUM(Employed_Date LIKE '2023-05-%') AS May, SUM(Employed_Date LIKE '2023-06-%') AS June, SUM(Employed_Date LIKE '2023-07-%') AS July, SUM(Employed_Date LIKE '2023-08-%') AS August, SUM(Employed_Date LIKE '2023-09-%') AS September, SUM(Employed_Date LIKE '2023-10-%') AS October, SUM(Employed_Date LIKE '2023-11-%') AS November, SUM(Employed_Date LIKE '2023-12-%') AS December, SUM(Position = 'Senior Immigration Consultant') AS SIC, SUM(Position = 'Sales Executive') AS SE, SUM(Position = 'Immigration Consultant') AS IC, SUM(Position = 'Processing Officer') AS PO, SUM(Position = 'Unit Supervisor') AS US, SUM(Position LIKE '%Manager%') AS MG FROM `user` WHERE Branch = '{$_SESSION["branch"]}'";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports</title>
    <?php $currentPage = 'Reports'; ?>
    <?php $currentSub = ""; ?>
    <?php include '../plugins.php'; ?>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);
      google.charts.setOnLoadCallback(drawChart2);
      google.charts.setOnLoadCallback(drawChart3);


        function drawChart() {
         <?php while($row = mysqli_fetch_array($result)){ ?>
          var data = google.visualization.arrayToDataTable([
            ['Month', 'Number of Employees'],
            ['January', <?php echo $row['January'] ?>],
            ['February', <?php echo $row['February'] ?>],
            ['March', <?php echo $row['March'] ?>],
            ['April', <?php echo $row['April'] ?>],
            ['May', <?php echo $row['May'] ?>],
            ['June', <?php echo $row['June'] ?>],
            ['July', <?php echo $row['July'] ?>],
            ['August', <?php echo $row['August'] ?>],
            ['September', <?php echo $row['September'] ?>],
            ['October', <?php echo $row['October'] ?>],
            ['November', <?php echo $row['November'] ?>],
            ['December', <?php echo $row['December'] ?>]
          ]);
        
  
          var options = {
          };
  
          var chart = new google.charts.Bar(document.getElementById('columnchart_material'));
  
          chart.draw(data, google.charts.Bar.convertOptions(options));
        };
  
        function drawChart2() {
          var data = google.visualization.arrayToDataTable([
            ['Year', 'Number of Employees'],
            ['2019', <?php echo $row['FirstYear'] ?>],
            ['2020', <?php echo $row['SecondYear'] ?>],
            ['2021', <?php echo $row['ThirdYear'] ?>],
            ['2022', <?php echo $row['FourthYear'] ?>],
            ['2023', <?php echo $row['CurrentYear'] ?>]
          ]);
  
          var options = {
          };
  
          var chart = new google.charts.Bar(document.getElementById('columnchart_material2'));
  
          chart.draw(data, google.charts.Bar.convertOptions(options));
        };
  
        function drawChart3() {
          var data = google.visualization.arrayToDataTable([
          ['Position', 'Number of Employees'],
          ['Sales Executive', <?php echo $row['SE'] ?>],
          ['Senior Immigration Consultant', <?php echo $row['SIC'] ?>],
          ['Immigration Consultant', <?php echo $row['IC'] ?>],
          ['Processing Officer', <?php echo $row['PO'] ?>],
          ['Unit Supervisor', <?php echo $row['US'] ?>],
          ['Manager', <?php echo $row['MG'] ?>]
          ]);
  
          var options = {
          title: 'Total Number of Employees: <?php echo $row['Total'] ?>',
          titleTextStyle: {fontSize: 20},
          is3D: true,
          fontSize: 15,
          fontName: 'Poppins'
          };
  
          var chart = new google.visualization.PieChart(document.getElementById('piechart'));
  
          chart.draw(data, options);
          };

          <?php } ?>
      </script>
</head>
<body>
<?php require_once('AdminNavbar.php'); ?>
    <div class="content rounded bg-white" style="padding: 0.5em;">
    <div class="col-lg-13">
    <div class="card card-outline card-success">
		<div class="card-header">
			<h3 class="text-center"><b>REPORTS</b></h3>
		</div>
		
		<div class="card-body">
    <div class="col-lg-13">
    <div class="card card-outline card-primary">
		<div class="card-header">
			<h4 class="text-center">Number of Employees in <?php echo $_SESSION['branch'] ?> Branch</h4>
		</div>
		
		<div class="card-body">
            <div id="piechart" style="width: 100%; height: 400px;"></div>
            
        </div>
        </div>
    <!-- Total Employees in 5 Years -->
        <div class="col-lg-13">
    <div class="card card-outline card-primary">
		<div class="card-header">
			<h4 class="text-center">Number of Employees for the Last 5 Years in <?php echo $_SESSION['branch'] ?> Branch</h4>
		</div>
		
		<div class="card-body">
            <div id="columnchart_material2" style="width: 100%; height: 500px;"></div>
        </div>
        </div>
        <!-- Total Employees -->
        <div class="col-lg-13">
    <div class="card card-outline card-primary">
		<div class="card-header">
			<h4 class="text-center">Total Number of Employees for 2022 in <?php echo $_SESSION['branch'] ?> Branch</h4>
		</div>
		
		<div class="card-body">
    <div id="columnchart_material" style="height: 500px;"></div>
        </div>
        </div>
        <!-- Rank -->
        <div class="col-lg-13">
    <div class="card card-outline card-primary">
		<div class="card-header">
			<h4 class="text-center">Employee Rank Based on Overall Performance in <?php echo $_SESSION['branch'] ?> Branch</h4>
		</div>
		
		<div class="card-body">
        <table class="table table-bordered">     
            <tbody>
              <tr>
                <th scope="col">Name (Last, First, Middle, Suffix)</th>
                <th scope="col">Position</th>
                <th scope="col">Employed Date</th>
                <th scope="col">Rank</th>
              </tr>
              <tr>
                <td>Blanco, Wilma Raneses</td>
                <td>Employee</td>
                <td>07/01/2022</td>
                <td>1st</td>
              </tr>
    
            </tbody>
          </table>
    
          </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    
    <!-- Bootstrap JS -->
        <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
</body>
</html>