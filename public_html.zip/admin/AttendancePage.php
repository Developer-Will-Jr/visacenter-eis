<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] !== 2){
  header("location: ../index.php");
  exit;
}


// Include config file
require_once "../db/DBConn.php";

$sql = "SELECT *, DATE_FORMAT(curr_date, '%M %d, %Y') as DateA FROM emp_attendance WHERE emp_num = '{$_SESSION["id"]}' ORDER BY curr_Date DESC";
$result = $conn->query($sql);

$sql2 = "SELECT *, DATE_FORMAT(Date, '%M %d, %Y') AS DateofAbsent FROM emp_absent WHERE UserID = '{$_SESSION["id"]}' ORDER BY Date DESC";
$result2 = $conn->query($sql2);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance</title>
    <?php $currentPage = 'MyAttendance'; ?>
    <?php $currentSub = ''; ?>
    
    <?php include '../plugins.php'; ?>

</head>
<body>

<?php require_once('AdminNavbar.php'); ?>

            <div class="content rounded bg-white" style="padding: 1em;">

            <div class="col-lg-13">
    <div class="card card-outline card-success">
		<div class="card-header">
			<h4 class="text-center"><b>MY ATTENDANCE</b> </h4>
		</div>
		
		<div class="card-body">
            
    <?php if($result = mysqli_query($conn, $sql)){ ?>
        <table class="table table-hover text-center" id="myattendance">
                    <thead>
                    <tr>
                        <th scope="col">Date</th>
                        <th scope="col">Time IN</th>
                        <th scope="col">Time OUT</th>
                        <th scope="col">Location</th>
                    </tr>
                    </thead>        
                    <tbody>
                        
              <?php while($row = mysqli_fetch_array($result)){ ?>
                    <tr>
                        <td><?php echo $row['DateA'] ?></td>
                        <td><?php echo $row['time_in'] ?></td>
                        <td><?php echo $row['time_out'] ?></td>
                        <td><?php echo $row['Location'] ?></td>
                    </tr>
            
                    <?php }} ?>
                    </tbody>
                </table>
    
          </div>
    </div>
    </div>

    <div class="col-lg-13">
    <div class="card card-outline card-danger">
		<div class="card-header">
			<h4 class="text-center">MY ABSENT</h4>
		</div>
    
    <div class="card-body">
            
    <?php if($result2 = mysqli_query($conn, $sql2)){ ?>
        <table class="table table-hover text-center" id="myabsent">
                    <thead>
                    <tr>
                        <th scope="col">Date</th>
                    </tr>
                    </thead>        
                    <tbody>
                        
              <?php while($row1 = mysqli_fetch_array($result2)){ ?>
                    <tr>
                        <td><?php echo $row1['DateofAbsent'] ?></td>
                    </tr>
            
                    <?php }} ?>
                    </tbody>
                </table>
    
          </div>
    </div>
    </div>
            </div>


          
        <?php include '../footer.php'; ?>
        <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });

        $(document).ready(function() {
		    $('#myattendance').dataTable({"order": [],
              "aoColumns": [
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": false }
          ]
            })
            $('#myabsent').dataTable({"order": [],
              "aoColumns": [
              { "bSortable": true }
          ]
            })
          })
    </script>
</body>
</html>