<?php
// Initialize the session
session_start();

// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] !== 2){
  header("location: ../index.php");
  exit;
}

// Include config file
require_once "../db/DBConn.php";

// For View
$empVal = "";
if(isset($_GET['v']) && !empty($_GET['v'])){
  $empVal = $_GET['v'];
} elseif(isset($_GET['e']) && !empty($_GET['e'])){
  $empVal = $_GET['e'];
} elseif(isset($_GET['r']) && !empty($_GET['r'])){
   $empVal = $_GET['r'];
}

$branch = $_SESSION["branch"];

// For Table
  $sql = "SELECT *, DATE_FORMAT(Employed_Date, '%M %d, %Y') as EmpDate FROM `user` WHERE Access_level = 1 AND Branch = '{$_SESSION["branch"]}' ORDER BY Employed_Date DESC";

$result = $conn->query($sql);

$date = date('Y-m-d');
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Employee</title>
    <?php $currentPage = 'Employee'; ?>
    <?php $currentSub = 'EmployeeSubMenu1'; ?>
    
    <?php include '../plugins.php'; ?>

</head>
<body>

<?php require_once('AdminNavbar.php'); ?>
    <div class="container rounded bg-white" style="padding: 0.5em;">
    
     <!-- Employee List Table -->
     <div class="col-lg-13">
    <div class="card card-outline card-success">
		<div class="card-header">
			<h3 class="text-center"><b>EMPLOYEES <br>(<?php echo $branch ?> Branch)</b></h3>
    <button class="btn btn-success bg-gradient-success btn-sm" data-toggle="modal" data-target="#eview"><i class="fa fa-plus"></i> Evaluate Employee</button>
		</div>
		
		<div class="card-body">
<?php

if($result = mysqli_query($conn, $sql)){
    if(mysqli_num_rows($result) > 0){
echo  '<table class="table table-hover" id="emplist">';
echo '<thead>';
echo      '<tr class="text-center">';
echo        '<th scope="col">Name</th>';
echo        '<th scope="col">Position</th>';
echo        '<th scope="col">Employed Date</th>';
echo        '<th scope="col">Action</th>';
echo      '</tr>';
echo '</thead>';
echo    '<tbody>';
while($row = mysqli_fetch_array($result)){
echo      '<tr class="text-center">';
echo        '<td>' . $row['Last_Name'] . ', ' . $row['First_Name'] . ' ' . $row['Middle_Name'] . ' ' . $row['Suffix'] . '</td>';
echo        '<td>' . $row['Position'] . '</td>';
echo        '<td>' . $row['EmpDate'] . '</td>';
echo        '<td class="text-center">';
echo            '<button id="' . $row['UserID'] . '" class="btn btn-outline-primary" name="view1" title="View Details" onClick="empIDV(this.id)"><i class="fas fa-eye"></i></button>';
echo        '</td>';
echo      '</tr>';
}
echo    '</tbody>';
echo  '</table>';
// Free result set
mysqli_free_result($result);
} else{
  echo  '<table class="table table-bordered">';
  echo        '<tr>';
  echo          '<td colspan="4">';
  echo          '<div class="alert alert-danger"><em>No records were found.</em></div>';
  echo            '</div>';
  echo          '</td>';
  echo '</table>';
}
} else{
echo "Oops! Something went wrong. Please try again later.";
}
?>
     </div>
</div>
</div>
    <!-- Success -->
    <div class="modal fade" id="success" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Notice</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
          <h4><i class="fa fa-check" style="color:green"></i> Successfully Saved!</h4>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
      </div>
    </div>
      <!-- End -->


<!-- New Employee Form Modal -->
<div class="modal fade bd-example-modal-lg" id="EmployeeForm" tabindex="-1" role="dialog" aria-labelledby="EmployeeFormLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="EmployeeFormLabel">Create Account</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="../db/manage_employee.php" class="needs-validation" name="myForm" id="form1" onsubmit="return validateForm()" novalidate>
            <div class="form-row">
              <div class="form-group col-md-3">
                <label for="first">First Name</label>
                <input type="text" class="form-control" name="first" id="first" placeholder="First Name" required>
              </div>
              <div class="form-group col-md-3">
                <label for="inputEmail4">Middle Name</label>
                <input type="text" class="form-control" id="mid" name="mid" placeholder="Middle Name">
              </div>
              <div class="form-group col-md-3">
                <label for="inputEmail4">Last Name</label>
                <input type="text" class="form-control" name="last" id="last" placeholder="Last Name" required>
              </div>
              <div class="form-group col-md-3">
                <label for="inputEmail4">Suffix</label>
                <select name="suffix" placeholder="Suffix" class="form-control">
                  <option selected value="">N/A</option>
                  <option>Sr.</option>
                  <option>Jr.</option>
                  <option>III.</option>
                  <option>IV.</option>
                  <option>V.</option>
                  <option>VI.</option>
                  <option>VII.</option>
                  <option>VIII.</option>
                  <option>IX.</option>
                  <option>X.</option>
                  <option>XI.</option>
                  <option>XII.</option>
                  <option>XIII.</option>
                  <option>XIV.</option>
                  <option>XV.</option>
                  <option>XVI.</option>
                  <option>XVII.</option>
                  <option>XVIII.</option>
                  <option>XIX.</option>
                  <option>XX.</option>
                </select>
              </div>
              <div class="form-group col-md-3">
                <label for="inputEmail4">Birthdate</label>
                <input type="date" class="form-control" name="bday" placeholder="Birthdate" required>
              </div>
              <div class="form-group col-md-3">
                <label for="inputState">Gender</label>
                <select name="gender" class="form-control" required>
                  <option selected disabled value="">Choose..</option>
                  <option>Male</option>
                  <option>Female</option>
                  <option>Prefer Not to Specify</option>
                </select>
              </div>
              <div class="form-group col-md-3">
                <label for="inputEmail4">Contact Number</label>
                <input type="number" class="form-control" name="contact" placeholder="Contact Number" required>
              </div>
              <div class="form-group col-md-3">
                <label for="inputEmail4">Email</label>
                <input type="email" class="form-control" name="email" placeholder="Email" required>
              </div>
            </div>
            <div class="form-group">
              <label for="inputAddress">Complete Address</label>
              <input type="text" class="form-control" name="address" placeholder="Complete Address" required>
            </div>
            <div class="form-row">
              <div class="form-group col-md-4">
                <label for="inputState">Position</label>
                <select name="position" class="form-control" required>
                <option selected="true" disabled="disabled" value="">Choose..</option>
                <?php $resultpos = mysqli_query($conn, "SELECT * FROM positions WHERE Access_level = 1"); ?>
                <?php while ($row101 = mysqli_fetch_array($resultpos)) { ?>
                  <option><?php echo $row101['PositionName'] ?></option>
                  <?php } ?>
                </select>
              </div>
              <div class="form-group col-md-4">
                <label for="inputCity">Username</label>
                <input type="text" class="form-control" name="user" required>
              </div>
              <div class="form-group col-md-4">
                <label for="inputZip">Password</label>
                <input type="password" class="form-control" name="pass" required>
              </div>
            </div>
            
            <div class="form-row ">
            <div class="form-group col-md-6">
              <label for="inputAddress">Joined Date:</label>
              <input type="date" class="form-control" name="join"  min="<?php echo $date ?>" onkeydown="return false" required>
            </div>
            <div class="form-group col-md-6">
            <label for="inputState">Employment Status</label>
                <select name="status" class="form-control" required>
                <option selected="true" disabled="disabled" value="">Choose..</option>
                  <option>Probational</option>
                  <option>Regular</option>
                </select>
            </div>
          <div class="col-md-6">
          <label for="inputZip" class=" text-center">Please Input Your Password to Proceed:</label>
          <input type="password" class="form-control" id="mypass" placeholder="Your Password Here!" required>
          <div class="form-check mt-1">
          <input type="checkbox" class="form-check-input" onclick="showPassword()">
          <label class="form-label" for="exampleCheck1">Show Password</label>
          </div>
          </div>
            </div>
            <input type="hidden" class="form-control" name="branch" value="<?php echo $_SESSION["branch"] ?>">
          
      </div>
      <div class="modal-footer">      
        <div class="float-right">
      </div>  
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="addemployee" class="btn btn-primary">Add New Employee</button>
      </div>
    </form>
    </div>
  </div>
</div>
<!-- End of New Employee Form Modal -->

<!-- Employee to Evaluate -->
<div class="modal fade" id="eview" tabindex="-1" role="dialog" aria-labelledby="eviewLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="eviewLabel">Employees For Evaluation</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <form>
        <?php $resultve = mysqli_query($conn, "SELECT UserID, Branch, Position, CONCAT(Last_Name, ', ',First_Name,' ',Suffix, ' ',Middle_Name) AS Fullname, DATE_FORMAT(Employed_Date, '%M %d, %Y') as Date, DATEDIFF(CURDATE(), Employed_Date) as value FROM user WHERE DATEDIFF(CURDATE(), Employed_Date) >= 90 AND user.UserID NOT IN (SELECT evaluation.UserID FROM evaluation) AND Branch = '{$_SESSION["branch"]}';");?>
        <table class="table table-bordered">
                <tbody>
                  <tr class="text-center" bgcolor="green"><th colspan="5"><h5 style="color:white"><b>FIRST EVALUATION</b> </h5></th></tr>
                  <tr class="text-center">
                    <th scope="col">Full Name</th>
                    <th>Position</th>
                    <th>Employed Date</th>
                    <th>Days in the Company</th>
                    <th>Action</th>
                  </tr>
                  <?php while ($row1 = mysqli_fetch_array($resultve)) { ?>
                  <tr class="text-center">
                  <input type="hidden" name="userid" value="<?php echo $row1['UserID'] ?>">
                  <input type="hidden" name="name" value="<?php echo $row1['Fullname'] ?>">
                  <input type="hidden" name="pos" value="<?php echo $row1['Position'] ?>">
                  <input type="hidden" name="emp" value="<?php echo $row1['Date'] ?>">
                  <td><?php echo $row1['Fullname'] ?></td>
                    <td><?php echo $row1['Position'] ?></td>
                    <td><?php echo $row1['Date'] ?></td>
                    <td><?php echo $row1['value'] ?> Days</td>
                    <td class="text-center"><a type="submit" href="../Others/EvaluationPage.php?id=<?php echo $row1['UserID'] ?>" class="btn btn-success" name="evaluate" >Evaluate</a></td>
                  </tr>
                  <?php } ?>
        <?php $resultvi = mysqli_query($conn, "SELECT UserID, Branch, Position, CONCAT(Last_Name, ', ',First_Name,' ',Suffix, ' ',Middle_Name) AS Fullname,DATE_FORMAT(Employed_Date, '%M %d, %Y') as Date, DATEDIFF(CURDATE(), Employed_Date) as value FROM user WHERE DATEDIFF(CURDATE(), Employed_Date) >= 180 AND user.UserID IN (SELECT evaluation.UserID FROM evaluation) AND Branch = '{$_SESSION["branch"]}';");?>
        <table class="table table-bordered">
                <tbody>
                  <tr class="text-center" bgcolor="green"><th colspan="5" style="color:white"><h5><b>SECOND EVALUATION</b> </h5></th></tr>

                  <?php while ($row11 = mysqli_fetch_array($resultvi)) { ?>
                  <tr class="text-center">
                  <input type="hidden" name="userid" value="<?php echo $row11['UserID'] ?>">
                  <input type="hidden" name="name" value="<?php echo $row11['Fullname'] ?>">
                  <input type="hidden" name="pos" value="<?php echo $row11['Position'] ?>">
                  <input type="hidden" name="emp" value="<?php echo $row11['Date'] ?>">
                  <td><?php echo $row11['Fullname'] ?></td>
                    <td><?php echo $row11['Position'] ?></td>
                    <td><?php echo $row11['Date'] ?></td>
                    <td><?php echo $row11['value'] ?> Days</td>
                    <td class="text-center"><a type="submit" href="../Others/EvaluationPage.php?id=<?php echo $row11['UserID'] ?>" class="btn btn-success" name="evaluate" >Evaluate</a></td>
                  </tr>
                  <?php } ?>
                  </form>
                </tbody>
              </table>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  <!-- End of Employee to Evaluate -->


  <!-- Employee View -->
  <button style="display:none;" data-toggle="modal" data-target="#view"></button>
  <div class="modal fade" id="view" tabindex="-1" role="dialog" aria-labelledby="viewLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="viewLabel">Employee Full Details</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <?php $resultv = mysqli_query($conn, "SELECT * FROM `user` WHERE UserID = '$empVal'"); ?>
        <table class="table table-bordered">
        <?php while ($row2 = mysqli_fetch_array($resultv)) { ?>
                <tbody>
                  <tr>
                    <th scope="col">Full Name</th>
                    <td><?php echo $row2['Last_Name'] . ' ,' . $row2['First_Name'] . ' ' . $row2['Middle_Name'] . ' ' . $row2['Suffix'] ?></td>
                  </tr>
                  <tr>
                    <th>Birthdate</th>
                    <td><?php echo $row2['Birthdate'] ?></td>
                  </tr>
                  <tr>
                    <th>Gender</th>
                    <td><?php echo $row2['Gender'] ?></td>
                  </tr>
                  <tr>
                    <th>Contact Number</th>
                    <td><?php echo $row2['Contact'] ?></td>
                  </tr>
                  <tr>
                    <th>Email</th>
                    <td><?php echo $row2['Email'] ?></td>
                  </tr>
                  <tr>
                    <th>Complete Address</th>
                    <td><?php echo $row2['Address'] ?></td>
                  </tr>
                  <tr>
                    <th>Position</th>
                    <td><?php echo $row2['Position'] ?></td>
                  </tr>
                  <tr>
                    <th>Branch</th>
                    <td><?php echo $row2['Branch'] ?></td>
                  </tr>
                  <tr>
                    <th>Username</th>
                    <td><?php echo $row2['Username'] ?></td>
                  </tr>
                  <tr>
                    <th>Employment Status</th>
                    <td><?php echo $row2['Status'] ?></td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table> 
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  <!-- End of Employee View -->

  <!-- Edit Employee -->
<div class="modal fade bd-example-modal-lg" id="edit" tabindex="-1" role="dialog" aria-labelledby="editLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="editLabel">Edit Employee Form</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
        <?php $resulte = mysqli_query($conn, "SELECT * FROM `user` WHERE UserID = '$empVal'"); ?>
            <form method="post" action="../db/manage_employee.php" class="needs-validation" onsubmit="return validateForm2()" novalidate>
            <?php while ($row3 = mysqli_fetch_array($resulte)) { ?>
                <div class="form-row">
                  <div class="form-group col-md-3">
                    <label for="inputEmail4">First Name</label>
                    <input type="text" class="form-control" name="first" value="<?php echo $row3['First_Name'] ?>" id="first2" required>
                  </div>
                  <div class="form-group col-md-3">
                    <label for="inputEmail4">Middle Name</label>
                    <input type="text" class="form-control" name="mid" value="<?php echo $row3['Middle_Name'] ?>" id="mid2" required>
                  </div>
                  <div class="form-group col-md-3">
                    <label for="inputEmail4">Last Name</label>
                    <input type="text" class="form-control" name="last" value="<?php echo $row3['Last_Name'] ?>" id="last2" required>
                  </div>
                  <div class="form-group col-md-3">
                    <label for="inputEmail4">Suffix</label>
                    <input type="text" class="form-control" name="suffix" value="<?php echo $row3['Suffix'] ?>">
                  </div>
                  <div class="form-group col-md-3">
                    <label for="inputEmail4">Birthdate</label>
                    <input type="text" class="form-control" name="bday" value="<?php echo $row3['Birthdate'] ?>" required>
                  </div>
                  <div class="form-group col-md-3">
                    <label for="inputState">Gender</label>
                    <select id="inputState" class="form-control" name="gender" required>
                      <?php $gen = $row3['Gender']?>
                      <option <?php if ($gen == 'Male') { echo ' selected="selected"'; } ?>>Male</option>
                      <option <?php if ($gen == 'Female') { echo ' selected="selected"'; } ?>>Female</option>
                      <option <?php if ($gen == 'Prefer Not to Specify') { echo ' selected="selected"'; } ?>>Prefer Not to Specify</option>
                    </select>
                  </div>
                  <div class="form-group col-md-3">
                    <label for="inputEmail4">Contact Number</label>
                    <input type="number" class="form-control" name="contact" value="<?php echo $row3['Contact'] ?>" required>
                  </div>
                  <div class="form-group col-md-3">
                    <label for="inputEmail4">Email</label>
                    <input type="email" class="form-control" name="email" value="<?php echo $row3['Email'] ?>" required>
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputAddress">Complete Address</label>
                  <input type="text" class="form-control" name="address" value="<?php echo $row3['Address'] ?>" required>
                </div>
                <div class="form-row ">
                  <div class="form-group col-md-6">
                    <label for="inputState">Position</label>
                    <select id="inputState" class="form-control" name="position" required>
                    <?php $pos = $row3['Position']?>
                      <option <?php if ($pos == 'Sales Executive') { echo ' selected="selected"'; } ?>>Sales Executive</option>
                      <option <?php if ($pos == 'Senior Immigration Consultant') { echo ' selected="selected"'; } ?>>Senior Immigration Consultant</option>
                      <option> <?php if ($pos == 'Immigration Consultant') { echo ' selected="selected"'; } ?>Immigration Consultant</option>
                      <option <?php if ($pos == 'Processing Officer') { echo ' selected="selected"'; } ?>>Processing Officer</option>
                      <option <?php if ($pos == 'Unit Supervisor') { echo ' selected="selected"'; } ?>>Unit Supervisor</option>
                    </select>
                  </div>
                  <div class="form-group col-md-6">
              <label for="inputAddress text-center">Joined Date:</label>
              <input type="date" class="form-control" name="join" onkeydown="return false" value="<?php echo $row3['Employed_Date'] ?>" required>
            </div>
          <div class="col-md-6">
          <label for="inputZip" class=" text-center">Please Input Your Password to Proceed:</label>
          <input type="password" class="form-control" id="mypass2" placeholder="Your Password Here!" required>
          <div class="form-check mt-1">
          <input type="checkbox" class="form-check-input" onclick="showPassword2()">
          <label class="form-label" for="exampleCheck1">Show Password</label>
          </div>
          </div>
                  <input type="number" name="userid" value="<?php echo $row3['UserID'] ?>" hidden>
                  <input type="hidden" class="form-control" name="branch" value="<?php echo $_SESSION["branch"] ?>">
                </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Reset Password</button>
          <button type="submit" class="btn btn-success" name="editemployee">Save Changes</button>
        </div>
      </form>
      <?php } ?>
      </div>
    </div>
  </div>
  <!-- End of Edit Employee -->

    <!-- Remove Employee -->
    <div class="modal fade" id="remove" tabindex="-1" role="dialog" aria-labelledby="removeLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="removeLabel">Remove Employee</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
            <?php $resultr = mysqli_query($conn, "SELECT * FROM `user` WHERE UserID = '$empVal'"); ?>
            <form method="post" action="../db/manage_employee.php">
            <?php while ($row4 = mysqli_fetch_array($resultr)) { ?>
                <div class="form-row text-center">
                  <div class="form-group col-md-3">
                    <label for="inputEmail4">First Name</label>
                    <input type="text" class="form-control" name="first" value="<?php echo $row4['First_Name'] ?>" disabled>
                  </div>
                  <div class="form-group col-md-3">
                    <label for="inputEmail4">Middle Name</label>
                    <input type="text" class="form-control" name="mid" value="<?php echo $row4['Middle_Name'] ?>" disabled>
                  </div>
                  <div class="form-group col-md-3">
                    <label for="inputEmail4">Last Name</label>
                    <input type="text" class="form-control" name="last" value="<?php echo $row4['Last_Name'] ?>" disabled>
                  </div>
                  <div class="form-group col-md-3">
                    <label for="inputEmail4">Suffix</label>
                    <input type="text" class="form-control" name="suffix" value="<?php echo $row4['Suffix'] ?>" disabled>
                  </div>
                  <div class="form-group col-md-3">
                    <label for="inputEmail4">Contact Number</label>
                    <input type="number" class="form-control" name="contact" value="<?php echo $row4['Contact'] ?>" disabled>
                  </div>
                  <div class="form-group col-md-5">
                    <label for="inputEmail4">Email</label>
                    <input type="email" class="form-control" name="email" value="<?php echo $row4['Email'] ?>" disabled>
                  </div>
                  <div class="form-group col-md-4">
                    <label for="inputState">Position</label>
                    <select id="inputState" class="form-control" name="position" disabled>
                    <?php $pos = $row3['Position']?>
                      <option <?php if ($pos == 'Sales Executive') { echo ' selected="selected"'; } ?>>Sales Executive</option>
                      <option <?php if ($pos == 'Senior Immigration Consultant') { echo ' selected="selected"'; } ?>>Senior Immigration Consultant</option>
                      <option <?php if ($pos == 'Immigration Consultant') { echo ' selected="selected"'; } ?>>Immigration Consultant</option>
                      <option <?php if ($pos == 'Processing Officer') { echo ' selected="selected"'; } ?>>Processing Officer</option>
                      <option <?php if ($pos == 'Unit Supervisor') { echo ' selected="selected"'; } ?>>Unit Supervisor</option>
                    </select>
                  </div>
                </div>
                <div class="form-row">
                <div class="form-group col-md-3 text-center">
                <input type="number" name="userid" value="<?php echo $row4['UserID'] ?>" hidden>
            </div>
                  <div class="form-group col-md-5 text-center">
              <label for="inputAddress">Joined Date:</label>
              <input type="date" class="form-control text-center" name="join" value="<?php echo $row4['Employed_Date'] ?>" disabled>
            </div>
                  
                </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-danger" name="removeemployee">Remove</button>
        </div>
      </form>
      <?php } ?>
            </div>
          </div>
        </div>
      <!-- End of Remove Employee -->


    <input type="hidden" id="mypassword" value="<?php echo $_SESSION["password"] ?>">
     </div>
     </div>
    
     <?php include '../footer.php'; ?>
        <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
        $(function () {
        $('[data-toggle="tooltip"]').tooltip()
        })

        $(document).ready(function() {
		        $('#emplist').dataTable({"order": [],
              "aoColumns": [
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": false }
          ]
            })
          })
    </script>
    
    <!-- Data Validations -->
    <script>
          (function () {
            'use strict'

            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.querySelectorAll('.needs-validation')

            // Loop over them and prevent submission
            Array.prototype.slice.call(forms)
              .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                  if (!form.checkValidity()) {
                    alert("Please fill all the required field")
                    event.preventDefault()
                    event.stopPropagation()
                  }
                  form.classList.add('was-validated')
                  
                }, false)
              })
          })()

          function validateForm() {

            var letters = /^[A-Za-z]+$/;
            var first = document.getElementById("first");
            var mid = document.getElementById("mid");
            var last = document.getElementById("last");
            var mypass = document.getElementById("mypass");
            var password = document.getElementById("mypassword");
            var form1 = document.getElementById("form1");

            
            if (first.value == "") {
              alert("Please fill the Input Field");
              first.classList += " is-invalid";
              first.focus();
              return false;

            } else if (!letters.test(first.value)) {
              alert("The field should contain letters only");
              first.classList += " is-invalid";
              first.value = "";
              first.focus();
              return false;
              
            } else if (!letters.test(mid.value)) {
              alert("The field should contain letters only");
              mid.classList += " is-invalid";
              mid.value = "";
              mid.focus();
              return false;
              
            } else if (!letters.test(last.value)) {
              alert("The field should contain letters only");
              last.classList += " is-invalid";
              last.value = "";
              last.focus();
              return false;

            } else if (mypass.value != password.value) {
              alert("Wrong Password");
              mypass.classList += " is-invalid";
              mypass.focus();
              return false;
            } else {
              
            }
          }

          function validateForm2() {

            var letters = /^[A-Za-z]+$/;
            var first = document.getElementById("first2");
            var mid = document.getElementById("mid2");
            var last = document.getElementById("last2");
            var mypass = document.getElementById("mypass2");
            var password = document.getElementById("mypassword");

            if (first.value == "") {
              alert("Please fill the Input Field");
              first.classList += " is-invalid";
              first.focus();
              return false;

            } else if (!letters.test(first.value)) {
              alert("The field should contain letters only");
              first.classList += " is-invalid";
              first.value = "";
              first.focus();
              return false;
              
            } else if (!letters.test(mid.value)) {
              alert("The field should contain letters only");
              mid.classList += " is-invalid";
              mid.value = "";
              mid.focus();
              return false;
              
            } else if (!letters.test(last.value)) {
              alert("The field should contain letters only");
              last.classList += " is-invalid";
              last.value = "";
              last.focus();
              return false;

            } else if (mypass.value != password.value) {
              alert("Wrong Password");
              mypass.classList += " is-invalid";
              mypass.focus();
              return false;
            } else {
              
            }
            }

          function showPassword() {
          var x = document.getElementById("mypass");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
          }

          function showPassword2() {
          var x = document.getElementById("mypass2");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }
    </script>
    <script type="text/javascript">
      
      var urlcheck = window.location.href;
      var url = new URL(urlcheck);

      if (url.searchParams.get("v")!=null){
          $('#view').modal('show');
      } else if (url.searchParams.get("e")!=null){
          $('#edit').modal('show');
      }else if (url.searchParams.get("r")!=null){
          $('#remove').modal('show');
      }else if (url.searchParams.get("s")!=null){
          $('#success').modal('show');
      }

      function empIDV(clicked_id)
      { 
        var val = clicked_id;
          window.location.href="?v=" + val;
        
      };

      function empIDE(clicked_id)
      { 
        var val = clicked_id;
          window.location.href="?e=" + val;
         
      };

      function empIDR(clicked_id)
      { 
        var val = clicked_id;
          window.location.href="?r=" + val;
         
      };
      

</script>

</body>
</html>