<?php
// Initialize the session
session_start();

// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] !== 2){
  header("location: ../index.php");
  exit;
}

// Include config file
require_once "../db/DBConn.php";

$fill_info = "";
$fill_others = "";

// For Table
$sql = "SELECT n.Posted_by, n.NotificationID, n.Title, n.Details, n.Department, DATE_FORMAT(n.Date, '%M %d, %Y') as Date, n.Attachment, u.Last_Name, u.Position, u.ProfilePicture FROM `notification` n INNER JOIN user u ON n.Posted_by = u.UserID WHERE n.Department = '{$_SESSION["branch"]}' OR n.Department = 'All Departments' OR n.Posted_by = '{$_SESSION['id']}' ORDER BY n.Date DESC;";
$result = $conn->query($sql);

$date = date('Y-m-d');

$notifVal = "";
if(isset($_GET['e']) && !empty($_GET['e'])){
  $notifVal = base64_decode($_GET['e']);
} elseif(isset($_GET['r']) && !empty($_GET['r'])){
   $notifVal = base64_decode($_GET['r']);
}

$sql2 = "SELECT IF(Address = '' OR Email = '' OR Contact = '', 'YES', 'NO') as Info, IF(SSS = '' OR Philhealth = '' OR Pag_Ibig = '' OR Bank_Name = '' OR Bank_Account = '', 'YES', 'NO') as Others FROM `user` WHERE UserID = '{$_SESSION["id"]}'";
$result2 = $conn->query($sql2);
if($result2 = mysqli_query($conn, $sql2)){
    if(mysqli_num_rows($result2) > 0){
        while($row2 = mysqli_fetch_array($result2)){
        $fill_info = $row2['Info'];
        $fill_others = $row2['Others'];
         }
    }
}

$sql3 = "SELECT UserID, Branch, Position, CONCAT(Last_Name, ', ',First_Name,' ',Suffix, ' ',Middle_Name) AS Fullname, DATE_FORMAT(Employed_Date, '%M %d, %Y') as Date, DATEDIFF(CURDATE(), Employed_Date) as value FROM user WHERE DATEDIFF(CURDATE(), Employed_Date) >= 90 AND user.UserID NOT IN (SELECT evaluation.UserID FROM evaluation) AND Branch = '{$_SESSION["branch"]}';";
$result3 = $conn->query($sql3);

$sql4 = "SELECT UserID, Branch, Position, CONCAT(Last_Name, ', ',First_Name,' ',Suffix, ' ',Middle_Name) AS Fullname,DATE_FORMAT(Employed_Date, '%M %d, %Y') as Date, DATEDIFF(CURDATE(), Employed_Date) as value FROM user WHERE DATEDIFF(CURDATE(), Employed_Date) >= 180 AND user.UserID IN (SELECT evaluation.UserID FROM evaluation) AND Branch = '{$_SESSION["branch"]}';";
$result4 = $conn->query($sql4);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications</title>
    <?php $currentPage = 'Notifications'; ?>
    <?php $currentSub = ""; ?>
    <!-- Stylesheets -->
    
    
    <?php include '../plugins.php'; ?>

    <style>
        .notifbox{
            border-radius: 15px;
            padding: 1.5em;
            background-color: #254E58;
            color: #fff;
        }
        p{
            color: #fff;
            margin-left: 1em; 
        }
        hr{
            background-color: #fff;
        }
    </style>
</head>
<body>

<?php require_once('AdminNavbar.php'); ?>
    <div class="container rounded bg-white" style="padding: 1em;">
    <div class="col-lg-13">
    <div class="card card-outline card-success">
		<div class="card-header">
			<h4 class="text-center"><b>NOTIFICATIONS</b></h4>
				<div class="card-tools">
      <button class="btn btn-primary bg-gradient-primary btn-sm float-right" data-toggle="modal" data-target="#create"><i class="fa fa-plus"></i> Create New Notifications</button>
        </div> <br>
		<div class="card-body">

    <?php if ($fill_info == "YES"){ ?>
    <div class="notifbox" style="background-color: #0E4D92;">
        <h4>Fill Up Required!</h4>
        <p>We've detected that you have blank information in your profile, please fill it up. <a href="ManagerProfile.php" style="color: yellow; text-decoration: underline;">Click Here</a></p>
        <hr>
        <h6>This notification is system generated</h6>
    </div> <br>
    <?php } ?>

    <?php if ($fill_others == "YES"){ ?>
    <div class="notifbox" style="background-color: #0E4D92;">
        <h4>Fill Up Required</h4> <br>
        <p>We've detected that you have blank information in your profile, please fill it up. <a href="ManagerProfile.php" style="color: yellow; text-decoration: underline;">Click Here</a></p>
        <hr>
        <h6>This notification is system generated</h6>
    </div> <br>
    <?php } ?>

  <?php  if($result3 = mysqli_query($conn, $sql3)){
    if(mysqli_num_rows($result3) > 0){
        while($row3 = mysqli_fetch_array($result3)){ ?>

        <div class="notifbox" style="background-color: #0E4D92;">
        <h4>First evaluation is available for <?php echo $row3['Fullname'] ?></h4> <br>
        <p><b><?php echo $row3['Fullname'] ?></b> is hired on the day of <?php echo $row3['Date'] ?> (<?php echo $row3['value'] ?> days in the company) and a <?php echo $row3['Position'] ?> in <?php echo $row3['Branch'] ?> Branch. <a type="submit" href="../Others/EvaluationPage.php?id=<?php echo base64_encode($row3['UserID']) ?>" style="color: yellow; text-decoration: underline;">Click here to evaluate.</a></p> 
        
        <hr>
        <h6>This notification is system generated</h6>
        </div> <br>
        <?php } ?>
        <?php } ?>
        <?php } ?> 
  
    <?php  if($result4 = mysqli_query($conn, $sql4)){
    if(mysqli_num_rows($result4) > 0){
        while($row4 = mysqli_fetch_array($result4)){ ?>

        <div class="notifbox" style="background-color: #0E4D92;">
        <h4>Second evaluation is available for <?php echo $row4['Fullname'] ?></h4> <br>
        <h6><b><?php echo $row4['Fullname'] ?></b> is hired on the day of <?php echo $row4['Date'] ?> (<?php echo $row4['value'] ?> days in the company) and a <?php echo $row4['Position'] ?> in <?php echo $row4['Branch'] ?> Branch. <a type="submit" href="../Others/EvaluationPage.php?id=<?php echo base64_encode($row4['UserID']) ?>" style="color: yellow; text-decoration: underline;">Click here to evaluate.</a></h6> 
        
        <hr>
        <h6>This notification is system generated</h6>
        </div> <br>
        <?php } ?>
        <?php } ?>
        <?php } ?> 

    <?php

if($result = mysqli_query($conn, $sql)){
  if(mysqli_num_rows($result) > 0){
    while($row = mysqli_fetch_array($result)){

echo    '<div class="notifbox">';
if ($_SESSION["id"] == $row['Posted_by']){
echo        '<div style="float: right;">';
echo            '<button class="btn btn-success" id="' . base64_encode($row['NotificationID']) . '" title="Edit" onClick="notifE(this.id)">';
echo               '<i class="fas fa-pencil-alt"></i></button>';
echo            '<button id="' . base64_encode($row['NotificationID']) . '" class="btn btn-danger" data-placement="top" title="Delete"  onClick="notifR(this.id)"><i class="fas fa-trash-alt"></i></button>';
echo        '</div>';
}
echo        '<h4>' . $row['Title'] . '</h4>';
echo        '<p>' . $row['Details'] . '</p>';
echo        '<p>Attachment: <a style="color: lightblue; text-decoration: underline;" href="../Files/notification/'.$row['Attachment'].'">'.$row['Attachment'].'</a></p>';
echo        '<hr>';
echo        '<h6><img src="../Images/upload/' .$row["ProfilePicture"]. '" alt="" width="4%" style="border-radius: 50%;"> ' . $row['Last_Name'] . ' | ' . $row['Position'] . ' to ' .  $row['Department'] . '<span style="float: right;">Date Posted: ' . $row['Date'] . '</span></h6>';
echo    '</div> <br>';

    }
mysqli_free_result($result);
} 
} else{
echo "Oops! Something went wrong. Please try again later.";
}
?>
      </div>
      </div>
      </div>

      <!-- Create -->
      <div class="modal fade bd-example-modal-lg" id="create" tabindex="-1" role="dialog" aria-labelledby="createLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="createLabel">Create Notification</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form method="post" action="../db/dbNotif.php" enctype="multipart/form-data">
                    <div class="form-row mb-3">
                        <div class="col">
                            <label for="">Title:</label>
                          <input type="text" class="form-control" name="title">
                        </div>
                        
                      </div>
                      <div class="form-row mb-3">
                        <div class="col">
                        <label for="inputState">Department</label>
                        <select id="inputState" class="form-control" name="department">
                        <?php $resultdep = mysqli_query($conn, "SELECT DISTINCT Department FROM positions"); ?>
                        <?php while ($row102 = mysqli_fetch_array($resultdep)) { ?>
                        <option value="<?php echo $row102['Department'] ?>"><?php echo $row102['Department'] ?> Department</option>
                        <?php } ?>
                        <option>All Departments</option>
                        </select>
                        </div>
                        <div class="col">
                          <label for="">Date:</label>
                          <input class="form-control" type="date" name="postdate" disabled value="<?php echo $date ?>">
                        </div>
                      </div>
                      <div class="form-row mb-3">
                        <label>Details</label>
                        <textarea class="form-control" rows="4" name="details"></textarea>
                      </div>
                        <div class="form-group">
                          <label class="form-label">Attachment</label>
                          <input type="file" class="form-control text-center" name="attach">
                          <small class="text-left">Only accept .jpg .jpeg .png .pdf .doc or .docx file</small>
                        </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary" name="post">Post</button>
            </div>
          </form>
          </div>
        </div>
      </div>
      <!-- End of Create -->

      <!-- Edit -->
      <div class="modal fade bd-example-modal-lg" id="edit" tabindex="-1" role="dialog" aria-labelledby="editLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="editLabel">Edit Notification</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
            <?php $resulta = mysqli_query($conn, "SELECT * FROM notification WHERE NotificationID = '$notifVal'"); ?>
            <form method="post" action="../db/dbNotif.php" enctype="multipart/form-data">
            <?php while ($row2 = mysqli_fetch_array($resulta)) { ?>
                    <div class="form-row mb-3">
                        <div class="col">
                            <label for="">Subject:</label>
                          <input type="text" class="form-control" name="title" value="<?php echo $row2['Title'] ?>">
                        </div>
                      </div>

                      <div class="form-row mb-3">
                        <div class="col">
                        <label for="inputState">Department</label>
                        <select id="inputState" class="form-control" name="department">
                        <?php $dept = $row2['Department']?>
                        <?php $resultdep = mysqli_query($conn, "SELECT DISTINCT Department FROM positions"); ?>
                        <?php while ($row102 = mysqli_fetch_array($resultdep)) { ?>
                        <option value="<?php echo $row102['Department'] ?>" <?php if ($row102['Department'] == $dept) { echo ' selected="selected"'; } ?>><?php echo $row102['Department'] ?> Department</option>
                        <?php } ?>
                        <option value="All Employee" <?php if ($dept == "All Employee") { echo ' selected="selected"'; } ?>>All Employee</option>
                        </select>
                      </div>
                     </div>
                     
                      <div class="form-row mb-3">
                        <label> Details</label>
                        <textarea class="form-control" rows="5" name="details"><?php echo $row2['Details'] ?></textarea>
                      </div>
                        <div class="form-group">
                          <label class="form-label">Current Attachment: </label>
                          <a style="color: blue; text-decoration: underline;" href="../Files/notification/<?php echo $row2['Attachment'] ?>"> <?php echo $row2['Attachment'] ?></a> <br>
                          <input type="hidden" name="currattach" value="<?php echo $row2['Attachment'] ?>">

                          <label class="form-label">Edit Attachment</label>
                          <input type="file" class="form-control text-center" name="newattach">
                          <small class="text-left">Only accept .jpg .jpeg .png .pdf .doc or .docx file</small>
                        </div>
                        <input type="hidden" name="notifid" value="<?php echo $row2['NotificationID'] ?>">
                        <input class="form-control" type="hidden" name="postdate" value="<?php echo $date ?>">
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary" name="editnotif">Save Changes</button>
            </div>
          </form>
          </div>
        </div>
      </div>
      </div>
      <!-- End of Edit -->

      <!-- Delete -->
      <div class="modal fade bd-example-modal-lg" id="delete" tabindex="-1" role="dialog" aria-labelledby="editLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="editLabel">Remove Notification</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
            <form method="post" action="../db/dbNotif.php">
                    <div class="form-row mb-3">
                        <div class="col">
                            <label for="">Subject: </label>
                          <input type="text" class="form-control" value="<?php echo $row2['Title'] ?>" disabled>
                        </div>
                      </div>
                      <div class="form-row mb-3">
                        <div class="col">
                        <label for="inputState">Department</label>
                        <input type="text" class="form-control" disabled value="<?php echo $row2['Department'] ?>" disabled>
                      </div>
            </div>
                      <div class="form-row mb-3">
                        <label>Details</label>
                        <textarea class="form-control" rows="5" name="details" disabled><?php echo $row2['Details'] ?></textarea>
                      </div>
                        <div class="form-group">
                          <label class="form-label">Attachment: </label>
                          <a style="color: blue; text-decoration: underline;" href="../Files/notification/<?php echo $row2['Attachment'] ?>"> <?php echo $row2['Attachment'] ?></a>
                        </div>
                        <input type="hidden" name="notifid" value="<?php echo $row2['NotificationID'] ?>">
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-danger" name="removenotif">Remove</button>
            </form>
            </div>
          </div>
        </div>
      </div>
      <!-- End of Delete -->
      
      <?php }?>

    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    
    <!-- Bootstrap JS -->
        <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
        $(function () {
        $('[data-toggle="tooltip"]').tooltip()
        })
    </script>
    <script type="text/javascript">

    //For Showing Modal
    var urlcheck = window.location.href;
    var url = new URL(urlcheck);
    if (url.searchParams.get("e")!=null){
        $('#edit').modal('show');
    }else if (url.searchParams.get("r")!=null){
        $('#delete').modal('show');
    }else if (url.searchParams.get("s")!=null){
        $('#success').modal('show');
    }

    // For Putting a Value in URL
    function notifE(clicked_id)
    { 
      if (clicked_id != null){
        var val = clicked_id;
        window.location.href="./Notifications.php" + "?e=" + val;
      }
    };

    function notifR(clicked_id)
    { 
      if (clicked_id != null){
        var val = clicked_id;
        window.location.href="./Notifications.php" + "?r=" + val;
      }
    };
    </script>
</body>
</html>