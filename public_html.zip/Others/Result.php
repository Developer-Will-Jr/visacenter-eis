<?php
// Initialize the session
session_start();
 

// Include config file
require_once "../db/DBConn.php";

$sql = "SELECT CONCAT(user.Last_Name, ', ',user.First_Name,' ',user.Suffix, ' ',user.Middle_Name) AS Fullname, user.Position, DATE_FORMAT(user.Employed_Date, '%m/%d/%Y') AS date, DATE_FORMAT(evaluation.Date, '%m/%d/%Y') AS evaldate, evaluation.Attitude1, evaluation.Attitude2, evaluation.Attitude3, evaluation.Attitude4, evaluation.Attitude5, evaluation.Attitude6, evaluation.Responsibility1, evaluation.Responsibility2, evaluation.Responsibility3, evaluation.Responsibility4, evaluation.Competency1, evaluation.Competency2, evaluation.Competency3, evaluation.Competency4, evaluation.Competency5, evaluation.Comment, evaluation.Rating FROM evaluation INNER JOIN user ON user.UserID = evaluation.UserID WHERE evaluation.EvaluationID = {$_GET["id"]}";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evaluation Result</title>
    <link rel="stylesheet" href="../Styles/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Styles/style.css">

    <style>
         input[type='radio'] { 
            transform: scale(2); 
        }
        .container[type='radio']{
            text-align: center;
        }
        th.headers{
            background-color: yellow !important;
        }

        @media print {
            .print-btn{
                display: none;
                visibility: none;
            }
            #text-hide{
                display: none;
                visibility: none;
            }
            body{
                background: #fff;
            }
        }
    </style>
</head>
<body>
<div class="container rounded bg-white" style="padding: 1rem; margin-top: 1rem">
        <form>
        <h4 class="text-center" style="color:green"><img src="../Images/logo.webp" alt="" width="30px"> The Visa Center Evaluation Form</h4>
            <?php if($result = mysqli_query($conn, $sql)){ ?>
                    <table class="table table-bordered">
                        <tbody>
                        <tr>
                            <th>Employee Name</th>
                            <?php while($row = mysqli_fetch_array($result)){ ?>
                            <td colspan="4"><?php echo $row['Fullname'] ?></td>
                            <th>Date</th>
                            <td><?php echo $row['evaldate'] ?></td>
                        </tr>
                        <tr>
                            <th>Date of Joining</th>
                            <td colspan="4"><?php echo $row['date'] ?></td>
                            <th rowspan="3">Total Rating</th>
                            <td rowspan="3"><?php echo $row['Rating'] ?></td>
                        </tr>
                        <tr>
                            <th>Position</th>
                            <td colspan="4"><?php echo $row['Position'] ?></td>
                        </tr>
                        <tr>
                            <th>Department</th>
                            <td colspan="4"></td>
                        </tr>
                        <tr>
                            <th colspan="7" class="text-center headers">Evaluation Sheet</th>
                        </tr>
                        <div style="background-color: green;">
                        <tr>
                            <td colspan="2"></td>
                            <td>Deficient</td>
                            <td>Below Standard</td>
                            <td>Below Expectation</td>
                            <td>Above Standard</td>
                            <td>Outstanding</td>
                        </tr>
                        <tr>
                            <td class="text-right">No</td>
                            <td>Criteria</td>
                            <td class="text-center">1</td>
                            <td class="text-center">2</td>
                            <td class="text-center">3</td>
                            <td class="text-center">4</td>
                            <td class="text-center">5</td>
                        </tr>
                        <tr>
                            <th class="text-right">1</th>
                            <th>Attitude</th>
                            <td colspan="6"></td>
                        </tr>
                        <tr>
                            <td class="text-right">1.1</td>
                            <td>Customer Service Oriented</td>
                            <?php $att1 = $row['Attitude1']?>
                            <td class="text-center"><input type="radio" id="html" name="1.1" value="1" <?php if ($att1 == 1) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.1" value="2" <?php if ($att1 == 2) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.1" value="3" <?php if ($att1 == 3) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.1" value="4" <?php if ($att1 == 4) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.1" value="5" <?php if ($att1 == 5) { echo ' checked="checked"'; } ?>></td>
                        </tr>
                        <tr>
                            <td class="text-right">1.2</td>
                            <td>Communication </td>
                            <?php $att2 = $row['Attitude2']?>
                            <td class="text-center"><input type="radio" id="html" name="1.2" value="1" <?php if ($att2 == 1) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.2" value="2" <?php if ($att2 == 2) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.2" value="3" <?php if ($att2 == 3) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.2" value="4" <?php if ($att2 == 4) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.2" value="5" <?php if ($att2 == 5) { echo ' checked="checked"'; } ?>></td>
                        </tr>
                        <tr>
                            <td class="text-right">1.3</td>
                            <td>Eagerness to learn</td>
                            <?php $att3 = $row['Attitude3']?>
                            <td class="text-center"><input type="radio" id="html" name="1.3" value="1" <?php if ($att3 == 1) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.3" value="2" <?php if ($att3 == 2) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.3" value="3" <?php if ($att3 == 3) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.3" value="4" <?php if ($att3 == 4) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.3" value="5" <?php if ($att3 == 5) { echo ' checked="checked"'; } ?>></td>
                        </tr>
                        <tr>
                            <td class="text-right">1.4</td>
                            <td>Teamwork</td>
                            <?php $att4 = $row['Attitude4']?>
                            <td class="text-center"><input type="radio" id="html" name="1.4" value="1" <?php if ($att4 == 1) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.4" value="2" <?php if ($att4 == 2) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.4" value="3" <?php if ($att4 == 3) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.4" value="4" <?php if ($att4 == 4) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.4" value="5" <?php if ($att4 == 5) { echo ' checked="checked"'; } ?>></td>
                        </tr>
                        <tr>
                            <td class="text-right">1.5</td>
                            <td>Leadership</td>
                            <?php $att5 = $row['Attitude5']?>
                            <td class="text-center"><input type="radio" id="html" name="1.5" value="1" <?php if ($att5 == 1) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.5" value="2" <?php if ($att5 == 2) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.5" value="3" <?php if ($att5 == 3) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.5" value="4" <?php if ($att5 == 4) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.5" value="5" <?php if ($att5 == 5) { echo ' checked="checked"'; } ?>></td>
                        </tr>
                        <tr>
                            <td class="text-right">1.6</td>
                            <td>Work under pressure</td>
                            <?php $att6 = $row['Attitude6']?>
                            <td class="text-center"><input type="radio" id="html" name="1.6" value="1" <?php if ($att6 == 1) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.6" value="2" <?php if ($att6 == 2) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.6" value="3" <?php if ($att6 == 3) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.6" value="4" <?php if ($att6 == 4) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="1.6" value="5" <?php if ($att6 == 5) { echo ' checked="checked"'; } ?>></td>
                        </tr>
                        <tr>
                            <th class="text-right">2</th>
                            <th colspan="6">Responsibility</th>
                        </tr>
                        <tr>
                            <td class="text-right">2.1</td>
                            <td>Attendance/Punctuality</td>
                            <?php $res1 = $row['Responsibility1']?>
                            <td class="text-center"><input type="radio" id="html" name="2.1" value="1" <?php if ($res1 == 1) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.1" value="2" <?php if ($res1 == 2) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.1" value="3" <?php if ($res1 == 3) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.1" value="4" <?php if ($res1 == 4) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.1" value="5" <?php if ($res1 == 5) { echo ' checked="checked"'; } ?>></td>
                        </tr>
                        <tr>
                            <td class="text-right">2.2</td>
                            <td>Work on deadline</td>
                            <?php $res2 = $row['Responsibility2']?>
                            <td class="text-center"><input type="radio" id="html" name="2.2" value="1" <?php if ($res2 == 1) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.2" value="2" <?php if ($res2 == 2) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.2" value="3" <?php if ($res2 == 3) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.2" value="4" <?php if ($res2 == 4) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.2" value="5" <?php if ($res2 == 5) { echo ' checked="checked"'; } ?>></td>
                        </tr>
                        <tr>
                            <td class="text-right">2.3</td>
                            <td>Willingness to take more responsibilities</td>
                            <?php $res3 = $row['Responsibility3']?>
                            <td class="text-center"><input type="radio" id="html" name="2.3" value="1" <?php if ($res3 == 1) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.3" value="2" <?php if ($res3 == 2) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.3" value="3" <?php if ($res3 == 3) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.3" value="4" <?php if ($res3 == 4) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.3" value="5" <?php if ($res3 == 5) { echo ' checked="checked"'; } ?>></td>
                        </tr>
                        <tr>
                            <td class="text-right">2.4</td>
                            <td>Open to feedback</td>
                            <?php $res4 = $row['Responsibility4']?>
                            <td class="text-center"><input type="radio" id="html" name="2.4" value="1" <?php if ($res4 == 1) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.4" value="2" <?php if ($res4 == 2) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.4" value="3" <?php if ($res4 == 3) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.4" value="4" <?php if ($res4 == 4) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="2.4" value="5" <?php if ($res4 == 5) { echo ' checked="checked"'; } ?>></td>
                        </tr>
                        <tr>
                            <th class="text-right">3</th>
                            <th colspan="6">Competency</th>
                        </tr>
                        <tr>
                            <td class="text-right">3.1</td>
                            <td>Creativity</td>
                            <?php $com1 = $row['Competency1']?>
                            <td class="text-center"><input type="radio" id="html" name="3.1" value="1" <?php if ($com1 == 1) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.1" value="2" <?php if ($com1 == 2) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.1" value="3" <?php if ($com1 == 3) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.1" value="4" <?php if ($com1 == 4) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.1" value="5" <?php if ($com1 == 5) { echo ' checked="checked"'; } ?>></td>
                        </tr>
                        <tr>
                            <td class="text-right">3.2</td>
                            <td>Productivity</td>
                            <?php $com2 = $row['Competency2']?>
                            <td class="text-center"><input type="radio" id="html" name="3.2" value="1" <?php if ($com2 == 1) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.2" value="2" <?php if ($com2 == 2) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.2" value="3" <?php if ($com2 == 3) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.2" value="4" <?php if ($com2 == 4) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.2" value="5" <?php if ($com2 == 5) { echo ' checked="checked"'; } ?>></td>
                        </tr>
                        <tr>
                            <td class="text-right">3.3</td>
                            <td>Ability to work independently</td>
                            <?php $com3 = $row['Competency3']?>
                            <td class="text-center"><input type="radio" id="html" name="3.3" value="1" <?php if ($com3 == 1) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.3" value="2" <?php if ($com3 == 2) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.3" value="3" <?php if ($com3 == 3) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.3" value="4" <?php if ($com3 == 4) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.3" value="5" <?php if ($com3 == 5) { echo ' checked="checked"'; } ?>></td>
                        </tr>
                        <tr>
                            <td class="text-right">3.4</td>
                            <td>Initiative</td>
                            <?php $com4 = $row['Competency4']?>
                            <td class="text-center"><input type="radio" id="html" name="3.4" value="1" <?php if ($com4 == 1) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.4" value="2" <?php if ($com4 == 2) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.4" value="3" <?php if ($com4 == 3) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.4" value="4" <?php if ($com4 == 4) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.4" value="5" <?php if ($com4 == 5) { echo ' checked="checked"'; } ?>></td>
                        </tr>
                        <tr>
                            <td class="text-right">3.5</td>
                            <td>Effective problem solving skills</td>
                            <?php $com5 = $row['Competency5']?>
                            <td class="text-center"><input type="radio" id="html" name="3.5" value="1" <?php if ($com5 == 1) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.5" value="2" <?php if ($com5 == 2) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.5" value="3" <?php if ($com5 == 3) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.5" value="4" <?php if ($com5 == 4) { echo ' checked="checked"'; } ?>></td>
                            <td class="text-center"><input type="radio" id="html" name="3.5" value="5" <?php if ($com5 == 5) { echo ' checked="checked"'; } ?>></td>
                        </tr>
                        <tr>
                            <td colspan="7"></td>
                        </tr>
                        <tr>
                            <th colspan="7">Comment / Recommendation</th>
                        </tr>
                        <tr>
                            <td colspan="7" rowspan="4"><textarea class="form-control" name="" id="" cols="30" rows="10" disabled style="background-color: #fff;"><?php echo $row['Comment']?></textarea></td>
                        </tr>
                        </div>
                        </tbody>
                    </table>
                <div class="text-center">
                <?php if ($_SESSION['access'] == 3){ ?>
                <button type="button" class="btn btn-primary print-btn" onclick="window.location.href='../Manager/PerformanceEvaluation.php'">Back</button> <?php }else { ?>
                <button type="button" class="btn btn-primary print-btn" onclick="window.location.href='../admin/EmployeeList.php'">Back</button>
                <?php } ?>
                <button type="button" class="btn btn-secondary print-btn" onclick="window.print()">Print</button>
                </div>
</form>
<?php }}?>
</div>

<div class="modal fade" id="eval" tabindex="-1" role="dialog" aria-labelledby="evalModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="evalModalLabel">Success!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Evaluation for William
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Print</button>
      </div>
    </div>
  </div>
</div>

</body>
     
    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script>
        $('input[type=radio]').click(function(e){
            e.preventDefault();
        });
    </script>
</html>