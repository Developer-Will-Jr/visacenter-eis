<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["position"]) || $_SESSION["position"] != "Admin Manager"){
    header("location: ../index.php");
    exit;
  }

// Include config file
require_once "../db/DBConn.php";

$id = base64_decode($_GET["id"]);

$sql = "SELECT DISTINCT user.UserID, CONCAT(user.First_Name, ' ',user.Last_Name, ' ',user.Suffix) AS Fullname, user.Position, user.Status, user.Branch, e.Salary FROM user LEFT JOIN employee_salary e ON e.UserID = user.UserID WHERE user.UserID = '$id';";
$result = $conn->query($sql);


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payslip</title>
    <link rel="stylesheet" href="../Styles/bootstrap/css/bootstrap.min.css">

        <style>
            body{
                background-color: #88BDBC;
            }
            th.headers{
                background-color: lightgreen !important;
            }
            table.bg{
                background-image: linear-gradient(rgba(255, 255, 255, 0.93),rgba(255, 255, 255, 0.93)), url(../Images/BigLogo.webp) !important;
                background-repeat: no-repeat !important;
                background-size: 500px !important;
                background-position: center !important;
            }
            table, th, td {
                border: 1px solid #000 !important;
                }

               
        </style>
</head>
<body>
    


    <div class="container rounded bg-white" style="padding: 1rem; margin-top: 1rem">
    <h1 style="font-weight: 700; color: rgb(40, 180, 40);"><img src="../Images/logo.webp" alt="logo"> The Visa Center</h1>
    <hr style="margin: 1px 0">
    <p><b>TVC International Immigration Services</b></p>
    <div style="padding: 2rem" class="text-center">
    <?php if($result = mysqli_query($conn, $sql)){ ?>
    <?php while($row = mysqli_fetch_array($result)){ ?>
    <h5>Basic Salary for <?php echo $row['Fullname'] ?></h5>
    <h5><?php echo $row['Position'] ?> at <?php echo $row['Branch'] ?> Branch</h5>
    <h5 class="mb-3">Status: <?php echo $row['Status'] ?></h5>
    <form action="../db/manage_employee.php" method="post">
    <div class="form-row">
            <input type="hidden" name="userid" value="<?php echo $row['UserID'] ?>">
            <div class="form-group col-md-12">
            <label for="">Basic Salary Per Day</label>
            <div class="form-group col-md-12 text-center">
            <input class="text-center" type="number" name="salary" step=".01" value="<?php echo $row['Salary'] ?>">
            </div>
            </div>
    <?php }} ?>
    <div class="form-group col-md-12">
    <a href="Payslip.php?id=<?php echo $_GET['id'] ?>" class="btn btn-secondary mt-3">Return</a>
    <button type="submit" name="basic_salary" class="btn btn-success mt-3">Save</button>
    </div>
</form>
    </div>
    </div>
</body>

</html>