<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] > 4){
    header("location: ../index.php");
    exit;
  }

// Include config file
require_once "../db/DBConn.php";

$sql = "SELECT CONCAT(user.Last_Name, ', ',user.First_Name,' ',user.Suffix, ' ',user.Middle_Name) AS Fullname, user.Position, DATE_FORMAT(user.Employed_Date, '%m/%d/%Y') AS date, user.Bank_Name, user.Bank_Account, DATE_FORMAT(payroll.Date_submitted, '%m/%d/%Y') AS paymentdate, payroll.Basic_salary, payroll.Total FROM payroll INNER JOIN user ON user.UserID = payroll.UserID WHERE Payroll_id = {$_GET["id"]}";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payslip Result</title>
    <link rel="stylesheet" href="../Styles/bootstrap/css/bootstrap.min.css">

    <style>
        body{
            background-color: #88BDBC;
        }
        th.headers{
            background-color: lightgreen !important;
        }
        table.bg{
            background-image: linear-gradient(rgba(255, 255, 255, 0.93),rgba(255, 255, 255, 0.93)), url(../Images/BigLogo.webp) !important;
            background-repeat: no-repeat !important;
            background-size: 500px !important;
            background-position: center !important;
        }
        table, th, td {
            border: 1px solid #000 !important;
            }

            
        @page{
                size: A4;
                margin: 0;

            }
        @media print {
            .print-btn{
                display: none;
                visibility: none;
            }
            #text-hide{
                display: none;
                visibility: none;
            }
            body{
                background: #fff;
            }
            
    }
    </style>
</head>
<body>
    
    <div class="container rounded bg-white" style="padding: 1rem; margin-top: 1rem">
    <h1 style="font-weight: 700; color: rgb(40, 180, 40);"><img src="../Images/logo.webp" alt="logo"> The Visa Center</h1>
    <hr style="margin: 1px 0">
    <p><b>TVC International Immigration Services</b></p>
    <div style="padding: 2rem">
    <?php if($result = mysqli_query($conn, $sql)){ ?>
    <table class="table bg">
        <thead>
            <th colspan="4" class="text-center headers"><br><h4>SALARY SLIP</h4></th>
            <th colspan="2" class="text-center headers"><h6>PRIVATE AND <br> CONFIDENTIAL</h6></th>
        </thead>
        <tbody>
        <?php while($row = mysqli_fetch_array($result)){ ?>
            <tr>
                <td>Employee Name:</td>
                <td style="text-transform: uppercase"><b><?php echo $row['Fullname'] ?></b></td>
                <td colspan="2">Payment Slip for the month of:</td>
                <td colspan="2">March 1-15, 2023</td>
            </tr>
            <tr>
                <td>Date of Joining:</td>
                <td><?php echo $row['date'] ?></td>
                <td colspan="2">Days Worked:</td>
                <td colspan="2" style="text-transform: uppercase">15 DAYS</td>
            </tr>
            <tr>
                <td>Department:</td>
                <td style="text-transform: uppercase"><?php echo $row['Position'] ?></td>
                <td colspan="2">Bank Name:</td>
                <td colspan="2"><?php echo $row['Bank_Name'] ?></td>
            </tr>
            <tr>
                <td>Designation:</td>
                <td style="text-transform: uppercase"><?php echo $row['Position'] ?></td>
                <td colspan="2">Bank Account #:</td>
                <td colspan="2"><?php echo $row['Bank_Account'] ?></td>
            </tr>
            <tr>
                <th colspan="2" class="headers">Description</th>
                <th colspan="2" class="text-center headers">Earnings</th>
                <th colspan="2" class="text-center headers">Deduction</th>
            </tr>
            <tr>
                <td colspan="2">Basic Salary</td>
                <td width="150"><?php echo $row['Basic_salary'] ?></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">Personal Quota</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">Team Quota</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">Late / Absences</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr><tr>
                <td colspan="2">SSS</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">PhilHealth</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">Pag Ibig</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">Cash Advance</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">Total Deductions:</td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <tr>
                <td colspan="2">Total:</td>
                <td rowspan="2" colspan="2"><h4> Net Salary Pay</h4></td>
                <td rowspan="2" colspan="2"><h4>Php <?php echo $row['Total'] ?></h4></td>
            </tr>
            <tr>
                <td colspan="2">Payment Date: <?php echo $row['paymentdate'] ?></td>
            </tr>
        </tbody>
    </table>
    <p class="text-center" style="margin-top: -10px;"><b>I hereby acknowledge and confirm that I received my salary (Net Pay) deposited to my bank account. Thank you.</b></p>
    <p style="margin-top: 5em;" class="text-center">Employee Signature:_________________________ &nbsp;&nbsp;&nbsp; HR Dept:_________________________</p>
        </div>
        <hr>
        <h6 class="text-center">Employee Information System Generated. Created by QCU BSIT Students</h6>
    </div>
    <?php }}?>
    <div class="text-center mt-3 mb-3">
    <button type="button" class="btn btn-primary print-btn" onclick="window.location.href='../Manager/Salary.php'">Back</button>
    <button type="button" class="btn btn-secondary print-btn" onclick="window.print()">Print</button>
    </div>
</body>
</html>