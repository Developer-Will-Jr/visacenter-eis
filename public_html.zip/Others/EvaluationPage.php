<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] <= 1){
    header("location: ../index.php");
    exit;
  }

// Include config file
require_once "../db/DBConn.php";

$id = base64_decode($_GET["id"]);

$sql = "SELECT CONCAT(Last_Name, ', ',First_Name, ' ',Middle_Name) AS Fullname, UserID, Position, DATE_FORMAT(Employed_Date, '%m/%d/%Y') AS date FROM user WHERE UserID = '$id'";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evaluation Page</title>
    <link rel="stylesheet" href="../Styles/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Styles/style.css">

    <style>
        
         input[type='radio'] { 
            transform: scale(2); 
        }
        .container[type='radio']{
            text-align: center;
        }
        th.eval{
            background: yellow !important;
            text-align: center;
        }
        .hide{
            display: none;
        }

        @page{
                size: A4;
                margin: 0;

            }
        @media print {
            
            .print-btn{
                display: none;
                visibility: none;
            }
            #text-hide{
                display: none;
                visibility: none;
            }
            body{
                background: #fff;
            }
    }
    </style>
</head>
<body>
<div class="container rounded bg-white" style="padding: 1rem; margin-top: 1rem">
<form action="../db/manage_employee.php" method="post">
            <h4 class="text-center" style="color:green"><img src="../Images/logo.webp" alt="" width="30px"> The Visa Center Evaluation Form</h4>
            <?php if($result = mysqli_query($conn, $sql)){ ?>
                    <table class="table table-bordered">
                        <tbody>
                        <tr>
                            <th>Employee Name</th>
                            <?php while($row = mysqli_fetch_array($result)){ ?>
                            <td colspan="4"><?php echo $row['Fullname'] ?></td>
                            <input type="hidden" name="userid" value="<?php echo $row['UserID'] ?>">
                            <input type="hidden" name="evaluatorid" value="<?php echo $_SESSION["id"] ?>">
                            <th>Date</th>
                            <td><span id="date"></span></td>
                        </tr>
                        <tr>
                            <th>Date of Joining</th>
                            <td colspan="4"><?php echo $row['date'] ?></td>
                            <th rowspan="3">Total Rating</th>
                            <td rowspan="3"><span id="totalvalue"></span></td>
                            <input type="hidden" name="total" id="totality">
                        </tr>
                        <tr>
                            <th>Position</th>
                            <td colspan="4"><?php echo $row['Position'] ?></td>
                        </tr>
                        <tr>
                            <th>Department</th>
                            <td colspan="4"></td>
                        </tr>
                        <tr>
                            <th colspan="7" class="eval">Evaluation Sheet</th>
                        </tr>
                        <tr>
                            <td colspan="2"></td>
                            <td>Deficient</td>
                            <td>Below Standard</td>
                            <td>Below Expectation</td>
                            <td>Above Standard</td>
                            <td>Outstanding</td>
                        </tr>
                        <tr>
                            <td class="text-right">No</td>
                            <td>Criteria</td>
                            <td class="text-center">1</td>
                            <td class="text-center">2</td>
                            <td class="text-center">3</td>
                            <td class="text-center">4</td>
                            <td class="text-center">5</td>
                        </tr>
                        <tr>
                            <th class="text-right">1</th>
                            <th>Attitude</th>
                            <td colspan="6"></td>
                        </tr>
                        <tr>
                            <td class="text-right">1.1</td>
                            <td>Customer Service Oriented</td>
                            <td class="text-center"><input type="radio" id="1.1" name="a1" value="1" required><span class="hide">1</span></td>
                            <td class="text-center"><input type="radio" id="1.1" name="a1" value="2"><span class="hide">2</span></td>
                            <td class="text-center"><input type="radio" id="1.1" name="a1" value="3"><span class="hide">3</span></td>
                            <td class="text-center"><input type="radio" id="1.1" name="a1" value="4"><span class="hide">4</span></td>
                            <td class="text-center"><input type="radio" id="1.1" name="a1" value="5"><span class="hide">5</span></td>
                        </tr>
                        <tr>
                            <td class="text-right">1.2</td>
                            <td>Communication </td>
                            <td class="text-center"><input type="radio" id="html" name="a2" value="1" required><span class="hide">1</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a2" value="2"><span class="hide">2</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a2" value="3"><span class="hide">3</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a2" value="4"><span class="hide">4</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a2" value="5"><span class="hide">5</span></td>
                        </tr>
                        <tr>
                            <td class="text-right">1.3</td>
                            <td>Eagerness to learn</td>
                            <td class="text-center"><input type="radio" id="html" name="a3" value="1" required><span class="hide">1</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a3" value="2"><span class="hide">2</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a3" value="3"><span class="hide">3</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a3" value="4"><span class="hide">4</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a3" value="5"><span class="hide">5</span></td>
                        </tr>
                        <tr>
                            <td class="text-right">1.4</td>
                            <td>Teamwork</td>
                            <td class="text-center"><input type="radio" id="html" name="a4" value="1" required><span class="hide">1</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a4" value="2"><span class="hide">2</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a4" value="3"><span class="hide">3</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a4" value="4"><span class="hide">4</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a4" value="5"><span class="hide">5</span></td>
                        </tr>
                        <tr>
                            <td class="text-right">1.5</td>
                            <td>Leadership</td>
                            <td class="text-center"><input type="radio" id="html" name="a5" value="1" required><span class="hide">1</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a5" value="2"><span class="hide">2</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a5" value="3"><span class="hide">3</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a5" value="4"><span class="hide">4</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a5" value="5"><span class="hide">5</span></td>
                        </tr>
                        <tr>
                            <td class="text-right">1.6</td>
                            <td>Work under pressure</td>
                            <td class="text-center"><input type="radio" id="html" name="a6" value="1" required><span class="hide">1</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a6" value="2"><span class="hide">2</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a6" value="3"><span class="hide">3</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a6" value="4"><span class="hide">4</span></td>
                            <td class="text-center"><input type="radio" id="html" name="a6" value="5"><span class="hide">5</span></td>
                        </tr>
                        <tr>
                            <th class="text-right">2</th>
                            <th colspan="6">Responsibility</th>
                        </tr>
                        <tr>
                            <td class="text-right">2.1</td>
                            <td>Attendance/Punctuality</td>
                            <td class="text-center"><input type="radio" id="html" name="r1" value="1" required><span class="hide">1</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r1" value="2"><span class="hide">2</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r1" value="3"><span class="hide">3</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r1" value="4"><span class="hide">4</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r1" value="5"><span class="hide">5</span></td>
                        </tr>
                        <tr>
                            <td class="text-right">2.2</td>
                            <td>Work on deadline</td>
                            <td class="text-center"><input type="radio" id="html" name="r2" value="1" required><span class="hide">1</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r2" value="2"><span class="hide">2</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r2" value="3"><span class="hide">3</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r2" value="4"><span class="hide">4</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r2" value="5"><span class="hide">5</span></td>
                        </tr>
                        <tr>
                            <td class="text-right">2.3</td>
                            <td>Willingness to take more responsibilities</td>
                            <td class="text-center"><input type="radio" id="html" name="r3" value="1" required><span class="hide">1</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r3" value="2"><span class="hide">2</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r3" value="3"><span class="hide">3</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r3" value="4"><span class="hide">4</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r3" value="5"><span class="hide">5</span></td>
                        </tr>
                        <tr>
                            <td class="text-right">2.4</td>
                            <td>Open to feedback</td>
                            <td class="text-center"><input type="radio" id="html" name="r4" value="1" required><span class="hide">1</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r4" value="2"><span class="hide">2</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r4" value="3"><span class="hide">3</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r4" value="4"><span class="hide">4</span></td>
                            <td class="text-center"><input type="radio" id="html" name="r4" value="5"><span class="hide">5</span></td>
                        </tr>
                        <tr>
                            <th class="text-right">3</th>
                            <th colspan="6">Competency</th>
                        </tr>
                        <tr>
                            <td class="text-right">3.1</td>
                            <td>Creativity</td>
                            <td class="text-center"><input type="radio" id="html" name="c1" value="1" required><span class="hide">1</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c1" value="2"><span class="hide">2</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c1" value="3"><span class="hide">3</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c1" value="4"><span class="hide">4</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c1" value="5"><span class="hide">5</span></td>
                        </tr>
                        <tr>
                            <td class="text-right">3.2</td>
                            <td>Productivity</td>
                            <td class="text-center"><input type="radio" id="html" name="c2" value="1" required><span class="hide">1</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c2" value="2"><span class="hide">2</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c2" value="3"><span class="hide">3</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c2" value="4"><span class="hide">4</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c2" value="5"><span class="hide">5</span></td>
                        </tr>
                        <tr>
                            <td class="text-right">3.3</td>
                            <td>Ability to work independently</td>
                            <td class="text-center"><input type="radio" id="html" name="c3" value="1" required><span class="hide">1</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c3" value="2"><span class="hide">2</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c3" value="3"><span class="hide">3</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c3" value="4"><span class="hide">4</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c3" value="5"><span class="hide">5</span></td>
                        </tr>
                        <tr>
                            <td class="text-right">3.4</td>
                            <td>Initiative</td>
                            <td class="text-center"><input type="radio" id="html" name="c4" value="1" required><span class="hide">1</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c4" value="2"><span class="hide">2</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c4" value="3"><span class="hide">3</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c4" value="4"><span class="hide">4</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c4" value="5"><span class="hide">5</span></td>
                        </tr>
                        <tr>
                            <td class="text-right">3.5</td>
                            <td>Effective problem solving skills</td>
                            <td class="text-center"><input type="radio" id="html" name="c5" value="1" required><span class="hide">1</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c5" value="2"><span class="hide">2</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c5" value="3"><span class="hide">3</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c5" value="4"><span class="hide">4</span></td>
                            <td class="text-center"><input type="radio" id="html" name="c5" value="5"><span class="hide">5</span></td>
                        </tr>
                        <tr>
                            <td colspan="7"></td>
                        </tr>
                        <tr>
                            <th colspan="7">Comment / Recommendation</th>
                        </tr>
                        <tr>
                            <td colspan="7" rowspan="4"><textarea class="form-control" name="comment" id="" cols="30" rows="10"></textarea></td>
                        </tr>
                        </tbody>
                    </table>
                <div class="text-center">
                <button type="button" class="btn btn-secondary print-btn" onclick="history.go(-1)">Cancel</button>
                <button type="button" class="btn btn-primary print-btn" onclick="compute();" >Compute</button>
                <button type="submit" class="btn btn-success print-btn" id="sub" name="evaluation" disabled>Submit Evaluation</button>
                </div>
</form>
<?php }}?>
</div>

</body>
     
    <!-- jQuery CDN - Slim version (=without AJAX) -->
    
    <script src="../Styles/bootstrap/js/jquery.calculation.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script>
         n =  new Date();
        y = n.getFullYear();
        m = n.getMonth() + 1;
        d = n.getDate();
        if (d < 10) d = '0' + d;
        if (m < 10) m = '0' + m;
        document.getElementById("date").innerHTML = m + "/" + d + "/" + y;

        function compute(){
            var total = 0;
            $("input[type=radio]:checked").each(function() {
                total += parseFloat($(this).val());
            });
            let totalval = Math.round(((total)/15) * 100)/ 100;

            document.getElementById("totalvalue").innerHTML = totalval;
            document.getElementById("totality").value = totalval;

            document.body.scrollTop = document.documentElement.scrollTop = 0;
            document.getElementById("sub").disabled = false;
            
        };

    </script>
</html>