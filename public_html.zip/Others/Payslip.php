<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["position"]) || $_SESSION["position"] != "Admin Manager"){
    header("location: ../index.php");
    exit;
  }

// Include config file
require_once "../db/DBConn.php";

$show_modal1 = false;
$show_modal2 = false;
$show_modal3 = false;
$from = "";
$to = "";
$diff = date_create("0000-00-00");

$id = base64_decode($_GET['id']);

$sql = "SELECT DISTINCT e.Salary, CONCAT(user.First_Name, ' ', user.Middle_Name, ' ',user.Last_Name, ' ',user.Suffix) AS Fullname, user.UserID, user.Position, DATE_FORMAT(user.Employed_Date, '%m/%d/%Y') AS date, user.Bank_Name, user.Bank_Account, d.SSS, d.PhilHealth, d.Pag_Ibig, d.Others, d.Cash_Advance FROM user INNER JOIN employee_salary e ON e.UserID = user.UserID LEFT JOIN deductions d ON d.UserID = user.UserID WHERE user.UserID = $id;";
$result = $conn->query($sql);

if($result = mysqli_query($conn, $sql)){
if(mysqli_num_rows($result) < 1){
        $show_modal1 = true;
            }
        }

$sqlB = "SELECT * FROM deductions WHERE UserID = $id";
$resultB = $conn->query($sqlB);
if($resulB = mysqli_query($conn, $sqlB)){
    if(mysqli_num_rows($resulB) < 1){
            $show_modal2 = true;
                }
            }

if (!isset($_GET['from'])){
    $show_modal3 = true;
} else {
    
$from = $_GET['from'];
$to = $_GET['to'];

$from1 = date_create($from);
$to1 = date_create($to);
$to1->modify('+1 day');
$diff = date_diff($from1, $to1);
}

$late = 0;
    


$sqlC = "SELECT u.UserID, SUM(ROUND(TIME_TO_SEC(e.minutes_of_late) / 60)) as minutes FROM user u LEFT JOIN emp_attendance e ON u.UserID = e.emp_num WHERE e.curr_date >= '$from' AND e.curr_date <= '$to' AND e.emp_num = $id";
$resultB = $conn->query($sqlB);
if($resultC = mysqli_query($conn, $sqlC)){
    if(mysqli_num_rows($resultC) < 1){
        if(mysqli_num_rows($resultC) > 0){
            while($rowC = mysqli_fetch_array($resultC)){
                $late = $rowC['minutes'];
             }
        }
            }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payslip</title>
    <?php include '../plugins.php'; ?>

    <style>
        body{
            background-color: #88BDBC;
        }
        th.headers{
            background-color: lightgreen !important;
        }
        table, th, td {
            border: 1px solid #000 !important;
            }

            
        @page{
                size: A4;
                margin: 0;

            }
        @media print {
            .print-btn{
                display: none;
                visibility: none;
            }
            #text-hide{
                display: none;
                visibility: none;
            }
            body{
                background: #fff;
            }
            
    }
    </style>
</head>
<body>
    
    <div class="container rounded bg-white" style="padding: 1rem; margin-top: 1rem">
    <h1 style="font-weight: 700; color: rgb(40, 180, 40);"><img src="../Images/logo.webp" alt="logo"> The Visa Center</h1>
    <hr style="margin: 1px 0">
    <p><b>TVC International Immigration Services</b></p>
    <div style="padding: 2rem">
    <?php
     if($result = mysqli_query($conn, $sql)){?>
            
    <form action="../db/manage_employee.php" method="post">
        
        <table class="table bg">
        <thead>
            <th colspan="2" class="text-center headers"><br><h4>PAYROLL</h4></th>
        </thead>
        <tbody>
        <?php while($row = mysqli_fetch_array($result)){ ?>
            <tr>
                <td>Employee Name:</td>
                <td style="text-transform: uppercase"><b><?php echo $row['Fullname'] ?></b></td>
            </tr>
            <tr>
                <td>Date of Joining:</td>
                <td><?php echo $row['date'] ?></td>
            </tr>
            <tr>
                <td>Department:</td>
                <td style="text-transform: uppercase"><?php echo $row['Position'] ?></td>
            </tr>
            <tr>
                <td>Designation:</td>
                <td style="text-transform: uppercase"><?php echo $row['Position'] ?></td>
            </tr>
            <tr>
                <td>Bank Name:</td>
                <td><?php echo $row['Bank_Name'] ?></td>
            </tr>
            <tr>
                <td>Bank Account #:</td>
                <td><?php echo $row['Bank_Account'] ?></td>
            </tr>
            <tr>
                <td>Payslip From:</td>
                <td><input type="date" value="<?php echo $from ?>" class="form-control" disabled></td>
            </tr>
            <tr>
                <td>Payslip To:</td>
                <td><input type="date" value="<?php echo $to ?>" class="form-control" disabled></td>
            </tr>
            <tr>
                <td>Days Worked:</td>
                <td>
                <input type="text" class="form-control" value="<?php echo $diff->format('%d'); ?>" id="days" style="border: 0;" disabled>
                </td>
            </tr>
            <tr>
                <th colspan="2" class="text-center headers">Earnings</th>
            </tr>
            <tr>
                <td>Basic Salary</td>
                <td><span id="basicsalary">0</span></td>
            </tr>
            <tr>
                <td>Personal Quota</td>
                <td><input type="number" name="personal" id="personal" class="form-control" style="width: 35%" value="0"></td>
            </tr>
            <tr>
                <td>Team Quota</td>
                <td><input type="number" name="team" id="team" class="form-control" style="width: 35%" value="0"></td>
            </tr>
            <tr>
                <td>Bonus</td>
                <td><input type="number" name="bonus" id="bonus" class="form-control" style="width: 35%" value="0"></td>
            </tr>
            <tr>
                <th colspan="2" class="text-center headers">Deductions</th>
            </tr>
            <tr>
                <td>Late / Absences</td>
                <td><?php echo $late ?></td>
            </tr>
            <tr>
                <td>SSS</td>
                <td><?php echo $row['SSS'] ?></td>
            </tr>
            <tr>
                <td>PhilHealth</td>
                <td><?php echo $row['PhilHealth'] ?></td>
            </tr>
            <tr>
                <td>Pag Ibig</td>
                <td><?php echo $row['Pag_Ibig'] ?></td>
            </tr>
            <tr>
                <td>Others</td>
                <td><?php echo $row['Others'] ?></td>
            </tr>
            <tr>
                <td>Cash Advance</td>
                <td><?php if($row['Cash_Advance'] != ""){ echo $row['Cash_Advance'] ?>
                 <?php } else { echo '0'  ?>
                 <?php } ?>
            </tr>
            <tr>
            <?php
                 $basic = $row['Salary'] * 15;
                 $c = 0;
                 $d = $row['SSS'];
                 $e = $row['PhilHealth'];
                 $f = $row['Pag_Ibig'];
                 $g = $row['Others'];
                 $h = $row['Cash_Advance'];
                 $totalE = $basic;
                 $totalD = $c+$d+$e+$f+$g+$h;
                 $totalSalary = $totalE - $totalD;
                 ?>
                <td>Total Deductions:</td>
                <td><?php echo $totalD ?></td>
            </tr>
            <tr>
                <th colspan="2" class="text-center headers">Total Net Pay</th>
            </tr>
            <tr>
                <td colspan="2" class="text-center"><h4 id="net">0</h4></td>
            </tr>
        </table>

    <input type="hidden" name="from" value="<?php echo $to ?>">
    <input type="hidden" name="to" value="<?php echo $to ?>">
    <input type="hidden" name="days" value="<?php echo $diff->format('%d'); ?>">
    <input type="hidden" name="userid" value="<?php echo $row['UserID'] ?>">
    <input type="hidden" name="basic" id="basic" value="">
    <input type="hidden" name="personal" value="<?php echo $a ?>">
    <input type="hidden" name="team" value="<?php echo $b ?>">
    <input type="hidden" name="late" value="<?php echo $c ?>">
    <input type="hidden" name="sss" value="<?php echo $d ?>">
    <input type="hidden" name="ph" value="<?php echo $e ?>">
    <input type="hidden" name="pagibig" value="<?php echo $f ?>">
    <input type="hidden" name="others" value="<?php echo $g ?>">
    <input type="hidden" name="cash" value="<?php echo $h ?>">
    <input type="hidden" name="totalD" value="<?php echo $totalD ?>">
    <input type="hidden" id="totalnet" name="total" value="">

        
    

   
    <div class="text-center mt-3 mb-3">
    <a type="button" class="btn btn-secondary bg-gradient-secondary" href="../Manager/Salary.php">Cancel</a>
    <a type="button" class="btn btn-danger bg-gradient-danger" href="Deductions.php?id=<?php echo $_GET["id"] ?>">Edit Deductions</a>
    <a type="button" class="btn btn-primary bg-gradient-primary" href="BasicSalary.php?id=<?php echo $_GET["id"] ?>">Edit Basic Salary</a>
    <button type="button" class="btn btn-primary bg-gradient-primary" onclick="compute();">Compute</button>
    <button type="submit" class="btn btn-success bg-gradient-success" id="upload" name="payslip" disabled>Upload</button>
    </form>
    </div>

    
    </div>
    </div>
    <script>
                    
                    var days = document.getElementById("days");
                    var basic = document.getElementById("basicsalary");
                    var netsalary = document.getElementById("net");
                    var btnupload = document.getElementById("upload");
                    var bonus = document.getElementById("bonus");
                    var team = document.getElementById("team");
                    var personal = document.getElementById("personal");
                    var totalDeductions = <?php echo $totalD ?>;
                    var salary = <?php echo $row['Salary'] ?>
                    
                    function compute(){
                        
                        var totaldays =+ days.value * salary;
                        var totaladd =+ team.value + personal.value + bonus.value;
                        var totalnet =+ totaladd + totaldays - totalDeductions;
                        basic.innerHTML = totaldays;
                        netsalary.innerHTML = "Php " + totalnet;
                        document.getElementById("basic").value = totaldays;
                        document.getElementById("totalnet").value = totalnet;
                        btnupload.disabled = false;
                        
                    };

                    function dateselect(){
                        var from = document.getElementById("from");
                        var to = document.getElementById("to");
                        var from1 = document.getElementById("from1");
                        var to1 = document.getElementById("to1");

                        if (from.value > to.value) {
                        alert("Please select a valid date");
                        from.focus();
                        } else if (from.value == "" || to.value == ""){
                            alert("Please select a valid date");
                        from.focus();
                        } else {
                            window.location.href="?id=<?php echo $_GET['id'] ?>" +"&from=" + from.value + "&to=" + to.value;
                            
                        }
                                    
                    }
                </script>
                 <?php }}?>
</body>
     <!-- Modal3 Alert -->
     <div class="modal fade" id="modal3" tabindex="-1" role="dialog" aria-labelledby="payrollLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="payrollLabel">Select Date First</h5>
        </div>
        <div class="modal-body">

        From:<input type="date" id="from" class="form-control">
        <br>
        To: <input type="date" id="to" class="form-control">

        </div>
        <div class="modal-footer">
          <a href="../Manager/Salary.php" class="btn btn-secondary">Return</a>
          <button class="btn btn-primary" onclick="dateselect();">Proceed</button>
          
        </div>
      </div>
    </div>
  </div>
 <!-- Modal1 Alert -->
 <div class="modal fade" id="modal1" tabindex="-1" role="dialog" aria-labelledby="payrollLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="payrollLabel">Warning</h5>
        </div>
        <div class="modal-body">
        <?php $resultbas = mysqli_query($conn, "SELECT DISTINCT CONCAT(Last_Name, ', ',First_Name, ' ',Middle_Name) AS Fullname FROM user WHERE UserID = $id");?>
        <?php while ($row3 = mysqli_fetch_array($resultbas)) { ?>
            <h5>We've Detected that you didn't setup a basic salary for <b><?php echo $row3['Fullname'] ?></b></h5>
        </div>
        <div class="modal-footer">
          <a href="../Manager/Salary.php" class="btn btn-secondary">Return</a>
          <a href="BasicSalary.php?id=<?php echo $_GET["id"] ?>" class="btn btn-primary">Proceed to Basic Salary</a>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>

   <!-- Modal2 Alert -->
 <div class="modal fade" id="modal2" tabindex="-1" role="dialog" aria-labelledby="payrollLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="payrollLabel">Warning</h5>
        </div>
        <div class="modal-body">
        <?php $resultded = mysqli_query($conn, "SELECT DISTINCT CONCAT(Last_Name, ', ',First_Name, ' ',Middle_Name) AS Fullname FROM user WHERE UserID = $id");?>
        <?php while ($row4 = mysqli_fetch_array($resultded)) { ?>
            <h5>We've Detected that you didn't setup a deductions (SSS, PhilHealth etc.) for <b><?php echo $row4['Fullname'] ?></b>. If deductions are not applicable kindly set it to 0.</h5>
        </div>
        <div class="modal-footer">
          <a href="../Manager/Salary.php" class="btn btn-secondary">Return</a>
          <a href="Deductions.php?id=<?php echo $_GET["id"] ?>" class="btn btn-primary">Proceed to Deductions</a>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>



        <!-- jQuery CDN - Slim version (=without AJAX) -->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
        <!-- Popper.JS -->
        
        <!-- Bootstrap JS -->
            <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

            <?php if($show_modal1):?>
            <script> 
                $('#modal1').modal({backdrop: 'static', keyboard: false})  
                $('#modal1').modal('show');
                </script>
            <?php endif;?>

            <?php if($show_modal2):?>
            <script> 
                $('#modal2').modal({backdrop: 'static', keyboard: false})  
                $('#modal2').modal('show');
                </script>
            <?php endif;?>

            <?php if($show_modal3):?>
            <script> 
                $('#modal3').modal({backdrop: 'static', keyboard: false})  
                $('#modal3').modal('show');
                </script>
            <?php endif;?>

            
</html>