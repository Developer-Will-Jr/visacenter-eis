<?php
require_once "../db/DBConn.php";

$userid = $_SESSION["id"];

$date = date('Y-m-d');

$in = "";
$out = "";
$sql16 = "SELECT * FROM `emp_attendance` WHERE emp_num = '{$_SESSION["id"]}' AND curr_date = '$date'";
$result16 = $conn->query($sql16);
if($result16 = mysqli_query($conn, $sql16)){
    if(mysqli_num_rows($result16) > 0){
        $in = "Yes";
    }
}
$sql17 = "SELECT * FROM `emp_attendance` WHERE emp_num = '{$_SESSION["id"]}' AND curr_date = '$date' AND time_out != ''";
$result17 = $conn->query($sql17);
if($result17 = mysqli_query($conn, $sql17)){
    if(mysqli_num_rows($result17) > 0){
        $out = "Yes";
    }
}


?>

<div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">

        <div class="sidebar-header" >
                <img src="../Images/logo.webp" alt="">
                <h4><u>The Visa Center</u></h4>
                <span>Employee Information System</span>
            </div>

            <ul class="list-unstyled components">
                <li <?php if ($currentPage === 'Dashboard') {echo 'class="active"';} ?>>
                    <a href="Dashboard.php">
                    <img src="../Styles/Icons/dashboard.png" alt="">
                        <span class="hide"> Dashboard</span>
                    </a>
                </li>
                <li <?php if ($currentPage === 'Account') {echo 'class="active"';} ?>>
                     <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                     <img src="../Styles/Icons/account.png" alt="">
                        <span class="hide">My Account</span>
                    </a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li <?php if ($currentSub === 'Account1') {echo 'class="active under"';} ?>>
                          <a href="EmployeeAttendancePage.php"><img src="../Styles/Icons/attendance.png" alt=""> Attendance</a>
                      </li>
                        <li <?php if ($currentSub === 'Account2') {echo 'class="active under"';} ?>>
                            <a href="EmployeeSalary.php"><img src="../Styles/Icons/payslip.png" alt=""> Salary</a>
                        </li>
                        <li <?php if ($currentSub === 'Account3') {echo 'class="active under"';} ?>>
                            <a href="EmployeeLeave.php"><img src="../Styles/Icons/leave.png" alt="" width="35px"> My Leave</a>
                        </li>
                    </ul> 
                </li>
                </li>
                <li <?php if ($currentPage === 'Tasks') {echo 'class="active"';} ?>>
                    <a href="Task_List.php">
                    <img src="../Styles/Icons/task.png" alt="">
                        <span class="hide">Projects</span>
                    </a>
                </li>
                <li>
                <a href="#" class="logout" data-toggle="modal" data-target="#logout1">
                    <img src="../Styles/Icons/logout.png" alt="">
                        <span class="hide">Logout</span>
                    </a>
                </li>
        </nav>
    
        <!-- Page Content  -->
        <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" class="btn btn-info" id="sidebarCollapse">
                        <i class="fas fa-align-left"></i>
                        <span>Menu</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>
                    <div>
                        <ul class="nav navbar-nav ml-auto">
                            <li class="nav-item">
                                <a href="EmployeeNotification.php" data-toggle="tooltip" title="Notifications">
                                    <i class="fas fa-bell bell <?php if ($currentPage === 'Notifications') {echo 'bellactive"';} ?>"></i>
                                    
                                </a>
                            </li>
                            <li class="nav-item">
                            
                            <?php $resultnav = mysqli_query($conn, "SELECT * FROM `user` WHERE UserID = $userid"); ?>
                            <?php while ($rownav = mysqli_fetch_array($resultnav)) { ?>
                                <a class="nav-link <?php if ($currentPage === 'Profile') {echo 'active"';} ?>" href="ProfilePage.php" data-toggle="tooltip" title="View Profile"><?php echo $rownav['Last_Name'] ?> | <?php echo $rownav['Position'] ?></a>
                            </li>
                            <li class="nav-item">
                                <img src="../Images/upload/<?php echo $rownav['ProfilePicture'] ?>" class="rounded-circle" width="50" height="50" alt="Black and White Portrait of a Man" loading="lazy"/>
                            </li>
                            <?php } ?>
                    </div>
                </div>
                </nav>

    <!-- End of Navbar -->
    
    <div class="modal fade" id="logout1" tabindex="-1" role="dialog" aria-labelledby="viewLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title" id="viewLabel">Confirmation</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <?php if($in == "Yes" && $out != "Yes"){ ?>
                <h5>We've detected that you didn't time out yet.</h5>
            <?php } ?>
            <h5>Are You Sure You Want to Logout?</h5>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <?php if($in == "Yes" && $out != "Yes"){ ?>
            <form action="../Attendance/save.php" method="post">
                
                <input type="hidden" name="id_num" value="<?php echo $_SESSION["id"]; ?>">
                <input type="hidden" name="location" id="location" value="<?php echo $loc ?>">
                <button type="submit" class="btn btn-danger" value="Time out" id="id_num2">Time Out</button>
                <button type="button" class="btn btn-danger" onclick="window.location.href = '../Logout.php'">Logout</button>
            <?php } else { ?>
          <button type="button" class="btn btn-danger" onclick="window.location.href = '../Logout.php'">Logout</button>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>

  