<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task History</title>
    <!-- Stylesheets -->
    
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="../Styles/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../Styles/style.css">
    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>


</head>
<body>

    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">

            <div class="sidebar-header logo" >
                <img src="../../Images/logo.webp" alt="">
                <h4 href=""> The Visa Center</h4>
                <span style="font-size: 20px">Employee Information System</span>
                
            </div>

            <ul class="list-unstyled components">
                <li>
                    <a href="../Dashboard.php">
                        <i class="fas fa-home logo"></i>
                        <span class="hide"> Dashboard</span>
                    </a>
                </li>
                <li>
                     <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-users logo"></i>
                        <span class="hide">Account</span>
                    </a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li>
                          <a href="../EmployeeAttendancePage.php"><i class="fas fa-calendar-check"></i> Attendance</a>
                      </li>
                        <li>
                            <a href="../EmployeeSalary.php"><i class="fas fa-credit-card"></i> Salary</a>
                        </li>
                        <li>
                            <a href="#"><i class="fas fa-sign-out-alt"></i> Leave</a>
                        </li>
                    </ul> 
                </li>
                </li>
                <li class="active">
                    <a href="../EmployeeTaskPage.php">
                        <i class="fas fa-copy logo"></i>
                        <span class="hide">Tasks</span>
                    </a>
                </li>
                <li>
                    <a href="../../index.php" class="logout">
                        <i class="fas fa-power-off logo"></i>
                        <span class="hide">Logout</span>
                    </a>
                </li>
        </nav>
    
        <!-- Page Content  -->
        <div id="content">

        <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" class="btn btn-info" id="sidebarCollapse">
                        <i class="fas fa-align-left"></i>
                        <span>Menu</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>
                    <div>
                        <ul class="nav navbar-nav ml-auto">
                            <li class="nav-item">
                                <a href="../EmployeeNotification.php" data-toggle="tooltip" title="Notifications">
                                    <i class="fas fa-bell bell"></i>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../ProfilePage.php" data-toggle="tooltip" title="View Profile">Wilma | HR</a>
                            </li>
                            <li class="nav-item">
                                <img src="../../Images/women.jpg" class="rounded-circle" height="50" alt="Black and White Portrait of a Man" loading="lazy"/>
                            </li>
                        </ul>
                    </div>
                </div>
        </nav>

    <!-- End of Navbar -->
    <div class="content rounded bg-white" style="padding: 1em;">
    <a href="../EmployeeTaskPage.php" class="btn btn-outline-primary btn-lg mb-2" data-toggle="tooltip" data-placement="top" title="Return"><i class="fas fa-arrow-left"></i></a>
    <table class="table table-bordered">
        <thead class="thead-dark">
            <tr>
                <th colspan="7" class="text-center"><h3>Tasks</h1</th>
            </tr>
        </thead>        
        <tbody>
          <tr>
            <th scope="col">Given By:</th>
            <th scope="col">Subject</th>
            <th scope="col">Details</th>
            <th scope="col">Status</th>
          </tr>
          <tr>
            <td>HR William</td>
            <td>Introduction</td>
            <td>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos voluptatum commodi quisquam delectus magnam.</td>
            <td>Submitted</td>
          </tr>

        </tbody>
      </table>
      </div>
      </div>
      </div>
      
    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    
    <!-- Bootstrap JS -->
        <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
        $(function () {
        $('[data-toggle="tooltip"]').tooltip()
        });
    </script>
</body>
</html>