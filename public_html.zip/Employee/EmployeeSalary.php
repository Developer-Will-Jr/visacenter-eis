<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] !== 1){
  header("location: ../index.php");
  exit;
}


// Include config file
require_once "../db/DBConn.php";

$sql = "SELECT payroll.Payroll_id, DATE_FORMAT(payroll.Date_submitted, '%M %d, %Y') as date, payroll.Total FROM `user` INNER JOIN payroll ON user.UserID = payroll.UserID WHERE user.UserID = '{$_SESSION["id"]}'";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salary</title>
    <?php $currentPage = 'Account'; ?>
    <?php $currentSub = 'Account2'; ?>
    
    <?php include '../plugins.php'; ?>

</head>
<body>

<?php require_once('EmployeeNavbar.php'); ?>

    <div class="content rounded bg-white" style="padding: 1em;">

    <div class="col-lg-13">
    <div class="card card-outline card-primary">
		<div class="card-header">
			<h4 class="text-center">PAYSLIP</h4>
		</div>
		
		<div class="card-body">
    <?php if($result = mysqli_query($conn, $sql)){ ?>
    <table class="table table-hover" id="payslip">
        <thead class="text-center">
          <tr>
            <th scope="col">Date</th>
            <th scope="col">Amount</th>
            <th scope="col">Action</th>
          </tr>
        </thead>        
        <tbody>
        <?php while($row = mysqli_fetch_array($result)){ ?>
          <tr class="text-center">
            <td><?php echo $row['date'] ?></td>
            <td>₱ <?php echo $row['Total'] ?></td>
            <td><a href="../Others/PayslipResult.php?id=<?php echo $row['Payroll_id'] ?>" class="btn btn-outline-primary"><i class="fas fa-eye"></i></a></td>
          </tr>
        </tbody>
      </table>
      <?php }} ?>
      </div>
      </div>
      </div>

      <?php include '../footer.php'; ?>
        <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });

        $(document).ready(function() {
		        $('#payslip').dataTable({"order": [],
              "aoColumns": [
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": false }
          ]
            })
          })
    </script>
</body>
</html>