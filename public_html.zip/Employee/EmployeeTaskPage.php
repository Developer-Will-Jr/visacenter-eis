<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] !== 1){
  header("location: ../index.php");
  exit;
}


// Include config file
require_once "../db/DBConn.php";

$userid = "";
// For Table
$sql = "SELECT * FROM `tasklist`";
$result = $conn->query($sql);

$taskVal = "";
if(isset($_GET['v']) && !empty($_GET['v'])){
  $taskVal = $_GET['v'];
} elseif(isset($_GET['e']) && !empty($_GET['e'])){
  $taskVal = $_GET['e'];
} elseif(isset($_GET['r']) && !empty($_GET['r'])){
   $taskVal = $_GET['r'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasks</title>
    <?php $currentPage = 'Tasks'; ?>
    <?php $currentSub = ''; ?>
    <!-- Stylesheets -->
    
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="../Styles/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Styles/style.css">
    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>

    <style>
        .taskbox{
            border: 1px solid black;
            border-radius: 15px;
            padding: 1em;
        }
    </style>
</head>
<body>

    <?php require_once('EmployeeNavbar.php'); ?>
    <div class="content rounded bg-white" style="padding: 1em;">
        <a href="Others/TaskHistory.php" class="btn btn-outline-secondary mb-3 float-right">Task History</a>
        <?php 
    if($result = mysqli_query($conn, $sql)){
    if(mysqli_num_rows($result) > 0){
echo  '<table class="table table-bordered">';
echo  '<thead class="thead-dark">';
echo        '<tr>';
echo            '<th colspan="6" class="text-center"><h3>List of Task</h3></th>';
echo        '</tr>';
echo    '</thead>';
echo    '<tbody>';
echo      '<tr class="text-center">';
echo        '<th scope="col">Department</th>';
echo        '<th scope="col">Subject</th>';
echo        '<th scope="col">Date Posted</th>';
echo        '<th scope="col">Task Status</th>';
echo        '<th scope="col">Deadline</th>';
echo        '<th scope="col">Action</th>';
echo      '</tr>';
while($row = mysqli_fetch_array($result)){
  if($row['Priority_level'] == "Low"){
echo      '<tr style="background-color: green; color:white;"}>';
  } elseif ($row['Priority_level'] == "Medium"){
    echo      '<tr style="background-color: orange; color:white;"}>';
   } elseif ($row['Priority_level'] == "High"){
    echo      '<tr style="background-color: red; color:white;"}>';
   }
echo        '<td>' . $row['Department'] . '</td>';
echo        '<td>' . $row['Subject'] . '</td>';
echo        '<td>' . $row['Post_Date'] . '</td>';
echo        '<td>' . $row['Status'] . '</td>';
echo        '<td>' . $row['Deadline'] . '</td>';
echo        '<td class="text-center">';
echo            '<button id="' . $row['TaskID'] . '" class="btn btn-light" name="view1" title="View Details" onClick="taskV(this.id)"><i class="fas fa-eye"></i></button>';
echo        '</td>';
echo      '</tr>';
}
echo    '</tbody>';
echo  '</table>';
// Free result set
mysqli_free_result($result);
} else{
  echo  '<table class="table table-bordered">';
  echo  '<thead class="thead-dark">';
  echo        '<tr>';
  echo            '<th colspan="5" class="text-center"><h3>My Leave Requests</h3></th>';
  echo        '</tr>';
  echo    '</thead>';
  echo        '<tr>';
  echo          '<td colspan="4">';
  echo          '<div class="alert alert-danger"><em>No records were found.</em></div>';
  echo            '</div>';
  echo          '</td>';
  echo '</table>';
}
} else{
echo "Oops! Something went wrong. Please try again later.";
}
?>
      </div>
      </div>
      </div>


        <!-- View Task -->
  <div class="modal fade" id="view" tabindex="-1" role="dialog" aria-labelledby="viewLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="viewLabel">Employee Full Details</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <table class="table table-bordered">
            <?php $resulta = mysqli_query($conn, "SELECT * FROM `tasklist` WHERE TaskID = '$taskVal'"); ?>
                <tbody>
                <?php while ($row2 = mysqli_fetch_array($resulta)) { ?>
                  <tr>
                      <th>Department</th>
                      <td><?php echo $row2['Department'] ?></td>
                    </tr>
                  <tr>
                      <th>Subject</th>
                      <td><?php echo $row2['Subject'] ?></td>
                    </tr>
                    <tr>
                      <th>Details</th>
                      <td><?php echo $row2['Details'] ?></td>
                    </tr>
                    <tr>
                      <th>Posted By</th>
                      <td><?php echo $row2['Posted_by'] ?></td>
                    </tr>
                    <tr>
                      <th>Priority Level</th>
                      <td><?php echo $row2['Priority_level'] ?></td>
                    </tr>
                    <tr>
                      <th>Status</th>
                      <td><?php echo $row2['Status'] ?></td>
                    </tr>
                    <tr>
                      <th>Date Posted</th>
                      <td><?php echo $row2['Post_Date'] ?></td>
                    </tr>
                    <tr>
                      <th>Deadline</th>
                      <td><?php echo $row2['Deadline'] ?></td>
                    </tr>
                    <tr>
                        <th>Attach File</th>
                        <td><input type="file" name="" id=""></td>
                    </tr>
                  </tbody>
              </table>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <form action="">
            <button type="submit" class="btn btn-success">Mark as Done</button>
          </form>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>
  <!-- End of View Task -->



    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    
    <!-- Bootstrap JS -->
        <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
    //For Showing Modal
    var urlcheck = window.location.href;
      var url = new URL(urlcheck);
      if (url.searchParams.get("v")!=null){
          $('#view').modal('show');
      } else if (url.searchParams.get("e")!=null){
          $('#edit').modal('show');
      }else if (url.searchParams.get("r")!=null){
          $('#cancel').modal('show');
      }else if (url.searchParams.get("s")!=null){
          $('#success').modal('show');
      }

      // For Putting a Value in URL
      function taskV(clicked_id)
      { 
        if (clicked_id != null){
          var val = clicked_id;
          window.location.href="http://localhost/VisaCenter-EIS-Final/Employee/EmployeeTaskPage.php" + "?v=" + val;
        }
        
      };

      function taskE(clicked_id)
      { 
        if (clicked_id != null){
          var val = clicked_id;
          window.location.href="http://localhost/VisaCenter-EIS-Final/Employee/EmployeeTaskPage.php" + "?e=" + val;
        }
      };

      function taskR(clicked_id)
      { 
        if (clicked_id != null){
          var val = clicked_id;
          window.location.href="http://localhost/VisaCenter-EIS-Final/Employee/EmployeeTaskPage.php" + "?r=" + val;
        }
      };
    </script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });

        n =  new Date();
        y = n.getFullYear();
        m = n.getMonth() + 1;
        d = n.getDate();
        document.getElementById("date").innerHTML = m + "/" + d + "/" + y;

        

    </script>
    
</body>
</html>