<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rate Performance</title>
</head>
<body>
    <nav>
        <a href="ProfilePage.php">My Profile</a>
        <a href="EmployeeAttendancePage.php">My Attendance</a>
        <a href="EmployeeTaskPage.php">My Tasks</a>
        <a href="EmployeeRatePerformancePage.php" aria-disabled="true">Rate Other Employee</a>
        <a href="../HomePage.php" style="float:right">Logout</a>
    </nav>
    
    <h1>Rate Performance Page</h1>
    <form action="">
        <input type="date" name="" id="" placeholder="Date">
        <textarea name="" id="" cols="30" rows="10" placeholder="Reason of Leave"></textarea>
        <input type="submit" value="Submit">
    </form>
</body>
</html>