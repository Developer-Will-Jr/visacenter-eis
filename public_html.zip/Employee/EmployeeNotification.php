<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] !== 1){
  header("location: ../index.php");
  exit;
}

// Include config file
require_once "../db/DBConn.php";

$fill_info = "";
$fill_others = "";

// For Table
$sql = "SELECT n.NotificationID, n.Title, n.Details, n.Department,  DATE_FORMAT(n.Date, '%M %d, %Y') as Date, n.Attachment, u.Last_Name, u.Position, u.ProfilePicture FROM `notification` n INNER JOIN user u ON n.Posted_by = u.UserID WHERE n.Department = '{$_SESSION["branch"]}' OR n.Department = 'All Departments' ORDER BY n.Date DESC;";
$result = $conn->query($sql);


$sql2 = "SELECT IF(Address = '' OR Email = '' OR Contact = '', 'YES', 'NO') as Info, IF(SSS = '' OR Philhealth = '' OR Pag_Ibig = '' OR Bank_Name = '' OR Bank_Account = '', 'YES', 'NO') as Others FROM `user` WHERE UserID = '{$_SESSION["id"]}'";
$result2 = $conn->query($sql2);
if($result2 = mysqli_query($conn, $sql2)){
    if(mysqli_num_rows($result2) > 0){
        while($row2 = mysqli_fetch_array($result2)){
        $fill_info = $row2['Info'];
        $fill_others = $row2['Others'];
         }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications</title>
    <?php $currentPage = 'Notifications'; ?>
    <?php $currentSub = ''; ?>
    <!-- Stylesheets -->
    
    <?php include '../plugins.php'; ?>

    <style>
        .notifbox{
            border-radius: 15px;
            padding: 1.5em;
            background-color: #254E58;
            color: #fff;
        }
        p{
            color: #fff;
            margin-left: 1em; 
        }
        hr{
            background-color: #fff;
        }

        
    </style>
</head>
<body>

<?php require_once('EmployeeNavbar.php'); ?>
    <div class="container rounded bg-white" style="padding: 1em;">
    <h1 class="text-center">Notifications</h1>
    <br>
    <?php if ($fill_info == "YES"){ ?>
    <div class="notifbox">
        <h4>!!! Please finish filling up your information. <a href="ProfilePage.php" style="color: yellow; text-decoration: underline;">Click Here</a></h4>
        <p></p>
        <hr>
        <h6>This notification is system generated</h6>
    </div> <br>
    <?php } ?>

    <?php if ($fill_others == "YES"){ ?>
    <div class="notifbox" style="background-color: #0E4D92;">
        <h4>!!! Please finish filling up your other details. <a href="ProfilePage.php" style="color: yellow; text-decoration: underline;">Click Here</a></h4>
        <p></p>
        <hr>
        <h6>This notification is system generated</h6>
    </div> <br>
    <?php } ?>
    
    <?php

if($result = mysqli_query($conn, $sql)){
    if(mysqli_num_rows($result) > 0){
      while($row = mysqli_fetch_array($result)){

echo    '<div class="notifbox">';
echo        '<h4>' . $row['Title'] . '</h4>';
echo        '<p>' . $row['Details'] . '</p>';
echo        '<p>Attachment: <a style="color: lightblue; text-decoration: underline;" href="../Files/notification/'.$row['Attachment'].'">'.$row['Attachment'].'</a></p>';
echo        '<hr>';
echo        '<h6><img src="../Images/upload/' .$row["ProfilePicture"]. '" alt="" width="4%" style="border-radius: 50%;"> ' . $row['Last_Name'] . ' | ' . $row['Position'] . ' <span style="float: right;">Date Posted: ' . $row['Date'] . '</span></h6>';
echo    '</div> <br>';

      }
mysqli_free_result($result);
} 
} else{
echo "Oops! Something went wrong. Please try again later.";
}
?>
      </div>
      
      </div>
      </div>

    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    
    <!-- Bootstrap JS -->
        <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
</body>
</html>