<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] !== 1){
  header("location: ../index.php");
  exit;
}

// Include config file
require_once "../db/DBConn.php";

$userid = $_SESSION["id"];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile</title>
    <?php $currentPage = 'Profile'; ?>
    <?php $currentSub = ''; ?>
    
    <?php include '../plugins.php'; ?>

    <style>
        .profilepic .pp-btn {
            opacity: 0.8;
            position: absolute;
            top: 20%;
            left: 75%;
            transform: translate(-50%, -50%);
            -ms-transform: translate(-50%, -50%);
            background-color: #01a049;
            color: #fff;
            font-size: 18px;
            border: none;
            cursor: pointer;
            border-radius: 50%;
            transition: all 300ms linear;
        }
        
        .profilepic .pp-btn:hover {
            
            background-color: #f9f9f3;
            color: #01a049;

        }
    </style>

</head>
<body>

<?php require_once('EmployeeNavbar.php'); ?>

    <div class="container rounded bg-white">
    <?php $result = mysqli_query($conn, "SELECT * FROM `user` WHERE UserID = $userid"); ?>
        <div class="row">
        <?php while ($row = mysqli_fetch_array($result)) { ?>
            <div class="col-md-3 border-right">
                <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                <div class="profilepic"><img class="rounded-circle mt-5" width="150px" height="150px" src="../Images/upload/<?php echo $row['ProfilePicture'] ?>"><button class="pp-btn" data-toggle="modal" data-target="#profilepic" title="Edit Profile Picture"><i class="fas fa-pencil-alt"></i></button></div>
                <span class="font-weight-bold"><?php echo $row['First_Name'] . ' ' . $row['Middle_Name'] . ' ' . $row['Last_Name'] . ' ' . $row['Suffix'] ?></span>
                <span><?php echo $row['Position'] ?></span>
                <span class="text-black-50 mt-2"><?php echo $row['Email'] ?><br><?php echo $row['Status'] ?><br>Since: <?php echo $row['Employed_Date'] ?> <br> <?php echo $row['Branch'] ?></span></div>
            </div>
            <div class="col-md-5 border-right">
                <div class="p-3 py-2">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="text-right">Personal Details</h4>
                    </div>
                    <div class="row mt-2">
                        <div class="col-md-6"><label class="labels">First Name:</label><input type="text" class="form-control" value="<?php echo $row['First_Name'] ?>" readonly></div>
                        <div class="col-md-6"><label class="labels">Middle Name:</label><input type="text" class="form-control" placeholder="Middle Name" value="<?php echo $row['Middle_Name'] ?>" readonly></div>
                        <div class="col-md-6 mt-1"><label class="labels">Surname:</label><input type="text" class="form-control" value="<?php echo $row['Last_Name'] ?>" readonly></div>
                        <div class="col-md-6 mt-1"><label class="labels">Suffix:</label><input type="text" class="form-control" value="<?php echo $row['Suffix'] ?>" readonly></div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-md-6"><label class="labels">Birthdate:</label><input type="text" class="form-control" placeholder="" value="<?php echo $row['Birthdate'] ?>" readonly></div>
                        <div class="col-md-6"><label class="labels">Gender:</label><input type="text" class="form-control" placeholder="" value="Male" readonly></div>
                        <div class="col-md-6 mt-2"><label class="labels">Contact Number:</label><input type="text" class="form-control" placeholder="" value="<?php echo $row['Contact'] ?>" readonly></div>
                        <div class="col-md-6 mt-2"><label class="labels">Position:</label><input type="text" class="form-control" placeholder="" value="<?php echo $row['Position'] ?>" readonly></div>
                        <div class="col-md-12 mt-2"><label class="labels">Email:</label><input type="text" class="form-control" placeholder="" value="<?php echo $row['Email'] ?>" readonly></div>
                        <div class="col-md-12 mt-2"><label class="labels">Complete Address:</label><textarea type="text" class="form-control" placeholder="" style="resize: none;" readonly><?php echo $row['Address'] ?> </textarea></div>
                    </div>
                    
                    <div class="mt-3 text-center"><button class="btn btn-primary btn-block profile-button" data-toggle="modal" data-target="#personal">Edit My Personal Details</button></div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-3 py-2">
                    <h4 class="text-left mb-4">Additional Details</h4>
                        <div class="row mb-3">
                            <label for="exampleInputEmail1">Username:</label>
                            <input type="text" class="form-control" value="<?php echo $row['Username'] ?>" disabled>
                        </div>
                        <div class="mt-3 mb-2 text-center"><button class="btn btn-primary btn-block profile-button" data-toggle="modal" data-target="#exampleModal">Change Password</button></div>

                        <div class="row mb-3">
                            <label for="exampleInputEmail1">SSS #:</label>
                            <input type="text" class="form-control" value="<?php echo $row['SSS'] ?>" disabled>
                        </div>
                        <div class="row mb-3">
                            <label for="exampleInputEmail1">PhilHealth #:</label>
                            <input type="text" class="form-control" value="<?php echo $row['Philhealth'] ?>" disabled>
                        </div>
                        <div class="row mb-3">
                            <label for="exampleInputEmail1">Pag-IBIG #:</label>
                            <input type="text" class="form-control" value="<?php echo $row['Pag_Ibig'] ?>" disabled>
                        </div>
                        <div class="mt-3 text-center"><button class="btn btn-secondary btn-block profile-button" data-toggle="modal" data-target="#bank">View My Bank Account Details</button></div>
                        <div class="mt-3 text-center"><button class="btn btn-primary btn-block profile-button" data-toggle="modal" data-target="#details">Edit Details</button></div>

                  </div>
            </div>
        </div>
    </div>
     <!-- Modal UserPass -->
     <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Change Password</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                <form action="../db/manage_employee.php" method="post" onsubmit="return validateForm()" novalidate>
                    <label for="exampleInputEmail1">Current Password:</label>
                    <input type="password" id="mypass2" class="form-control" value="" name="password">
                    <div class="form-check mt-1">
                    <input type="checkbox" class="form-check-input" onclick="showPassword2()">
                    <label class="form-label" for="exampleCheck1">Show Password</label>
                    </div>
                    <br>
                    <label for="exampleInputEmail1">New Password:</label>
                    <input type="password"  id="mypass" class="form-control" value="" name="password">
                    <div class="form-check mt-1">
                    <input type="checkbox" class="form-check-input" onclick="showPassword()">
                    <label class="form-label" for="exampleCheck1">Show Password</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" id="mypassword" value="<?php echo $_SESSION["password"] ?>">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="hidden" name="userid" value="<?php echo $row['UserID'] ?>">
                    <button type="submit" class="btn btn-primary" name="userpass">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>



    <!-- Modal Personal Details -->
    <div class="modal fade" id="personal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Personal Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="../db/manage_employee.php" method="post">
                    <label for="exampleInputEmail1">Contact Number:</label>
                    <input type="number" class="form-control" value="<?php echo $row['Contact'] ?>" name="contact">
                    <br>
                    <label for="exampleInputEmail1">Email:</label>
                    <input type="email" class="form-control" value="<?php echo $row['Email'] ?>" name="email">
                    <br>
                    <div><label class="labels">Complete Address:</label><textarea type="text" class="form-control" style="resize: none;" name="address"><?php echo $row['Address'] ?> </textarea></div>
                    <input type="hidden" name="userid" value="<?php echo $row['UserID'] ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" name="personal">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>

        <!-- Modal Additional Details -->
        <div class="modal fade" id="details" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Personal Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="../db/manage_employee.php" method="post">
                    <label for="exampleInputEmail1">SSS #:</label>
                    <input type="text" class="form-control" value="<?php echo $row['SSS'] ?>" name="sss">
                    <br>
                    <label for="exampleInputEmail1">PhilHealth #:</label>
                    <input type="text" class="form-control" value="<?php echo $row['Philhealth'] ?>" name="philhealth">
                    <br>
                    <label for="exampleInputEmail1">Pag-IBIG #:</label>
                    <input type="text" class="form-control" value="<?php echo $row['Pag_Ibig'] ?>" name="pagibig">
                    <br>
                    <label for="exampleInputEmail1">Bank Name:</label>
                    <input type="text" class="form-control" value="<?php echo $row['Bank_Name'] ?>" name="bankname">
                    <br>
                    <label for="exampleInputEmail1">Bank Account #:</label>
                    <input type="text" class="form-control" value="<?php echo $row['Bank_Account'] ?>" name="bankacc">
                    <input type="hidden" name="userid" value="<?php echo $row['UserID'] ?>">
                    <br>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" name="addpersonal">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Bank Details -->
    <div class="modal fade" id="bank" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Personal Details</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <label for="exampleInputEmail1">Bank Name:</label>
                    <input type="text" class="form-control" value="<?php echo $row['Bank_Name'] ?>" readonly>
                    <br>
                    <label for="exampleInputEmail1">Bank Account #:</label>
                    <input type="text" class="form-control" value="<?php echo $row['Bank_Account'] ?>" readonly>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Profile Picture -->
    <div class="modal fade" id="profilepic" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Profile Picture</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                <form action="../db/manage_employee.php" method="post" enctype="multipart/form-data">
                <label class="form-label">Profile Picture</label>
		        <input type="file" class="form-control" name="pp">
                <input type="hidden" name="userid" value="<?php echo $row['UserID'] ?>">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" name="profilepic">Save changes</button>
                </div>
                </form>
            </div>
        </div>
    </div>


        <?php } ?>

   
    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    
    <!-- Bootstrap JS -->
        <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
    <script>
        function validateForm() {
            var letter = /[a-zA-Z]/; 
            var number = /[0-9]/;
            var password = document.getElementById("mypassword");
            var mypass2 = document.getElementById("mypass2");
            var newpass = document.getElementById("mypass");

            if (mypass2.value != password.value) {
              alert("Incorrect Current Password! Please Try Again");
              mypass2.value = "";
              mypass2.focus();
              return false;
            } else if (!number.test(newpass.value)){
                alert("Password should contain atleast one number! Please Try Again");
                newpass.value = "";
                newpass.focus();
                return false;
            }  else if (!letter.test(newpass.value)){
                alert("Password should be a combination of numbers and letters! Please Try Again");
                newpass.value = "";
                newpass.focus();
                return false;
            } else if (newpass.value.length < 6){
                alert("Password should be atleast 6 character long! Please Try Again");
                newpass.value = "";
                newpass.focus();
                return false;
            }
        }

        function showPassword() {
          var x = document.getElementById("mypass");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }
        function showPassword2() {
          var x = document.getElementById("mypass2");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }
    </script>
</body>
</html>