<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["access"]) || $_SESSION["access"] !== 1){
  header("location: ../index.php");
  exit;
}

// Include config file
require_once "../db/DBConn.php";

$onsite = "No";
$time_in = "No";
$date = date('Y-m-d');
$done = "No";
$onleave = "NO";
$endleave = "";
$leavetype = "";
$totaLeave = "";
$absent = "No";

$mon = $tue = $wed = $thu = $fri = $sat = $sun = $scheduled = "";

$show_modal1 = false;
if ($_SESSION["password"] == "123"){
    $show_modal1 = true;
}


$sql2 = "SELECT COUNT(*) AS TotalProject FROM project_list WHERE user_ids LIKE '%{$_SESSION['id']}%'";
$result2 = $conn->query($sql2);

$sql3 = "SELECT DATE_FORMAT(evaluation.Date, '%M %d, %Y') as Date, evaluation.EvaluationID, evaluation.Rating FROM evaluation INNER JOIN user ON evaluation.UserID = user.UserID WHERE evaluation.UserID = '{$_SESSION["id"]}'";
$result3 = $conn->query($sql3);

$sql5 = "SELECT * FROM branch_ipaddress WHERE IPAddress = '{$_SESSION["ip"]}'";
$result5 = $conn->query($sql5);
if($result5 = mysqli_query($conn, $sql5)){
    if(mysqli_num_rows($result5) > 0){
        $onsite = "Yes";
        while($row5 = mysqli_fetch_array($result5)){
        $loc = $row5['Branch'];
         }
    } else {
        $loc = "WFH";
    }
}

$sql6 = "SELECT * FROM `emp_attendance` WHERE emp_num = '{$_SESSION["id"]}' AND curr_date = '$date'";
$result6 = $conn->query($sql6);
if($result6 = mysqli_query($conn, $sql6)){
    if(mysqli_num_rows($result6) > 0){
        $time_in = "Yes";
    }
}

$sql7 = "SELECT * FROM `emp_attendance` WHERE emp_num = '{$_SESSION["id"]}' AND curr_date = '$date' AND time_out != ''";
$result7 = $conn->query($sql7);
if($result7 = mysqli_query($conn, $sql7)){
    if(mysqli_num_rows($result7) > 0){
        $done = "Yes";
    }
}

$sql8 = "SELECT Category, DATE_FORMAT(EndLeave, '%M %d, %Y') as EndLeave, IF(CURDATE() >= StartLeave AND CURDATE() <= EndLeave, 'YES', 'NO') as value FROM `leavelist` WHERE UserID = '{$_SESSION["id"]}' AND Status = 'Approved'";
$result8 = $conn->query($sql8);
if($result8 = mysqli_query($conn, $sql8)){
    if(mysqli_num_rows($result8) > 0){
        while($row8 = mysqli_fetch_array($result8)){
        $onleave = $row8['value'];
        $endleave = $row8['EndLeave'];
        $leavetype = $row8['Category'];
         }
    }
}

$sql9 = "SELECT COUNT(*) as totalapprove FROM `leavelist` WHERE UserID = '{$_SESSION['id']}' AND Status = 'Approved'";
$result9 = $conn->query($sql9);
if($result9 = mysqli_query($conn, $sql9)){
  if(mysqli_num_rows($result9) > 0 ){
    while($row9 = mysqli_fetch_array($result9)){
      $totalapprove = $row9['totalapprove'];
      if($row9['totalapprove'] == ""){
        $totalapprove = "0";
      }
       }
  }
}

$sql10 = "SELECT * FROM work_schedule WHERE UserID = '{$_SESSION["id"]}'";
$result10 = $conn->query($sql10);
if($result10 = mysqli_query($conn, $sql10)){
    if(mysqli_num_rows($result10) > 0){
        while($row10 = mysqli_fetch_array($result10)){
            $mon = $row10['Monday'];
            $tue = $row10['Tuesday'];
            $wed = $row10['Wednesday'];
            $thu = $row10['Thursday'];
            $fri = $row10['Friday'];
            $sat = $row10['Saturday'];
            $sun = $row10['Sunday'];
            $scheduled = $row10[date('l')];
         }
    }
}


$sql11 = "SELECT CONCAT(u.Last_Name, ', ',u.First_Name,' ',u.Suffix, ' ',u.Middle_Name) AS Fullname, u.Position, u.Branch, u.UserID, SUM(Sales_Gain) as sales_per_employee FROM user u INNER JOIN sales s USING (UserID) WHERE u.Branch = '{$_SESSION["branch"]}' Group by u.UserID ORDER BY s.Sales_Gain DESC LIMIT 3";
$result11 = $conn->query($sql11);

$sql12 = "SELECT * FROM emp_absent WHERE UserID = '{$_SESSION["id"]}' AND DATE(Date) = '$date'";
$result12 = $conn->query($sql12);
if($result12 = mysqli_query($conn, $sql12)){
    if(mysqli_num_rows($result12) > 0){
        while($row12 = mysqli_fetch_array($result12)){
            $absent = "Yes";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <?php $currentPage = 'Dashboard'; ?>
    <?php $currentSub = ''; ?>
    <!-- Stylesheets -->
    
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="../Styles/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Styles/style.css">
    <link rel="stylesheet" href="../Styles/dashboard.css">
    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>


</head>
<body>

    <?php require_once('EmployeeNavbar.php'); ?>
    
    <div class="cards">
    <a class="card stretched-link text-decoration-none" href="EmployeeLeave.php">
                <div class="card-content" style="text-align: center;">
                    <div class="number"><?php echo $totalapprove ?> </div>
                    <div class="card-name">Total Approved Leave</div>
                </div>
            </a>
            <a class="card stretched-link text-decoration-none" href="EmployeeAttendancePage.php">
                <div class="card-content">
                    <div class="number">95%</div>
                    <div class="card-name">Attendance Rate</div>
                </div>
            </a>
            
            <a class="card stretched-link text-decoration-none" href="Task_List.php">
                <div class="card-content">
                    <div class="number"><?php while($row2 = mysqli_fetch_array($result2)){ echo $row2['TotalProject']; }?></div>
                    <div class="card-name">Pending Project/s</div>
                </div>
            </a>
        </div>
        <div class="charts">
            <div class="chart">
                <h2>Top Sales in <?php echo $_SESSION['branch'] ?> Branch</h2>
                <table class="table table-bordered">     
            <tbody>
              <?php if(mysqli_num_rows($result11) > 0){ $i = 1; while($row11 = mysqli_fetch_array($result11)){ ?>
              <tr class="text-center">
                <th scope="col">Rank</th>
                <th scope="col">Name (Last, First, Middle, Suffix)</th>
                <th scope="col">Position</th>
                <th scope="col">Overall Score</th>
              </tr>
              <tr class="text-center">
                <td><?php echo $i; $i++; ?></td>
                <td><?php echo $row11['Fullname'];  ?></td>
                <td><?php echo $row11['Position'];  ?></td>
                <td><?php if($row11['sales_per_employee'] != ""){ echo $row11['sales_per_employee'];  }else { echo '0'?><?php }?></td>
              </tr>
                <?php }} else {?>
                    <tr class="text-center">
                        <th>No Records Available</th>
                    </tr>
                    <?php } ?>
            </tbody>
          </table>
            </div>
            <?php if(mysqli_num_rows($result3) > 0){ while($row3 = mysqli_fetch_array($result3)){ ?>
            <a class="chart stretched-link text-decoration-none" target="_blank" style="text-align:center;" href="../Others/Result.php?id=<?php echo $row3['EvaluationID']; ?>">
                <h2>My Evaluation Rating</h2>
                <div class="number mt-3 mb-3"><?php echo $row3['Rating']; ?>%</div>
                <h2>Date Evaluated:</h2>
                <h2><?php echo $row3['Date']; ?></h2>
                <?php } ?>
            </a>
            <?php } else { ?>
            <div class="chart text-center">
                    <h2>My Evaluation Rating</h2>
                    <div class="number mt-3 mb-3">N/A</div>
                    <h2>Date Evaluated:</h2>
                    <h2>N/A</h2>
                    
            </div>
            <?php } ?>
            
            <?php if ($onleave == "NO"){ ?>
            <?php if ($_SESSION["WORK_OFFSITE"] == "Yes" || $onsite == "Yes"){ ?>
            <?php if ($scheduled == 1){?>
            <?php if ($absent == "No"){ ?>
            <div class="cardtime">
                <a class="timebutt stretched-link text-decoration-none" href="EmployeeAttendancePage.php">
                    <h2 style="color: #888;">Attendance</h2>
                    <span id="time" class="mb-2" style="color: #299b63;"></span>
                    <div class="container d-flex justify-content-center">
                <div class="row">
                    <div class="col">
                <form action="../Attendance/save.php" method="post">
                
                <input type="hidden" name="id_num" value="<?php echo $_SESSION["id"]; ?>">
                <input type="hidden" name="location" id="location" value="<?php echo $loc ?>">
             
                <?php if ($time_in == "No"){ ?>
                    <input type="submit" value="Time in" class="btn btn-lg btn-success" id="id_num1"> 
                    <?php } elseif ($time_in == "Yes" && $done == "No") { ?>
                    <input type="submit" value="Time out" class="btn btn-lg btn-danger" id="id_num2">
                    <?php } else { ?>
                    <h5>Attendance Done for Today!</h5>
                    <?php } ?>
                </form>
            </div>
        </div>
    </div>
                </a>
            </div>
            <?php } else { ?>
            <div class="cardtime">
            <a class="timebutt stretched-link text-decoration-none" href="EmployeeAttendancePage.php">
                <h2 style="color: #888;">Attendance Not Available</h2>
                <div class="container d-flex justify-content-center">
            <div class="row">
            <div class="col" style="color: #299b63;">
                <h5>You are mark as absent today.</h5>
            </div>
            </div>
            </div>
        </a>
        </div>
        <?php }?>
        <?php } else { ?>
            <div class="cardtime">
            <a class="timebutt stretched-link text-decoration-none" href="ProfilePage.php">
                <h2 style="color: #888;">Attendance Not Available</h2>
                <div class="container d-flex justify-content-center">
            <div class="row">
            <div class="col" style="color: #299b63;">
                <h5>You are not scheduled today</h5>
            </div>
            </div>
            </div>
        </a>
        </div>
        <?php }?>
        <?php } else { ?>
        <div class="cardtime">
            <a class="timebutt stretched-link text-decoration-none" href="#">
                <h2 style="color: #888;">Attendance Not Available</h2>
                <div class="container d-flex justify-content-center">
            <div class="row">
            <div class="col" style="color: #299b63;">
                <h5>We've detected that you are not onsite today</h5>
                <h6>For any problem or inquiries kindly contact HR Manager or System Administrator</h6>
            </div>
            </div>
            </div>
        </a>
        </div>
        
        <?php } ?>
        
        <?php } else { ?>

            <div class="cardtime">
            <a class="timebutt stretched-link text-decoration-none" href="MyLeave.php">
                <h2 style="color: #888;">You Are On-Leave</h2>
                <div class="container d-flex justify-content-center">
            <div class="row">
            <div class="col" style="color: #299b63;">
                <h5>Your Leave Will End on <?php echo $endleave ?></h5>
                <h5>Type: <?php echo $leavetype ?></h5>
            </div>
            </div>
            </div>
        </a>
        </div>
        <?php } ?>
        

        <!-- Modal1 Alert -->

   <div class="modal fade" id="modal1" tabindex="-1" role="dialog" aria-labelledby="payrollLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="payrollLabel"><b> Welcome to Employee Information System!</b></h5>
        </div>
        <div class="modal-body">
            <h5>Since this is your first time using the system, we recommend to change your Password first for security and set up your profile.</h5>
        </div>
        <div class="modal-footer">
          <a href="../Logout.php" class="btn btn-danger">Logout</a>
          <a href="ProfilePage.php" class="btn btn-primary">Proceed to Profile Page</a>
        </div>
      </div>
    </div>
  </div>

    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    
    <!-- Bootstrap JS -->
        <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

        <?php if($show_modal1):?>
            <script> 
                $('#modal1').modal({backdrop: 'static', keyboard: false})  
                $('#modal1').modal('show');
                </script>
            <?php endif;?>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
        
        var datetime = new Date();
console.log(datetime);
document.getElementById("time").textContent = datetime;
function refreshTime() {
  const timeDisplay = document.getElementById("time");
  const dateString = new Date().toLocaleString();
  const formattedString = dateString.replace(", ", " - ");
  timeDisplay.textContent = formattedString;
}
  setInterval(refreshTime, 1000);
    </script>

</body>
</html>