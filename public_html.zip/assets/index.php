<?php
// include autoloader
require_once 'dompdf/autoload.inc.php';

// import dompdf class into global namespace
use Dompdf\Dompdf;

// instantiate dompdf class
$dompdf = new Dompdf();


// pdf content
$html = '<head></head><body><h1 style="font-weight: 700; color: rgb(40, 180, 40);"><img src="../Images/logo.webp"> The Visa Center</h1>
<hr style="margin: 1px 0">
<p><b>TVC International Immigration Services</b></p>
<div style="padding: 2rem">
<table class="table bg">
    <thead>
        <th colspan="4" class="text-center headers"><br><h4>SALARY SLIP</h4></th>
        <th colspan="2" class="text-center headers"><h6>PRIVATE AND <br> CONFIDENTIAL</h6></th>
    </thead>
    <tbody>
        <tr>
            <td>Employee Name:</td>
            <td style="text-transform: uppercase"><b></b></td>
            <td colspan="2">Payment Slip for the month of:</td>
            <td colspan="2">March 1-15, 2023</td>
        </tr>
        <tr>
            <td>Date of Joining:</td>
            <td></td>
            <td colspan="2">Days Worked:</td>
            <td colspan="2" style="text-transform: uppercase">15 DAYS</td>
        </tr>
        <tr>
            <td>Department:</td>
            <td style="text-transform: uppercase"></td>
            <td colspan="2">Bank Name:</td>
            <td colspan="2">BANCO DE ORO (BDO)</td>
        </tr>
        <tr>
            <td>Designation:</td>
            <td style="text-transform: uppercase"></td>
            <td colspan="2">Bank Account #:</td>
            <td colspan="2">123-1234567</td>
        </tr>
        <tr>
            <th colspan="2" class="headers">Description</th>
            <th colspan="2" class="text-center headers">Earnings</th>
            <th colspan="2" class="text-center headers">Deduction</th>
        </tr>
        <tr>
            <td colspan="2">Basic Salary</td>
            <td width="150"></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Personal Quota</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Team Quota</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Late / Absences</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr><tr>
            <td colspan="2">SSS</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">PhilHealth</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Pag Ibig</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Cash Advance</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Total Deductions:</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2">Total:</td>
            <td rowspan="2" colspan="2"><h4> Net Salary Pay</h4></td>
            <td rowspan="2" colspan="2"><h4>Php</h4></td>
        </tr>
        <tr>
            <td colspan="2">Payment Date</td>
        </tr>
    </tbody>
</table>
<p class="text-center" style="margin-top: -10px;"><b>I hereby acknowledge and confirm that I received my salary (Net Pay) deposited to my bank account. Thank you.</b></p>
<p style="margin-top: 5em;" class="text-center">Employee Signature:_________________________ &nbsp;&nbsp;&nbsp; HR Dept:_________________________</p>
    </div>
    <hr>
    <h6 class="text-center">Employee Information System Generated. Created by QCU BSIT Students</h6></body>';

// load html
$dompdf->loadHtml($html);

// set paper size and orientation
$dompdf->setPaper('A4', 'portrait');

// render html as pdf
$dompdf->render();

// output the pdf to browser
$dompdf->stream();
?>