<?php

require('fpdf.php');
require_once "../../db/DBConn.php";

$eval  = $_POST["eval_ids"];
$value = implode(", ",$eval);

$sql = "SELECT CONCAT(user.Last_Name, ', ',user.First_Name,' ',user.Suffix, ' ',user.Middle_Name) AS Fullname, user.Position, DATE_FORMAT(user.Employed_Date, '%M %d, %Y') AS date, DATE_FORMAT(evaluation.Date, '%M %d, %Y') AS evaldate, evaluation.Attitude1, evaluation.Attitude2, evaluation.Attitude3, evaluation.Attitude4, evaluation.Attitude5, evaluation.Attitude6, evaluation.Responsibility1, evaluation.Responsibility2, evaluation.Responsibility3, evaluation.Responsibility4, evaluation.Competency1, evaluation.Competency2, evaluation.Competency3, evaluation.Competency4, evaluation.Competency5, evaluation.Comment, evaluation.Rating FROM evaluation INNER JOIN user ON user.UserID = evaluation.UserID WHERE evaluation.EvaluationID IN ($value)";
$result = $conn->query($sql);

// Instanciation of inherited class
$pdf = new FPDF();

if($result = mysqli_query($conn, $sql)){
	while($row = mysqli_fetch_array($result)){

$pdf->AddPage();
	// Logo
	$pdf->Image('../../Images/BigLogo.png',47,4,12);
	// Arial bold 28
	$pdf->SetFont('Arial','B', 18);
	// Move to the right
	$pdf->Cell(10);
    // Set color
    $pdf->SetTextColor(40, 180, 40);
	// Title
	$pdf->Cell(180,0,'The Visa Center Evaluation Form', 0, 0, 'C');
    $pdf->SetTextColor(40, 40, 40);
	// Line break
	$pdf->Ln(10);
// COLOR
$pdf->setFillColor(0,255,147); 
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(32, 8, 'Employee Name', 1, 0, '', 0);
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(90, 8, ''.$row['Fullname'], 1, 0, '', 0);
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(30, 8, 'Date', 1, 0, '', 0);
$pdf->Cell(30, 8, ' '.$row['evaldate'], 1, 0, '', 0);
$pdf->Ln();
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(32, 8, 'Date of Joining', 1, 0, '', 0);
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(90, 8, ''.$row['date'], 1, 0, '', 0);
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(30, 8, '', 'R', 0, '', 0);
$pdf->Cell(30, 8, '', 'R', 0, '', 0);
$pdf->Ln();
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(32, 8, 'Position', 1, 0, '', 0);
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(90, 8, ''.$row['Position'], 1, 0, '', 0);
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(30, 8, 'Total Rating:', 'R', 0, '', 0);
$pdf->SetFont('Arial','B', 12);
$pdf->Cell(30, 8, ' '.$row['Rating'].'%', 'R', 0, '', 0);
$pdf->Ln();
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(32, 8, 'Department', 1, 0, '', 0);
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(90, 8, '', 1, 0, '', 0);
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(30, 8, '', 'BR', 0, '', 0);
$pdf->Cell(30, 8, '', 'BR', 0, '', 0);
$pdf->Ln();
$pdf->Cell(182, 8, 'Evaluation Sheet', 1, 0, 'C', 1);
$pdf->Ln();
$pdf->SetFont('Arial','', 7.5);
$pdf->Cell(60, 8, '', 1, 0, 'C', 0);
$pdf->Cell(24.4, 8, 'Deficient', 1, 0, 'C', 0);
$pdf->Cell(24.4, 8, 'Below Standard', 1, 0, 'C', 0);
$pdf->Cell(24.4, 8, 'Below Expectation', 1, 0, 'C', 0);
$pdf->Cell(24.4, 8, 'Above Standard', 1, 0, 'C', 0);
$pdf->Cell(24.4, 8, 'Outstanding', 1, 0, 'C', 0);
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, 'No', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Criteria', 1, 0, '', 0);
$pdf->Cell(24.4, 8, '1', 1, 0, 'C', 0);
$pdf->Cell(24.4, 8, '2', 1, 0, 'C', 0);
$pdf->Cell(24.4, 8, '3', 1, 0, 'C', 0);
$pdf->Cell(24.4, 8, '4', 1, 0, 'C', 0);
$pdf->Cell(24.4, 8, '5', 1, 0, 'C', 0);
$pdf->Ln();
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(10, 8, '1', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Attitude', 1, 0, '', 0);
$pdf->Cell(24.4, 8, '', 'B', 0, 'C', 0);
$pdf->Cell(24.4, 8, '', 'B', 0, 'C', 0);
$pdf->Cell(24.4, 8, '', 'B', 0, 'C', 0);
$pdf->Cell(24.4, 8, '', 'B', 0, 'C', 0);
$pdf->Cell(24.4, 8, '', 'BR', 0, 'C', 0);
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, '1.1', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Customer Service Oriented', 1, 0, '', 0);
$pdf->SetFont('Arial','', 16);
$att1 = $row['Attitude1'];
if ($att1 == 1){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att1 == 2){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att1 == 3){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att1 == 4){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att1 == 5){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, '1.2', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Communication', 1, 0, '', 0);
$pdf->SetFont('Arial','', 16);
$att2 = $row['Attitude2'];
if ($att2 == 1){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att2 == 2){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att2 == 3){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att2 == 4){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att2 == 5){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, '1.3', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Eagerness to learn', 1, 0, '', 0);
$pdf->SetFont('Arial','', 16);
$att3 = $row['Attitude3'];
if ($att3 == 1){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att3 == 2){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att3 == 3){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att3 == 4){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att3 == 5){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, '1.4', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Teamwork', 1, 0, '', 0);
$pdf->SetFont('Arial','', 16);
$att4 = $row['Attitude4'];
if ($att4 == 1){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att4 == 2){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att4 == 3){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att4 == 4){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att4 == 5){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, '1.5', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Leadership', 1, 0, '', 0);
$pdf->SetFont('Arial','', 16);
$att5 = $row['Attitude5'];
if ($att5 == 1){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att5 == 2){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att5 == 3){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att5 == 4){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att5 == 5){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, '1.6', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Work under pressure', 1, 0, '', 0);
$pdf->SetFont('Arial','', 16);
$att6 = $row['Attitude6'];
if ($att6 == 1){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att6 == 2){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att6 == 3){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att6 == 4){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($att6 == 5){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
$pdf->Ln();
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(10, 8, '2', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Responsibility', 1, 0, '', 0);
$pdf->Cell(24.4, 8, '', 'B', 0, 'C', 0);
$pdf->Cell(24.4, 8, '', 'B', 0, 'C', 0);
$pdf->Cell(24.4, 8, '', 'B', 0, 'C', 0);
$pdf->Cell(24.4, 8, '', 'B', 0, 'C', 0);
$pdf->Cell(24.4, 8, '', 'BR', 0, 'C', 0);
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, '2.1', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Attendance/Punctuality', 1, 0, '', 0);
$pdf->SetFont('Arial','', 16);
$res1 = $row['Responsibility1'];
if ($res1 == 1){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res1 == 2){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res1 == 3){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res1 == 4){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res1 == 5){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, '2.2', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Work on deadline', 1, 0, '', 0);
$pdf->SetFont('Arial','', 16);
$res2 = $row['Responsibility2'];
if ($res2 == 1){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res2 == 2){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res2 == 3){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res2 == 4){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res2 == 5){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, '2.3', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Willingness to take responsibilities', 1, 0, '', 0);
$pdf->SetFont('Arial','', 16);
$res3 = $row['Responsibility3'];
if ($res3 == 1){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res3 == 2){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res3 == 3){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res3 == 4){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res3 == 5){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, '2.4', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Open to feedback', 1, 0, '', 0);
$pdf->SetFont('Arial','', 16);
$res4 = $row['Responsibility4'];
if ($res4 == 1){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res4 == 2){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res4 == 3){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res4 == 4){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($res4 == 5){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
$pdf->Ln();
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(10, 8, '3', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Competency', 1, 0, '', 0);
$pdf->Cell(24.4, 8, '', 'B', 0, 'C', 0);
$pdf->Cell(24.4, 8, '', 'B', 0, 'C', 0);
$pdf->Cell(24.4, 8, '', 'B', 0, 'C', 0);
$pdf->Cell(24.4, 8, '', 'B', 0, 'C', 0);
$pdf->Cell(24.4, 8, '', 'BR', 0, 'C', 0);
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, '3.1', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Creativity', 1, 0, '', 0);
$pdf->SetFont('Arial','', 16);
$com1 = $row['Competency1'];
if ($com1 == 1){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com1 == 2){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com1 == 3){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com1 == 4){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com1 == 5){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, '3.2', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Productivity', 1, 0, '', 0);
$pdf->SetFont('Arial','', 16);
$com2 = $row['Competency2'];
if ($com2 == 1){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com2 == 2){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com2 == 3){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com2 == 4){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com2 == 5){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, '3.3', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Ability to work independently	', 1, 0, '', 0);
$pdf->SetFont('Arial','', 16);
$com3 = $row['Competency3'];
if ($com3 == 1){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com3 == 2){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com3 == 3){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com3 == 4){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com3 == 5){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, '3.4', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Initiative', 1, 0, '', 0);
$pdf->SetFont('Arial','', 16);
$com4 = $row['Competency4'];
if ($com4 == 1){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com4 == 2){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com4 == 3){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com4 == 4){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com4 == 5){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(10, 8, '3.5', 1, 0, 'R', 0);
$pdf->Cell(50, 8, 'Effective problem solving skills', 1, 0, '', 0);
$pdf->SetFont('Arial','', 16);
$com5 = $row['Competency5'];
if ($com5 == 1){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com5 == 2){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com5 == 3){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com5 == 4){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
if ($com5 == 5){$pdf->Cell(24.4, 8, '/', 1, 0, 'C', 0);} else {$pdf->Cell(24.4, 8, '', 1, 0, 'C', 0);}
$pdf->Ln();
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(182, 8, 'Comment / Recommendation', 0, 0, '', 0);
$pdf->Ln();
$pdf->SetFont('Arial','', 8);
$pdf->Cell(182, 40, '  '.$row['Comment'], 1, 0, '', 0);
	}
}
$pdf->Output();
?>
