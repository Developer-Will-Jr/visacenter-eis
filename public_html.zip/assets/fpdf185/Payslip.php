<?php

require('fpdf.php');

require_once "../../db/DBConn.php";
$payroll  = $_POST["payroll_ids"];
$value = implode(", ",$payroll);

$sql = "SELECT CONCAT(user.Last_Name, ', ',user.First_Name,' ',user.Suffix, ' ',user.Middle_Name) AS Fullname, user.Position, DATE_FORMAT(user.Employed_Date, '%M %d, %Y') AS date, user.Bank_Name, user.Bank_Account, DATE_FORMAT(payroll.Date_From, '%M %d') AS paymentfrom, DATE_FORMAT(payroll.Date_To, '%M %d, %Y') AS paymentto, DATE_FORMAT(payroll.Date_submitted, '%M %d, %Y') AS paymentdate, payroll.* FROM payroll INNER JOIN user ON user.UserID = payroll.UserID WHERE Payroll_id IN ($value)";
$result = $conn->query($sql);

// Instanciation of inherited class
$pdf = new FPDF();
if($result = mysqli_query($conn, $sql)){
	while($row = mysqli_fetch_array($result)){
		
$pdf->SetFont('Times','',12);
$pdf->AddPage();
	// Logo
	$pdf->Image('../../Images/BigLogo.png',3,6,25);
	// Arial bold 28
	$pdf->SetFont('Arial','B', 28);
	// Move to the right
	$pdf->Cell(18);
    // Set color
    $pdf->SetTextColor(40, 180, 40);
	// Title
	$pdf->Cell(10,15,'The Visa Center');
    // for hr
    $pdf->Line(1, 32, 210-1, 32);
    //New line
    $pdf->SetFont('Arial','B', 12);
	// Move to the right
	$pdf->Cell(-33);
    // Set color
    $pdf->SetTextColor(40, 40, 40);
	// Title
	$pdf->Cell(10,50,'TVC International Immigration Services');
	// Line break
	$pdf->Ln(35);
// COLOR
$pdf->setFillColor(0,255,147); 
$pdf->SetFont('Arial','B', 16);
//Cell (width, height, text, border, end line, text align, fill color)
$pdf->Cell(130, 20, 'SALARY PAYSLIP', 1, 0, 'C', 1);
$pdf->SetFont('Arial','', 10);
$pdf->Cell(60, 20, 'PRIVATE AND CONFIDENTIAL', 1, 0, 'C', 1);
$pdf->Ln();
$pdf->Cell(31.66, 10, 'Employee Name:', 1, 0, '', 0);
$pdf->SetFont('Arial','B', 8);
$pdf->Cell(46.66, 10, ''.$row['Fullname'], 1, 0, '', 0);
$pdf->SetFont('Arial','', 10);
$pdf->Cell(51.66, 10, 'Payment Slip for the month of:', 1, 0, '', 0);
$pdf->Cell(60, 10, $row['paymentfrom'].' - '.$row['paymentto'], 1, 0, '', 0);
$pdf->Ln();
$pdf->Cell(31.66, 10, 'Date of Joining:', 1, 0, '', 0);
$pdf->Cell(46.66, 10, ''.$row['date'], 1, 0, '', 0);
$pdf->Cell(51.66, 10, 'Days Worked:', 1, 0, '', 0);
$pdf->Cell(60, 10, $row['Days'].' Days', 1, 0, '', 0);
$pdf->Ln();
$pdf->Cell(31.66, 10, 'Department:', 1, 0, '', 0);
$pdf->Cell(46.66, 10, '!!! dept', 1, 0, '', 0);
$pdf->Cell(51.66, 10, 'Bank Name:', 1, 0, '', 0);
$pdf->Cell(60, 10, ''.$row['Bank_Name'], 1, 0, '', 0);
$pdf->Ln();
$pdf->Cell(31.66, 10, 'Designation:', 1, 0, '', 0);
$pdf->SetFont('Arial','', 8);
$pdf->Cell(46.66, 10, ''.$row['Position'], 1, 0, '', 0);
$pdf->SetFont('Arial','', 10);
$pdf->Cell(51.66, 10, 'Bank Account #:', 1, 0, '', 0);
$pdf->Cell(60, 10, ''.$row['Bank_Account'], 1, 0, '', 0);
$pdf->Ln();
$pdf->SetFont('Arial','B', 10);
$pdf->Cell(78.32, 10, 'Description', 1, 0, '', 1);
$pdf->Cell(51.68, 10, 'Earnings', 1, 0, 'C', 1);
$pdf->Cell(60, 10, 'Deduction', 1, 0, 'C', 1);
$pdf->Ln();
$pdf->SetFont('Arial','', 10);
$pdf->Cell(78.32, 10, 'Basic Salary', 1, 0, '', 0);
$pdf->Cell(25.84, 10, ''.$row['Basic_salary'], 1, 0, '',0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(30, 10, '', 1, 0, '',0);
$pdf->Cell(30, 10, '', 1, 0, '',0);
$pdf->Ln();
$pdf->Cell(78.32, 10, 'Personal Quota', 1, 0, '', 0);
$pdf->Cell(25.84, 10, ''.$row['Personal_Quota'], 1, 0, '',0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(30, 10, '', 1, 0, '',0);
$pdf->Cell(30, 10, '', 1, 0, '',0);
$pdf->Ln();
$pdf->Cell(78.32, 10, 'Team Quota', 1, 0, '', 0);
$pdf->Cell(25.84, 10, ''.$row['Team_Quota'], 1, 0, '',0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(30, 10, '', 1, 0, '',0);
$pdf->Cell(30, 10, '', 1, 0, '',0);
$pdf->Ln();
$pdf->Cell(78.32, 10, 'Late / Absences', 1, 0, '', 0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(30, 10, ''.$row['Late_Absences'], 1, 0, '',0);
$pdf->Cell(30, 10, '', 1, 0, '',0);
$pdf->Ln();
$pdf->Cell(78.32, 10, 'SSS', 1, 0, '', 0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(30, 10, ''.$row['SSS'], 1, 0, '',0);
$pdf->Cell(30, 10, '', 1, 0, '',0);
$pdf->Ln();
$pdf->Cell(78.32, 10, 'PhilHealth', 1, 0, '', 0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(30, 10, ''.$row['PhilHealth'], 1, 0, '',0);
$pdf->Cell(30, 10, '', 1, 0, '',0);
$pdf->Ln();
$pdf->Cell(78.32, 10, 'Pag Ibig', 1, 0, '', 0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(30, 10, ''.$row['Pag_Ibig'], 1, 0, '',0);
$pdf->Cell(30, 10, '', 1, 0, '',0);
$pdf->Ln();
$pdf->Cell(78.32, 10, 'Others', 1, 0, '', 0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(30, 10, ''.$row['Others'], 1, 0, '',0);
$pdf->Cell(30, 10, '', 1, 0, '',0);
$pdf->Ln();
$pdf->Cell(78.32, 10, 'Cash Advance', 1, 0, '', 0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(30, 10, ''.$row['Cash_Advance'], 1, 0, '',0);
$pdf->Cell(30, 10, '', 1, 0, '',0);
$pdf->Ln();
$pdf->Cell(78.32, 10, 'Total Deductions:', 1, 0, '', 0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(30, 10, ''.$row['Total_Deduction'], 1, 0, '',0);
$pdf->Cell(30, 10, '', 1, 0, '',0);
$pdf->Ln();
$pdf->Cell(78.32, 10, 'Bonus', 1, 0, '', 0);
$pdf->Cell(25.84, 10, ''.$row['Bonus'], 1, 0, '',0);
$pdf->Cell(25.84, 10, '', 1, 0, '',0);
$pdf->Cell(30, 10, '', 1, 0, '',0);
$pdf->Cell(30, 10, '', 1, 0, '',0);
$pdf->Ln();
$pdf->Cell(78.32, 10, 'Total:', 1, 0, '', 0);
$pdf->SetFont('Arial','B', 12);
$pdf->Cell(51.68, 20, 'Net Salary Pay', 1, 0, '',0);
$pdf->Cell(60, 20, 'Php '.$row['Total'], 1, 0, '',0);
$pdf->Ln();
$pdf->SetFont('Arial','', 10);
$pdf->Cell(78.32, -10, 'Payment Date: '.$row['paymentdate'], 1, 0, '', 0);
$pdf->Cell(51.68, 0, '', 0, 0, '',0);
$pdf->Cell(30, 0, '', 0, 0, '',0);
$pdf->Ln();
$pdf->SetFont('Arial','B', 10);
$pdf->Cell(190,10,'I hereby acknowledge and confirm that I received my salary (Net Pay) deposited to my bank account. Thank you.', 0, 0, 'C', 0);
$pdf->Ln();

$pdf->SetFont('Arial','', 10);
$pdf->Cell(120,21,'Employee Signature:________________________', 0, 0, 'C', 0);
$pdf->Cell(40,21,'HR Dept:________________________', 0, 0, 'C', 0);
$pdf->Ln();
// Position at 1.5 cm from bottom
	}
}
$pdf->Output();
?>
