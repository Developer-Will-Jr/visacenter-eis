<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["SystemAdmin"]) || $_SESSION["SystemAdmin"] !== true){
  header("location: ../index.php");
  exit;
}

// Include config file
require_once "../db/DBConn.php";

$sql = "SELECT CONCAT(Last_Name, ', ',First_Name,' ',Suffix, ' ',Middle_Name) AS Fullname, Position, Branch, DATE_FORMAT(Employed_Date, '%M %d, %Y') AS Employed_Date FROM `user` ORDER BY Employed_Date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Manager</title>
    <?php $currentPage = 'Users'; ?>
    
    <?php include '../plugins.php'; ?>

</head>
<body>

<?php require_once('SysAdNavbar.php'); ?>

<div class="container rounded bg-white" style="padding: 1em;">
         <!-- Employee List Table -->
         <div class="col-lg-13">
    <div class="card card-outline card-success">
		<div class="card-header">
				<div class="card-tools">
				</div>
			<h3 class="text-center"><b>USERS</b></h3>
					<button class="btn btn-primary bg-gradient-primary btn-sm text-center" data-toggle="modal" data-target="#EmployeeForm"><i class="fa fa-plus"></i> Add New User</button>
		</div>
		
		<div class="card-body">
    
     <!-- Employee List Table -->

<?php

if($result = mysqli_query($conn, $sql)){
    if(mysqli_num_rows($result) > 0){
echo  '<table class="table table-hover" id="adduser">';
echo '<thead>';
echo      '<tr class="text-center">';
echo        '<th scope="col">Name</th>';
echo        '<th scope="col">Position</th>';
echo        '<th scope="col">Branch</th>';
echo        '<th scope="col">Employed Date</th>';
echo      '</tr>';
echo '</thead>';
echo    '<tbody>';
while($row = mysqli_fetch_array($result)){
echo      '<tr class="text-center">';
echo        '<td>' . $row['Fullname'] . '</td>';
echo        '<td>' . $row['Position'] . '</td>';
echo        '<td>' . $row['Branch'] . '</td>';
echo        '<td>' . $row['Employed_Date'] . '</td>';
echo      '</tr>';
}
echo    '</tbody>';
echo  '</table>';
// Free result set
mysqli_free_result($result);
} else{
  echo  '<table class="table table-bordered">';
  echo        '<tr>';
  echo          '<td colspan="4">';
  echo          '<div class="alert alert-danger"><em>No records were found.</em></div>';
  echo            '</div>';
  echo          '</td>';
  echo '</table>';
}
} else{
echo "Oops! Something went wrong. Please try again later.";
}
?>
     </div>




<!-- New Employee Form Modal -->
<div class="modal fade bd-example-modal-lg" id="EmployeeForm" tabindex="-1" role="dialog" aria-labelledby="EmployeeFormLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="EmployeeFormLabel">Create Account</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="post" action="../db/manage_employee.php" class="needs-validation" name="myForm" id="form1" onsubmit="return validateForm()" novalidate>
      <div class="form-row">
            <div class="form-group col-md-3">
                <label for="first">First Name</label>
                <input type="text" class="form-control" name="first" id="first" placeholder="First Name" required>
              </div>
              <div class="form-group col-md-3">
                <label for="inputEmail4">Middle Name</label>
                <input type="text" class="form-control" id="mid" name="mid" placeholder="Middle Name">
              </div>
              <div class="form-group col-md-3">
                <label for="inputEmail4">Last Name</label>
                <input type="text" class="form-control" name="last" id="last" placeholder="Last Name" required>
              </div>
              <div class="form-group col-md-3">
                <label for="inputEmail4">Suffix</label>
                <select name="suffix" placeholder="Suffix" class="form-control" required>
                  <option selected value="">N/A</option>
                  <option>Sr.</option>
                  <option>Jr.</option>
                  <option>III.</option>
                  <option>IV.</option>
                  <option>V.</option>
                  <option>VI.</option>
                  <option>VII.</option>
                  <option>VIII.</option>
                  <option>IX.</option>
                  <option>X.</option>
                  <option>XI.</option>
                  <option>XII.</option>
                  <option>XIII.</option>
                  <option>XIV.</option>
                  <option>XV.</option>
                  <option>XVI.</option>
                  <option>XVII.</option>
                  <option>XVIII.</option>
                  <option>XIX.</option>
                  <option>XX.</option>
                </select>
              </div>
              <div class="form-group col-md-3">
                <label for="inputEmail4">Birthdate</label>
                <input type="date" class="form-control" name="bday" placeholder="Birthdate" required>
              </div>
              <div class="form-group col-md-3">
                <label for="inputState">Gender</label>
                <select name="gender" class="form-control" required>
                  <option selected value="">Choose..</option>
                  <option>Male</option>
                  <option>Female</option>
                  <option>Prefer Not to Specify</option>
                </select>
              </div>
              <div class="form-group col-md-3">
                <label for="inputEmail4">Contact Number</label>
                <input type="number" class="form-control" name="contact" placeholder="Contact Number" required>
              </div>
              <div class="form-group col-md-3">
                <label for="inputEmail4">Email</label>
                <input type="email" class="form-control" name="email" placeholder="Email" required>
              </div>
            </div>
            <div class="form-group">
              <label for="inputAddress">Complete Address</label>
              <input type="text" class="form-control" name="address" placeholder="Complete Address" required>
            </div>
            <div class="form-row">
              <div class="form-group col-md-4">
                <label for="inputState">Position</label>
                <select name="position" class="form-control" required>
                <option selected="true" disabled="disabled" value="">Choose..</option>
                <?php $resultpos = mysqli_query($conn, "SELECT * FROM positions ORDER BY PositionName"); ?>
                <?php while ($row101 = mysqli_fetch_array($resultpos)) { ?>
                  <option><?php echo $row101['PositionName'] ?></option>
                  <?php } ?>
                </select>
                </select>
              </div>
              <div class="form-group col-md-4">
                <label for="inputCity">Username</label>
                <input type="text" class="form-control" name="user" required>
              </div>
              <div class="form-group col-md-4">
                <label for="inputZip">Password</label>
                <input type="password" class="form-control" name="pass" required>
              </div>
            </div>
            
            <div class="form-row ">
            <div class="form-group col-md-6">
              <label for="inputAddress">Joined Date:</label>
              <input type="date" class="form-control" name="join" min="<?php echo $date ?>" onkeydown="return false" required>
            </div>
            <div class="form-group col-md-6">
            <label for="inputState">Branch</label>
                <select name="branch" class="form-control" required>
                  <option value="" selected disabled>Select Branch</option>
            <?php $resultbra = mysqli_query($conn, "SELECT * FROM branch"); ?>
                <?php while ($row102 = mysqli_fetch_array($resultbra)) { ?>
                  <option><?php echo $row102['BranchName'] ?></option>
                  <?php } ?>
                  <option>None</option>
                </select>
            </div>
            <div class="form-group col-md-6">
              <label for="join_date">Employed Date:</label>
              <input type="date" id="join_date" name="employed_date" class="form-control <?php echo (!empty($join_date_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $join_date; ?>">
            </div>
            <div class="col-md-6">
          <label for="inputZip" class=" text-center">Please Input Your Password to Proceed:</label>
          <input type="password" class="form-control" id="mypass" placeholder="Your Password Here!" required>
          <div class="form-check mt-1">
          <input type="checkbox" class="form-check-input" onclick="showPassword()">
          <label class="form-label" for="exampleCheck1">Show Password</label>
          </div>
          </div>
            </div>
            
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" name="addadmin" class="btn btn-primary">Add New Employee</button>
      </div>
          </form>
        </div>
</div>
    </div>
  </div>
<!-- End of New Employee Form Modal -->
</body>

<?php include '../footer.php'; ?>
        <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
        $(function () {
        $('[data-toggle="tooltip"]').tooltip()
        })

        $(document).ready(function() {
		        $('#adduser').dataTable({"order": [],
              "aoColumns": [
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": true },
              { "bSortable": true }
          ]
            })
          })
    </script>

    <!-- Data Validations -->
    <script>
          (function () {
            'use strict'

            // Fetch all the forms we want to apply custom Bootstrap validation styles to
            var forms = document.querySelectorAll('.needs-validation')

            // Loop over them and prevent submission
            Array.prototype.slice.call(forms)
              .forEach(function (form) {
                form.addEventListener('submit', function (event) {
                  if (!form.checkValidity()) {
                    alert("Please fill all the required field")
                    event.preventDefault()
                    event.stopPropagation()
                  }
                  form.classList.add('was-validated')
                  
                }, false)
              })
          })()

          function validateForm() {

            var letters = /^[A-Za-z]+$/;
            var first = document.getElementById("first");
            var mid = document.getElementById("mid");
            var last = document.getElementById("last");
            var mypass = document.getElementById("mypass");
            var form1 = document.getElementById("form1");

            
            if (first.value == "") {
              alert("Please fill the Input Field");
              first.classList += " is-invalid";
              first.focus();
              return false;

            } else if (!letters.test(first.value)) {
              alert("The field should contain letters only");
              first.classList += " is-invalid";
              first.value = "";
              first.focus();
              return false;
              
            } else if (!letters.test(mid.value)) {
              alert("The field should contain letters only");
              mid.classList += " is-invalid";
              mid.value = "";
              mid.focus();
              return false;
              
            } else if (!letters.test(last.value)) {
              alert("The field should contain letters only");
              last.classList += " is-invalid";
              last.value = "";
              last.focus();
              return false;

            } else if (mypass.value != "123123123") {
              alert("Wrong Password");
              mypass.classList += " is-invalid";
              mypass.focus();
              return false;
            } else {
              
            }
          }

          function showPassword() {
          var x = document.getElementById("mypass");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }
        
        function validateForm2() {

          var letters = /^[A-Za-z]+$/;
          var first = document.getElementById("first2");
          var mid = document.getElementById("mid2");
          var last = document.getElementById("last2");
          var mypass = document.getElementById("mypass2");

          if (first.value == "") {
            alert("Please fill the Input Field");
            first.classList += " is-invalid";
            first.focus();
            return false;

          } else if (!letters.test(first.value)) {
            alert("The field should contain letters only");
            first.classList += " is-invalid";
            first.value = "";
            first.focus();
            return false;
            
          } else if (!letters.test(mid.value)) {
            alert("The field should contain letters only");
            mid.classList += " is-invalid";
            mid.value = "";
            mid.focus();
            return false;
            
          } else if (!letters.test(last.value)) {
            alert("The field should contain letters only");
            last.classList += " is-invalid";
            last.value = "";
            last.focus();
            return false;

          } else if (mypass.value != "123123123") {
            alert("Wrong Password");
            mypass.classList += " is-invalid";
            mypass.focus();
            return false;
          } else {
            
          }
          }

          function showPassword2() {
          var x = document.getElementById("mypass2");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }

    </script>
</html>

