<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["SystemAdmin"]) || $_SESSION["SystemAdmin"] !== true){
  header("location: ../index.php");
  exit;
}

// Include config file
require_once "../db/DBConn.php";

$sql = "SELECT * FROM `branch`";
$result = $conn->query($sql);

$sql2 = "SELECT * FROM `branch_ipaddress`";
$result2 = $conn->query($sql2);


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Branch</title>
    <?php $currentPage = 'Branch'; ?>
    
    <?php include '../plugins.php'; ?>

</head>
<body>

<?php require_once('SysAdNavbar.php'); ?>

<div class="container rounded bg-white" style="padding: 1em;">.

         <div class="col-lg-13">
    <div class="card card-outline card-success">
		<div class="card-header">
				<div class="card-tools">
				</div>
			<h3 class="text-center"><b>BRANCH</b></h3>
					<button class="btn btn-primary bg-gradient-primary btn-sm text-center" data-toggle="modal" data-target="#EmployeeForm"><i class="fa fa-plus"></i> Add New Branch</button>
		</div>
		
		<div class="card-body">
    
     <!-- Employee List Table -->

     <?php

if($result = mysqli_query($conn, $sql)){
    if(mysqli_num_rows($result) > 0){
echo  '<table class="table table-bordered " id="branch">';
echo  '<thead>';
echo      '<tr class="text-center">';
echo        '<th scope="col">Branch Name</th>';
echo        '<th scope="col">Branch Address</th>';
echo      '</tr>';
echo    '</thead>';
echo    '<tbody>';
while($row = mysqli_fetch_array($result)){
echo      '<tr>';
echo        '<td class="text-center">' . $row['BranchName'] . '</td>';
echo        '<td>' . $row['Address'] . '</td>';
echo        '</td>';
echo      '</tr>';
}
echo    '</tbody>';
echo  '</table>';
// Free result set
mysqli_free_result($result);
} else{
echo  '<table class="table table-bordered">';
echo  '<thead>';
echo        '<tr>';
echo            '<th colspan="2" class="text-center"><h3>Branch List</h3></th>';
echo        '</tr>';
echo    '</thead>';
echo        '<tr>';
echo          '<td colspan="2">';
echo          '<div class="alert alert-danger"><em>No branches found.</em></div>';
echo            '</div>';
echo          '</td>';
echo '</table>';
}
} else{
echo "Oops! Something went wrong. Please try again later.";
}
?>
     </div>
     </div>
    </div>

    <div class="col-lg-13">
    <div class="card card-outline card-success">
		<div class="card-header">
				<div class="card-tools">
				</div>
			<h3 class="text-center"><b>BRANCH IP ADDRESS</b></h3>
					<button class="btn btn-primary bg-gradient-primary btn-sm text-center" data-toggle="modal" data-target="#IPAddress"><i class="fa fa-plus"></i> Assigned IP Address</button>
		</div>
		
		<div class="card-body">
    
     <!-- Employee List Table -->

     <?php

if($result2 = mysqli_query($conn, $sql2)){
    if(mysqli_num_rows($result2) > 0){
echo  '<table class="table table-bordered " id="ip">';
echo  '<thead>';
echo      '<tr class="text-center">';
echo        '<th scope="col">IP Address</th>';
echo        '<th scope="col">Branch Assigned</th>';
echo      '</tr>';
echo    '</thead>';
echo    '<tbody>';
while($row2 = mysqli_fetch_array($result2)){
echo      '<tr>';
echo        '<td class="text-center">' . $row2['IPAddress'] . '</td>';
echo        '<td>' . $row2['Branch'] . '</td>';
echo        '</td>';
echo      '</tr>';
}
echo    '</tbody>';
echo  '</table>';
// Free result set
mysqli_free_result($result2);
} else{
echo  '<table class="table table-bordered">';
echo        '<tr>';
echo          '<td colspan="2">';
echo          '<div class="alert alert-danger"><em>No IP Address Assigned.</em></div>';
echo            '</div>';
echo          '</td>';
echo '</table>';
}
} else{
echo "Oops! Something went wrong. Please try again later.";
}
?>
     </div>
     </div>
    </div>




<!-- New Branch Form Modal -->
<div class="modal fade bd-example-modal" id="EmployeeForm" tabindex="-1" role="dialog" aria-labelledby="EmployeeFormLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="EmployeeFormLabel">Add Branch</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body text-center">
      <div class="text-center">
        <form action="../db/systemadmin.php" method="post" style="display: inline-block; ">
            <div class="form-row">
                <div class="form-group">
                    <label for="fname">Branch Name</label>
                    <input type="text" name="name" class="form-control" required>
                     <br>
                     <label for="fname">Branch Address</label>
                     <textarea class="form-control" name="address" rows="3" required></textarea>
                </div>
                
            </div>
            <button type="submit" class="btn btn-primary btn-block mt-4" name="addbranch">Add New Branch</button>
        </form>
        </div>
        </div>
</div>
    </div>
  </div>
<!-- End of New Branch Form Modal -->

<!-- New IP Address Form Modal -->
<div class="modal fade bd-example-modal" id="IPAddress" tabindex="-1" role="dialog" aria-labelledby="IPAddressFormLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="EmployeeFormLabel">Assigned IP Address</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body text-center">
      <div class="text-center">
        <form action="../db/systemadmin.php" method="post" style="display: inline-block; ">
            <div class="form-row">
                <div class="form-group">
                <label for="position">Branch</label>
            <select id="branch" class="form-control" name="branch">
                  <option selected="true" disabled="disabled" value="">Choose..</option>
                  <?php $resultbra = mysqli_query($conn, "SELECT * FROM branch"); ?>
                <?php while ($row102 = mysqli_fetch_array($resultbra)) { ?>
                  <option><?php echo $row102['BranchName'] ?></option>
                  <?php } ?>
                </select>
                     <br>
                    <label for="fname">Branch IP Address</label>
                    <input type="text" name="ip" class="form-control" required>
                </div>
                
            </div>
            <button type="submit" class="btn btn-primary btn-block mt-2" name="addip">Assign IP Address</button>
        </form>
        </div>
        </div>
</div>
    </div>
  </div>
<!-- End of New IP Address Form Modal -->
</body>

<?php include '../footer.php'; ?>
        <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
        $(function () {
        $('[data-toggle="tooltip"]').tooltip()
        })

        $(document).ready(function() {
		        $('#branch').dataTable({"order": [],
              "aoColumns": [
              { "bSortable": true },
              { "bSortable": true }
          ]
            })

            $('#ip').dataTable({"order": [],
              "aoColumns": [
              { "bSortable": true },
              { "bSortable": true }
          ]
            })
          })
    </script>
    </script>
</html>