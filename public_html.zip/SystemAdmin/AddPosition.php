<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["SystemAdmin"]) || $_SESSION["SystemAdmin"] !== true){
  header("location: ../index.php");
  exit;
}

// Include config file
require_once "../db/DBConn.php";

$sql = "SELECT * FROM `positions` ORDER BY Access_level DESC";
$result = $conn->query($sql);

$pVal = "";
if(isset($_GET['e']) && !empty($_GET['e'])){
  $pVal = base64_decode($_GET['e']);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Position</title>
    <?php $currentPage = 'Position'; ?>
    
    <?php include '../plugins.php'; ?>

</head>
<body>

<?php require_once('SysAdNavbar.php'); ?>

<div class="container rounded bg-white" style="padding: 1em;">
         <!-- Employee List Table -->
         <div class="col-lg-13">
    <div class="card card-outline card-success">
		<div class="card-header">
				<div class="card-tools">
				</div>
			<h3 class="text-center"><b>POSITION</b></h3>
					<button class="btn btn-primary bg-gradient-primary btn-sm text-center" data-toggle="modal" data-target="#EmployeeForm"><i class="fa fa-plus"></i> Add New Position</button>
		</div>
		
		<div class="card-body">
    
     <!-- Employee List Table -->

     <?php

if($result = mysqli_query($conn, $sql)){
    if(mysqli_num_rows($result) > 0){
echo  '<table class="table table-hover text-center" id="position">';
echo '<thead>';
echo      '<tr class="text-center">';
echo        '<th scope="col">Position Name</th>';
echo        '<th scope="col">Department</th>';
echo        '<th scope="col">Position Access Level</th>';
echo        '<th scope="col">Action</th>';
echo      '</tr>';
echo '</thead>';
echo    '<tbody>';
while($row = mysqli_fetch_array($result)){
echo      '<tr>';
echo        '<td>' . $row['PositionName'] . '</td>';
echo        '<td>' . $row['Department'] . '</td>';
echo        '<td>' . $row['Access_level'] . '</td>';
echo            '<td><button id="' . base64_encode($row['PositionID']) . '" class="btn btn-outline-success" data-toggle="modal" data-target="#edit" title="Edit" onClick="pIDE(this.id)"><i class="fas fa-pencil-alt"></i></button></td>';
echo        '</td>';
echo      '</tr>';
}
echo    '</tbody>';
echo  '</table>';
// Free result set
mysqli_free_result($result);
} else{
echo  '<table class="table table-bordered">';
echo        '<tr>';
echo          '<td colspan="3">';
echo          '<div class="alert alert-danger"><em>No position found.</em></div>';
echo            '</div>';
echo          '</td>';
echo '</table>';
}
} else{
echo "Oops! Something went wrong. Please try again later.";
}
?>
     </div>




<!-- New Employee Form Modal -->
<div class="modal fade bd-example-modal" id="EmployeeForm" tabindex="-1" role="dialog" aria-labelledby="EmployeeFormLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="EmployeeFormLabel">Add Position</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body text-center">
      <form action="../db/systemadmin.php" method="post" style="display: inline-block;">
            <div class="form-row">
                <div class="form-group">
                    <label for="fname">Position Name</label>
                    <input type="text" name="posname" class="form-control" required>
                </div>
            </div>
            <div class="form-group">
                <label for="gender">Level of Authentication</label>
                <select name="level" class="form-control" name="level" required>
                  <option selected="true" disabled="disabled" value="">Choose..</option>
                  <option value="1">1 (Employees)</option>
                  <option value="2">2 (Admins)</option>
                  <option value="3">3 (Managers)</option>
                </select>
            </div>
            <div class="form-group">
                <label for="inputState">Department</label>
                <input type="text" name="depname" class="form-control" value="" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block mt-4" name="addposition">Submit</button>
        </form>
        </div>
</div>
    </div>
  </div>

  <!-- Edit -->

<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="editLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="editLabel">Edit Position</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body text-center">
        <?php $resulte = mysqli_query($conn, "SELECT * FROM `positions` WHERE PositionID = '$pVal'"); ?>
        <form action="../db/systemadmin.php" method="post" style="display: inline-block;">
            <?php while ($row1 = mysqli_fetch_array($resulte)) { ?>
              
            <div class="form-row">
                <div class="form-group">
                    <label for="fname">Position Name</label>
                    <input type="text" name="posname" class="form-control" value="<?php echo $row1['PositionName'] ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label for="gender">Level of Authentication</label>
                <select name="level" class="form-control" name="level" required>
                <?php $acc = $row1['Access_level']?>
                  <option selected="true" disabled="disabled" value="">Choose..</option>
                  <option value="1" <?php if ($acc == '1') { echo ' selected="selected"'; } ?>>1 (Employees)</option>
                  <option value="2" <?php if ($acc == '2') { echo ' selected="selected"'; } ?>>2 (Admins)</option>
                  <option value="3" <?php if ($acc == '3') { echo ' selected="selected"'; } ?>>3 (Managers)</option>
                </select>
            </div>
            <div class="form-group">
                <label for="inputState">Department</label>
                <input type="text" name="depname" class="form-control" value="<?php echo $row1['Department'] ?>" required>
                <input type="hidden" name="posid" value="<?php echo $row1['PositionID'] ?>">
            </div>
            </div>
        <div class="modal-footer">
          <input type="number" name="leaveID" value="<?php echo $row1['PositionID'] ?>" hidden>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-success" name="editpos">Save Changes</button>
        </div>
      </form>
      <?php } ?>
      </div>
    </div>
  </div>
</body>

<?php include '../footer.php'; ?>
        <script src="../Styles/bootstrap/js/bootstrap.bundle.min.js"></script>

        <script>
          var urlcheck = window.location.href;
          var url = new URL(urlcheck);
          if (url.searchParams.get("e")!=null){
            $('#edit').modal('show');
          }
        </script>
    <script type="text/javascript">
      

        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
        $(function () {
        $('[data-toggle="tooltip"]').tooltip()
        })

        $(document).ready(function() {
		        $('#position').dataTable({"order": [],
              "aoColumns": [
              { "bSortable": true },
              { "bSortable": true }
          ]
            })
          })

          function pIDE(clicked_id)
      { 
          var val = clicked_id;

          window.location.href="?e=" + val;
         
      };
    </script>
</html>
