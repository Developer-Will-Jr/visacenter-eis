<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to login page
if(!isset($_SESSION["SystemAdmin"]) || $_SESSION["SystemAdmin"] !== true){
  header("location: ../index.php");
  exit;
}

// Include config file
require_once "../db/DBConn.php";

$sql = "SELECT COUNT(*) AS Total FROM user WHERE Access_level = 3";
$result = $conn->query($sql);

$sql2 = "SELECT COUNT(*) AS Total FROM positions";
$result2 = $conn->query($sql2);

$sql3 = "SELECT COUNT(*) AS Total FROM branch";
$result3 = $conn->query($sql3);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <?php $currentPage = 'Dashboard'; ?>
    <!-- Stylesheets -->
    
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="../Styles/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../Styles/style.css">
    <link rel="stylesheet" href="../Styles/dashboard.css">
    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
    
    <style>
        .cardbox {
            position: absolute;
        top: 50%;
        left: 80%;
        margin-right: -50%;
        transform: translate(-50%, -50%) }
    </style>
</head>
<body>

<?php require_once('SysAdNavbar.php'); ?>

<div class="cardbox">
    
<div class="cards">
            <a class="card stretched-link text-decoration-none" href="AddManager.php">
                <div class="card-content" style="text-align: center;">
                <div class="number"> <?php while($row = mysqli_fetch_array($result)){ echo $row['Total']; }?></div>
                    <div class="card-name">Number of Executives in the Company</div>
                </div>
            </a>
            </div>
            <div class="cards"> 
            <a class="card stretched-link text-decoration-none" href="AddPosition.php">
                <div class="card-content">
                    <div class="number"><?php while($row2 = mysqli_fetch_array($result2)){ echo $row2['Total']; }?></div>
                    <div class="card-name">Number of Positions in the Company</div>
                </div>
            </a>
            </div>
            <div class="cards"> 
            <a class="card stretched-link text-decoration-none" href="AddBranch.php">
                <div class="card-content">
                    <div class="number"><?php while($row3 = mysqli_fetch_array($result3)){ echo $row3['Total']; }?></div>
                    <div class="card-name">Number of Company Branches</div>
                </div>
            </a>
        </div>
        </div>
</body>
</html>