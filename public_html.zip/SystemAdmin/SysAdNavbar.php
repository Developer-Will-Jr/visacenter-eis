<div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">

            <div class="sidebar-header" >
                <img src="../Images/logo.webp" alt="">
                <h4> The Visa Center</h4>
                <hr style="background-color: #fff">
                <span style="font-size: 20px">System Administrator</span>
            </div>

            <ul class="list-unstyled components">
                <li <?php if ($currentPage === 'Dashboard') {echo 'class="active"';} ?>>
                    <a href="Home.php">
                        <img src="../Styles/Icons/dashboard.png" alt="">
                        <span class="hide"> Dashboard</span>
                    </a>
                </li>
                <li <?php if ($currentPage === 'Users') {echo 'class="active"';} ?>>
                    <a href="AddManager.php">
                        <img src="../Styles/Icons/employee.png" alt="">
                        <span class="hide"> Users</span>
                    </a>
                </li>
                <li <?php if ($currentPage === 'Position') {echo 'class="active"';} ?>>
                    <a href="AddPosition.php">
                        <img src="../Styles/Icons/people.png" alt="report">
                        <span class="hide"> Position</span>
                    </a>
                </li>
                <li <?php if ($currentPage === 'Branch') {echo 'class="active"';} ?>>
                    <a href="AddBranch.php">
                        <img src="../Styles/Icons/report.png" alt="report">
                        <span class="hide"> Branch</span>
                    </a>
                </li>
                <li>
                    <a href="../Logout.php" class="logout">
                        <img src="../Styles/Icons/logout.png" alt="">
                        <span class="hide">Logout</span>
                    </a>
                </li>
        </nav>
    
        <div id="content">