<?php

$dbServername = "localhost";
$dbusername = "u456912403_visacenter";
$dbPassword = "Icongroup2023";
$dbName = "u456912403_eis";


$conn  = mysqli_connect($dbServername, $dbusername, $dbPassword, $dbName);


if($conn === false){
    die("ERROR: Could not connect to server." . mysqli_connect_error());
}
?>

