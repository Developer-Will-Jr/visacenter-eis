<?php 
	session_start();
	
    require_once "../db/DBConn.php";

	// initialize variables
	$name = $address = $posname = $level = $salary = "";
    
    if (isset($_POST['addbranch'])) {

    // Assign and Call the form names
    $name = $_POST["name"];
    $address = $_POST["address"];

	   // Prepare an insert statement
    $sql = 'INSERT INTO branch (BranchName, Address) VALUES (?, ?)';
     
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, 'ss', $param_name, $param_address);
        
        // Set parameters
        
        $param_name = $name;
        $param_address = $address;
        
        // Attempt to execute the prepared statement
        if (mysqli_stmt_execute($stmt)){
            // Redirect to login page
            header("location: ../SystemAdmin/AddBranch.php?s=1");
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }

        // Close statement
        mysqli_stmt_close($stmt);

    }
    // Close connection
    mysqli_close($conn);
 } elseif (isset($_POST['addposition'])) {

    // Assign and Call the form names
    $posname = $_POST["posname"];
    $level = $_POST["level"];
    $department = $_POST["depname"];

	   // Prepare an insert statement
    $sql = 'INSERT INTO positions (PositionName, Department, Access_level) VALUES (?, ?, ?)';
     
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, 'sss', $param_posname, $param_dep, $param_level);
        
        // Set parameters
        
        $param_posname = $posname;
        $param_dep = $department;
        $param_level = $level;
        
        // Attempt to execute the prepared statement
        if (mysqli_stmt_execute($stmt)){
            // Redirect to login page
            header("location: ../SystemAdmin/AddPosition.php?s=1");
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }

        // Close statement
        mysqli_stmt_close($stmt);

    }
    // Close connection
    mysqli_close($conn);
 } elseif (isset($_POST['addip'])) {

    // Assign and Call the form names
    $ip = $_POST["ip"];
    $address = $_POST["branch"];

	   // Prepare an insert statement
    $sql = 'INSERT INTO `branch_ipaddress` (`IPAddress`, `Branch`) VALUES (?, ?)';
     
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, 'ss', $param_ip, $param_add);
        
        // Set parameters
        
        $param_ip = $ip;
        $param_add = $address;
        
        // Attempt to execute the prepared statement
        if (mysqli_stmt_execute($stmt)){
            // Redirect to login page
            header("location: ../SystemAdmin/AddBranch.php?s=1");
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }

        // Close statement
        mysqli_stmt_close($stmt);

    }
    // Close connection
    mysqli_close($conn);
 } elseif (isset($_POST['editpos'])) {

     // Assign and Call the form names
     $posid = $_POST["posid"];
     $posname = $_POST["posname"];
     $level = $_POST["level"];
     $department = $_POST["depname"];
 
        // Prepare an insert statement
     $sql = 'UPDATE positions SET PositionName = ?, Department = ?, Access_level = ? WHERE PositionID = ?';
      
     if($stmt = mysqli_prepare($conn, $sql)){
         // Bind variables to the prepared statement as parameters
         mysqli_stmt_bind_param($stmt, 'sssi', $param_posname, $param_dep, $param_level, $param_id);
         
         // Set parameters
         
         $param_posname = $posname;
         $param_dep = $department;
         $param_level = $level;
         $param_id = $posid;
         
         // Attempt to execute the prepared statement
         if (mysqli_stmt_execute($stmt)){
             // Redirect to login page
             header("location: ../SystemAdmin/AddPosition.php?s=1");
             
         } else{
             echo "Oops! Something went wrong. Please try again later.";
         }
 
         // Close statement
         mysqli_stmt_close($stmt);

    }
    // Close connection
    mysqli_close($conn);
 }