<?php 
	session_start();
	
    require_once "../db/DBConn.php";

	// initialize variables
	$department = $title = $details = $postdate = $posted_by = "";
    $date = date('Y-m-d');
    
    if (isset($_POST['post'])) {

    // Assign and Call the form names
    $department = $_POST["department"];
    $title = $_POST["title"];
    $postdate = $date;
    $details = $_POST["details"];
    $userid = $_SESSION["id"];

    $file_name = $_FILES['attach']['name'];
    $tmp_name = $_FILES['attach']['tmp_name'];
    if (isset($_FILES['attach']['name']) AND !empty($_FILES['attach']['name'])) {
        $file_ex = pathinfo($file_name, PATHINFO_EXTENSION);
        $file_ex_to_lc = strtolower($file_ex);

        $allowed_exs = array('jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx');
        if(in_array($file_ex_to_lc, $allowed_exs)){
           $new_file_name = uniqid($userid, true).'.'.$file_ex_to_lc;
           $file_upload_path = '../Files/notification/'.$new_file_name;
           move_uploaded_file($tmp_name, $file_upload_path);
        }
    } else {
        $new_file_name = "";
    }

	   // Prepare an insert statement
    $sql = 'INSERT INTO notification (Title, Details, Department, Posted_by, Date, Attachment) VALUES (?, ?, ?, ?, ?, ?)';
     
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, 'sssiss', $param_title, $param_details, $param_department, $param_postedby, $param_postdate, $param_attach);
        
        // Set parameters
        $param_title = $title;
        $param_department = $department;
        $param_postedby = $userid;
        $param_postdate = $postdate;
        $param_details = $details;
        $param_attach = $new_file_name;
        
        
        // Attempt to execute the prepared statement
        if (mysqli_stmt_execute($stmt)){
            $_SESSION['success'] = 1;
                    if ($_SESSION["access"] == 3){
                        header("location: ../Manager/ManagerNotifications.php");}
                        else {
                            header("location: ../admin/Notifications.php");
                        }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }

        // Close statement
        mysqli_stmt_close($stmt);

    }
    // Close connection
    mysqli_close($conn);
 } elseif (isset($_POST['removenotif'])) {

    // Assign and Call the form names

    $notifid = trim($_POST["notifid"]);

       // Prepare an insert statement
    $sql = "DELETE FROM notification WHERE NotificationID = ?";
     
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, 'i', $param_notifid);
        
        // Set parameters
        $param_notifid = $notifid;

        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            $_SESSION['success'] = 1;
            if ($_SESSION["access"] == 3){
                header("location: ../Manager/ManagerNotifications.php");}
                else {
                    header("location: ../admin/Notifications.php");
                }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }


// Close connection
mysqli_close($conn);
} elseif (isset($_POST['editnotif'])) {

    // Assign and Call the form names
    $department = $_POST["department"];
    $title = $_POST["title"];
    $postdate = $date;
    $details = $_POST["details"];
    $notifid = $_POST["notifid"];
    $userid = $_SESSION["id"];
    $notifid = trim($_POST["notifid"]);

    $file_name = $_FILES['newattach']['name'];
    $tmp_name = $_FILES['newattach']['tmp_name'];
    if (isset($_FILES['newattach']['name']) AND !empty($_FILES['newattach']['name'])) {
        $file_ex = pathinfo($file_name, PATHINFO_EXTENSION);
        $file_ex_to_lc = strtolower($file_ex);

        $allowed_exs = array('jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx');
        if(in_array($file_ex_to_lc, $allowed_exs)){
           $new_file_name = uniqid($userid, true).'.'.$file_ex_to_lc;
           $file_upload_path = '../Files/notification/'.$new_file_name;
           move_uploaded_file($tmp_name, $file_upload_path);
        }
    } else {
        $new_file_name = $_POST["currattach"];;
    }

       // Prepare an insert statement
    $sql = "UPDATE notification SET Title= ?, Details= ?, Department= ?, Date= ?, Attachment= ? WHERE NotificationID = ?";
     
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, 'sssssi', $param_title, $param_details, $param_department, $param_postdate, $param_attach, $param_notifid);
        
        // Set parameters
        $param_title = $title;
        $param_department = $department;
        $param_postdate = $postdate;
        $param_details = $details;
        $param_attach = $new_file_name;
        $param_notifid = $notifid;

        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            $_SESSION['success'] = 1;
            if ($_SESSION["access"] == 3){
                header("location: ../Manager/ManagerNotifications.php");}
                else {
                    header("location: ../admin/Notifications.php");
                }
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }
    mysqli_close($conn);
}