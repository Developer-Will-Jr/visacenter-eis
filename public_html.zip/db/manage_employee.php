<?php 
	session_start();
	
    require_once "../db/DBConn.php";

    date_default_timezone_set('Asia/Singapore');
    $currentdatetime = date("Y-m-d H:i:s");

	// initialize variables
	$fname = $mname = $lname = $suffix = $birthdate = $gender = $contact = $email = $address = $position = $username = $password = $join_date = $stat = $branch = $accstat = "";

    $id = $evalid = $comment = $a1 = $a2 = $a3 = $a4 = $a5 = $a6 = $r1 = $r2 = $r3 = $r4 = $c1 = $c2 = $c3 = $c4 = $c5 = $rate= "";
    
    $mon = 0;
    $tue = 0;
    $wed = 0;
    $thu = 0;
    $fri = 0;
    $sat = 0;
    $sun = 0;

    if (isset($_POST['addemployee'])) {

    // Assign and Call the form names
    $username = trim($_POST["user"]);
    $password = trim($_POST["pass"]);
    $fname = $_POST["first"];
    $mname = $_POST["mid"];
    $lname = $_POST["last"];
    $suffix = trim($_POST["suffix"]);
    $birthdate = trim($_POST["bday"]);
    $gender = trim($_POST["gender"]);
    $address = trim($_POST["address"]);
    $position = trim($_POST["position"]);
    $join_date = trim($_POST["join"]);
    $email = trim($_POST["email"]);
    $contact = trim($_POST["contact"]);
    $stat = trim($_POST["status"]);
    $branch = $_POST["branch"];

	   // Prepare an insert statement
    $sql = 'INSERT INTO user (First_Name, Middle_Name, Last_Name, Suffix, Birthdate, Gender, Contact, Email, Address, Position, Branch, Username, Password, Employed_Date, Status, Account_Status, Access_level) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
     
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, 'sssssssssssssssss', $param_fname, $param_mname, $param_lname, $param_suffix, $param_birthdate, $param_gender, $param_contact, $param_email, $param_address, $param_position, $param_branch, $param_username, $param_password, $param_join_date, $param_status, $param_accstatus, $param_access);
        
        // Set parameters
        $param_fname = $fname;
        $param_mname = $mname;
        $param_lname = $lname;
        $param_suffix = $suffix;
        $param_birthdate = $birthdate;
        $param_gender = $gender;
        $param_contact = $contact;
        $param_email = $email;
        $param_address = $address;
        $param_position = $position;
        $param_username = $username;
        $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
        $param_join_date = $join_date;
        $param_status = $stat;
        $param_branch = $branch;
        $param_accstatus = "Active";
        $param_access = "1";

        // Attempt to execute the prepared statement
        if (mysqli_stmt_execute($stmt)){
            $_SESSION['success'] = 1;
                    header("location: ../admin/EmployeeList.php");
                
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }


// Close connection
mysqli_close($conn);
    } elseif (isset($_POST['editemployee'])) {

        // Assign and Call the form names
        $fname = trim($_POST["first"]);
        $mname = trim($_POST["mid"]);
        $lname = trim($_POST["last"]);
        $suffix = trim($_POST["suffix"]);
        $birthdate = trim($_POST["bday"]);
        $gender = trim($_POST["gender"]);
        $address = trim($_POST["address"]);
        $position = trim($_POST["position"]);
        $join_date = trim($_POST["join"]);
        $email = trim($_POST["email"]);
        $contact = trim($_POST["contact"]);
        $usernum = trim($_POST["userid"]);
        $branch = $_POST["branch"];
        $department = "";
        
        $sel = "SELECT Department FROM positions WHERE PositionName = '$position'";
        $result9 = $conn->query($sel);
        if($result9 = mysqli_query($conn, $sel)){
            if(mysqli_num_rows($result9) > 0 ){
              while($row9 = mysqli_fetch_array($result9)){
                $department = $row9['Department'];
              }
            }
          }

           // Prepare an insert statement
        $sql = "UPDATE user SET First_Name= ?, Middle_Name= ?, Last_Name= ?, Suffix= ?, Birthdate= ?, Gender= ?, Contact= ?, Email= ?, Address= ?, Position= ?, Employed_Date= ?, Branch= ?, Department = ? WHERE UserID = ?";
         
        if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, 'sssssssssssssi', $param_fname, $param_mname, $param_lname, $param_suffix, $param_birthdate, $param_gender, $param_contact, $param_email, $param_address, $param_position, $param_join_date, $param_branch, $param_dep, $param_usernum);
            
            // Set parameters
            $param_fname = $fname;
            $param_mname = $mname;
            $param_lname = $lname;
            $param_suffix = $suffix;
            $param_birthdate = $birthdate;
            $param_gender = $gender;
            $param_contact = $contact;
            $param_email = $email;
            $param_address = $address;
            $param_position = $position;
            $param_join_date = $join_date;
            $param_accstatus = $accstat;
            $param_usernum = $usernum;
            $param_branch = $branch;
            $param_dep = $department;
    
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $mon = trim($_POST["mon"]);
                $tue = trim($_POST["tue"]);
                $wed = trim($_POST["wed"]);
                $thu = trim($_POST["thu"]);
                $fri = trim($_POST["fri"]);
                $sat = trim($_POST["sat"]);
                $sun = trim($_POST["sun"]);

                
                $sql2 = "UPDATE work_schedule SET `Monday` = '$mon', `Tuesday` = '$tue', `Wednesday` = '$wed', `Thursday` = '$thu', `Friday` = '$fri', `Saturday` = '$sat', `Sunday` = '$sun' WHERE UserID = '$usernum'";
                $conn->query($sql2);
                // Redirect to login page
                $_SESSION['success'] = 1;
                        header("location: ../Manager/List.php");
                        
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
    
            // Close statement
            mysqli_stmt_close($stmt);
        }
    
    
    // Close connection
    mysqli_close($conn);
        } elseif (isset($_POST['removeemployee'])) {

            // Assign and Call the form names
        
            $usernum = trim($_POST["userid"]);
            
            $sql= "INSERT INTO user_archive SELECT * FROM user WHERE UserID = ?";
               // Prepare an insert statement
            if($stmt = mysqli_prepare($conn, $sql)){
                // Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, 'i', $param_usernum);
                
                // Set parameters
                $param_usernum = $usernum;
        
                // Attempt to execute the prepared statement
                if(mysqli_stmt_execute($stmt)){
                    $sql2 = "DELETE FROM user WHERE UserID = '$usernum'";
                    $conn->query($sql2);
                    $_SESSION['success'] = 1;
                        header("location: ../Manager/List.php");
                
                    
                } else{
                    echo "Oops! Something went wrong. Please try again later.";
                }
        
                // Close statement
                mysqli_stmt_close($stmt);
            }
        
        
        // Close connection
        mysqli_close($conn);
    } elseif (isset($_POST['addadmin'])) {

        // Assign and Call the form names
    $username = trim($_POST["user"]);
    $password = "123";
    $fname = trim($_POST["first"]);
    $mname = trim($_POST["mid"]);
    $lname = trim($_POST["last"]);
    $suffix = trim($_POST["suffix"]);
    $birthdate = trim($_POST["bday"]);
    $gender = trim($_POST["gender"]);
    $address = trim($_POST["address"]);
    $position = trim($_POST["position"]);
    $join_date = trim($_POST["join"]);
    $email = trim($_POST["email"]);
    $contact = trim($_POST["contact"]);
    $stat = trim($_POST["status"]);
    $branch = $_POST["branch"];
    $department = "";
    $access = "";
        
        $sel = "SELECT * FROM positions WHERE PositionName = '$position'";
        $result9 = $conn->query($sel);
        if($result9 = mysqli_query($conn, $sel)){
            if(mysqli_num_rows($result9) > 0 ){
              while($row9 = mysqli_fetch_array($result9)){
                $department = $row9['Department'];
                $access = $row9['Access_level'];
              }
            }
          }

	   // Prepare an insert statement
    $sql = 'INSERT INTO user (First_Name, Middle_Name, Last_Name, Suffix, Birthdate, Gender, Contact, Email, Address, Position, Username, Password, Employed_Date, Status, Access_level, Branch, Department, Creation_Date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
     
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, 'ssssssssssssssssss', $param_fname, $param_mname, $param_lname, $param_suffix, $param_birthdate, $param_gender, $param_contact, $param_email, $param_address, $param_position, $param_username, $param_password, $param_join_date, $param_status, $param_access, $param_branch, $param_dep, $param_date);
        
        // Set parameters
        $param_fname = $fname;
        $param_mname = $mname;
        $param_lname = $lname;
        $param_suffix = $suffix;
        $param_birthdate = $birthdate;
        $param_gender = $gender;
        $param_contact = $contact;
        $param_email = $email;
        $param_address = $address;
        $param_position = $position;
        $param_username = $username;
        $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
        $param_join_date = $join_date;
        $param_status = $stat;
        $param_access = $access;
        $param_branch = $branch;
        $param_dep = $department;
        $param_date = $currentdatetime;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $lastInsertedId = $conn->insert_id;
                $mon = trim($_POST["mon"]);
                $tue = trim($_POST["tue"]);
                $wed = trim($_POST["wed"]);
                $thu = trim($_POST["thu"]);
                $fri = trim($_POST["fri"]);
                $sat = trim($_POST["sat"]);
                $sun = trim($_POST["sun"]);

                

                $sql2 = "INSERT INTO work_schedule (`UserID`, `Monday`, `Tuesday`, `Wednesday`, `Thursday`, `Friday`, `Saturday`, `Sunday`) VALUES ('$lastInsertedId', '$mon', '$tue', '$wed', '$thu', '$fri', '$sat', '$sun')";
                $conn->query($sql2);
                $_SESSION['success'] = 1;
                header("location: ../Manager/List.php");
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
    
            // Close statement
            mysqli_stmt_close($stmt);
        }
    
    
    // Close connection
    mysqli_close($conn);
        } elseif (isset($_POST['evaluation'])) {

            // Assign and Call the form names
        
            $id = $_POST["userid"];
            $evalid = $_POST["evaluatorid"];
            $comment = $_POST["comment"];
            $a1 = $_POST["a1"];
            $a2 = $_POST["a2"];
            $a3 = $_POST["a3"];
            $a4 = $_POST["a4"];
            $a5 = $_POST["a5"];
            $a6 = $_POST["a6"];
            $r1 = $_POST["r1"];
            $r2 = $_POST["r2"];
            $r3 = $_POST["r3"];
            $r4 = $_POST["r4"];
            $c1 = $_POST["c1"];
            $c2 = $_POST["c2"];
            $c3 = $_POST["c3"];
            $c4 = $_POST["c4"];
            $c5 = $_POST["c5"];
            $rate = $_POST["total"];
        
               // Prepare an insert statement
               $sql = 'INSERT INTO evaluation (UserID, Attitude1, Attitude2, Attitude3, Attitude4, Attitude5, Attitude6, Responsibility1, Responsibility2, Responsibility3, Responsibility4, Competency1, Competency2, Competency3, Competency4, Competency5, Comment, EvaluatorID, Rating, Date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
             
            if($stmt = mysqli_prepare($conn, $sql)){
                // Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, 'iiiiiiiiiiiiiiiisids', $param_userid, $param_a1, $param_a2, $param_a3, $param_a4, $param_a5, $param_a6, $param_r1, $param_r2, $param_r3, $param_r4, $param_c1, $param_c2, $param_c3, $param_c4, $param_c5, $param_comment, $param_evalid, $param_rate, $param_date);
                
                // Set parameters
                $param_userid = $id;
                $param_a1 = $a1;
                $param_a2 = $a2;
                $param_a3 = $a3;
                $param_a4 = $a4;
                $param_a5 = $a5;
                $param_a6 = $a6;
                $param_r1 = $r1;
                $param_r2 = $r2;
                $param_r3 = $r3;
                $param_r4 = $r4;
                $param_c1 = $c1;
                $param_c2 = $c2;
                $param_c3 = $c3;
                $param_c4 = $c4;
                $param_c5 = $c5;
                $param_comment = $comment;
                $param_evalid = $evalid;
                $param_rate = $rate;
                $param_date = $currentdatetime;
        
                // Attempt to execute the prepared statement
                if(mysqli_stmt_execute($stmt)){
                    $lastInsertedId = $conn->insert_id;
                    $_SESSION['success'] = 1;
                    if ($_SESSION["access"] = 3){
                        
                    header('Location: ../Manager/PerformanceEvaluation.php');
                    } else {
                        header('Location: ../admin/EmployeeList.php');
                    }
                    
                } else{
                    echo "Oops! Something went wrong. Please try again later.";
                }
        
                // Close statement
                mysqli_stmt_close($stmt);
            }
        
        
        // Close connection
        mysqli_close($conn);
    } elseif (isset($_POST['payslip'])) {

        // Assign and Call the form names
    $userid = $_POST["userid"];
    $basic = $_POST["basic"];
    $personal =  $_POST["personal"];
    $team = $_POST["team"];
    $late = $_POST["late"];
    $sss = $_POST["sss"]; 
    $phil = $_POST["ph"];
    $pagibig = $_POST["pagibig"];
    $others = $_POST["others"];
    $cash = $_POST["cash"];
    $deduction = $_POST["totalD"];
    $bonus = $_POST["bonus"];
    $total = $_POST["total"];
    $from = $_POST["from"];
    $to = $_POST["to"];
    $days = $_POST["days"];

	   // Prepare an insert statement
    $sql = 'INSERT INTO payroll (`UserID`, `Basic_salary`, `Personal_Quota`, `Team_Quota`, `Late_Absences`, `SSS`, `PhilHealth`, `Pag_Ibig`, `Others`, `Cash_Advance`, `Total_Deduction`, `Bonus`, `Total`, `Date_From`, `Date_To`, `Days`, `Date_submitted`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, 'iddddddddddddssis', $param_userid, $param_basic, $param_personal, $param_team, $param_late, $param_sss, $param_phil, $param_pagibig, $param_others, $param_cash, $param_deduction, $param_bonus, $param_total, $param_from, $param_to, $param_days, $param_date);
        
        // Set parameters
        $param_userid = $userid;
        $param_basic = $basic;
        $param_personal = $personal;
        $param_team = $team;
        $param_late = $late;
        $param_sss = $sss;
        $param_phil = $phil;
        $param_pagibig = $pagibig;
        $param_others =  $others;
        $param_cash = $cash;
        $param_deduction = $deduction;
        $param_bonus = $bonus;
        $param_total = $total;
        $param_from = $from;
        $param_to = $to;
        $param_days = $days;
        $param_date = $currentdatetime;
        
    
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                
                 $lastInsertedId = $conn->insert_id;
                // Redirect to login page
                header('Location: ../Manager/Salary.php');
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
    
            // Close statement
            mysqli_stmt_close($stmt);
        }
    
    
    // Close connection
    mysqli_close($conn);
        }  elseif (isset($_POST['addwfh'])) {

            // Assign and Call the form names
            $userid = $_POST["userid"];
        
               // Prepare an insert statement
            $sql = 'INSERT INTO work_offsite (UserID) VALUES (?)';
             
            if($stmt = mysqli_prepare($conn, $sql)){
                // Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, 'i', $param_userid);
                
                // Set parameters
                
                $param_userid = $userid;
                
                // Attempt to execute the prepared statement
                if (mysqli_stmt_execute($stmt)){
                    
                    $_SESSION['success'] = 1;

                    header("location: ../Manager/WFH.php");
                    
                } else{
                    echo "Oops! Something went wrong. Please try again later.";
                }
        
                // Close statement
                mysqli_stmt_close($stmt);
        
            }
            // Close connection
            mysqli_close($conn);
         } elseif (isset($_POST['removewfh'])) {

            // Assign and Call the form names
        
            $usernum = trim($_POST["userid"]);
        
               // Prepare an insert statement
            $sql = "DELETE FROM work_offsite WHERE UserID = ?";
             
            if($stmt = mysqli_prepare($conn, $sql)){
                // Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, 'i', $param_usernum);
                
                // Set parameters
                $param_usernum = $usernum;
        
                // Attempt to execute the prepared statement
                if(mysqli_stmt_execute($stmt)){
                    $_SESSION['success'] = 1;
                    header("location: ../Manager/WFH.php");
                    
                } else{
                    echo "Oops! Something went wrong. Please try again later.";
                }
        
                // Close statement
                mysqli_stmt_close($stmt);
            }
        
        
        // Close connection
        mysqli_close($conn);
    }  elseif (isset($_POST['personal'])) {

        // Assign and Call the form names
       
        $usernum = trim($_POST["userid"]);
        $address = $_POST["address"];
        $email = trim($_POST["email"]);
        $contact = trim($_POST["contact"]);
    
           // Prepare an insert statement
        $sql = "UPDATE user SET Contact= ?, Email= ?, Address= ? WHERE UserID = ?";
         
        if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, 'sssi', $param_contact, $param_email, $param_address, $param_usernum);
            
            // Set parameters
            $param_contact = $contact;
            $param_email = $email;
            $param_address = $address;
            $param_usernum = $usernum;
    
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $_SESSION['success'] = 1;
                    if ($_SESSION["access"] == 1){
                        header("location: ../Employee/ProfilePage.php");}
                    elseif ($_SESSION["access"] == 2) {
                            header("location: ../admin/AdminProfile.php");
                        }
                    else {
                        header("location: ../Manager/ManagerProfile.php");
                    }
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
    
            // Close statement
            mysqli_stmt_close($stmt);
        }
    
    
    // Close connection
    mysqli_close($conn);
        }  elseif (isset($_POST['addpersonal'])) {

            // Assign and Call the form names
           
            $usernum = trim($_POST["userid"]);
            $sss = $_POST["sss"];
            $philhealth = trim($_POST["philhealth"]);
            $pagibig = trim($_POST["pagibig"]);
            $bankname = trim($_POST["bankname"]);
            $bankacc = trim($_POST["bankacc"]);
        
               // Prepare an insert statement
            $sql = "UPDATE user SET SSS= ?, Philhealth= ?, Pag_Ibig= ?, Bank_Name= ?, Bank_Account= ? WHERE UserID = ?";
             
            if($stmt = mysqli_prepare($conn, $sql)){
                // Bind variables to the prepared statement as parameters
                mysqli_stmt_bind_param($stmt, 'sssssi', $param_sss, $param_philhealth, $param_pagibig, $param_bankname, $param_bankacc, $param_usernum);
                
                // Set parameters
                $param_sss = $sss;
                $param_philhealth = $philhealth;
                $param_pagibig = $pagibig;
                $param_bankname = $bankname;
                $param_bankacc = $bankacc;
                $param_usernum = $usernum;
        
                // Attempt to execute the prepared statement
                if(mysqli_stmt_execute($stmt)){
                    // Redirect to login page
                        if ($_SESSION["access"] == 1){
                            header("location: ../Employee/ProfilePage.php");}
                        elseif ($_SESSION["access"] == 2) {
                                header("location: ../admin/AdminProfile.php");
                            }
                        else {
                            header("location: ../Manager/ManagerProfile.php");
                        }
                    
                } else{
                    echo "Oops! Something went wrong. Please try again later.";
                }
        
                // Close statement
                mysqli_stmt_close($stmt);
            }
        
        // Close connection
        mysqli_close($conn);
            }  elseif (isset($_POST['profilepic'])) {

                // Assign and Call the form names
               
                if (isset($_FILES['pp']['name']) AND !empty($_FILES['pp']['name'])) {
         
                    
                    $usernum = trim($_POST["userid"]);
                    $img_name = $_FILES['pp']['name'];
                    $tmp_name = $_FILES['pp']['tmp_name'];
                    $error = $_FILES['pp']['error'];
                    
                    if($error === 0){
                       $img_ex = pathinfo($img_name, PATHINFO_EXTENSION);
                       $img_ex_to_lc = strtolower($img_ex);
           
                       $allowed_exs = array('jpg', 'jpeg', 'png');
                       if(in_array($img_ex_to_lc, $allowed_exs)){
                          $new_img_name = uniqid($usernum, true).'.'.$img_ex_to_lc;
                          $img_upload_path = '../Images/upload/'.$new_img_name;
                          move_uploaded_file($tmp_name, $img_upload_path);
           
                          // Insert into Database
                          $sql = "UPDATE user SET ProfilePicture = ? WHERE UserID = ?";
                          $stmt = $conn->prepare($sql);
                          $stmt->execute([$new_img_name, $usernum]);
                          $_SESSION['success'] = 1;
           
                                if ($_SESSION["access"] == 1){
                                    header("location: ../Employee/ProfilePage.php");}
                                elseif ($_SESSION["access"] == 2) {
                                        header("location: ../admin/AdminProfile.php");
                                    }
                                else {
                                    header("location: ../Manager/ManagerProfile.php");
                                }
                           exit;
                       }else {
                        if ($_SESSION["access"] == 1){
                            header("location: ../Employee/ProfilePage.php");}
                        elseif ($_SESSION["access"] == 2) {
                                header("location: ../admin/AdminProfile.php");
                            }
                        else {
                            header("location: ../Manager/ManagerProfile.php");
                        }
                          exit;
                       }
                    }else {
                        if ($_SESSION["access"] == 1){
                            header("location: ../Employee/ProfilePage.php");}
                        elseif ($_SESSION["access"] == 2) {
                                header("location: ../admin/AdminProfile.php");
                            }
                        else {
                            header("location: ../Manager/ManagerProfile.php");
                        }
                       exit;
                    }
           
            
                    // Close statement
                    mysqli_stmt_close($stmt);
                }
            
            // Close connection
            mysqli_close($conn);
                } elseif (isset($_POST['deductions'])) {

                
                    // Assign and Call the form names
                $userid = $_POST["userid"];
                $sss = $_POST["sss"]; 
                $phil = $_POST["ph"];
                $pagibig = $_POST["pagibig"];
                $cash = $_POST["cash"];
                $others = $_POST["others"];

                $result = $conn->query("SELECT * FROM `deductions` WHERE UserID = $userid");
                if($result->num_rows == 0) {
                    $sql2 = "INSERT INTO deductions (UserID, SSS, PhilHealth, Pag_Ibig, Cash_Advance, Others) VALUES ('$userid', '$sss', '$phil', '$pagibig', '$cash', '$others')";

                    } else {
                        $sql2 = "UPDATE deductions SET SSS = '$sss', PhilHealth = '$phil', Pag_Ibig = '$pagibig', Cash_Advance = '$cash', Others = '$others' WHERE UserID = '$userid'";
                    }
                            
                    $conn->query($sql2);        
                    header('Location: ../Others/Payslip.php?id='.base64_encode($userid));
                
                
                // Close connection
                mysqli_close($conn);
                    }  elseif (isset($_POST['basic_salary'])) {

                
                        // Assign and Call the form names
                    $userid = $_POST["userid"];
                    $salary = $_POST["salary"]; 
    
                    $result = $conn->query("SELECT * FROM `employee_salary` WHERE UserID = $userid");
                    if($result->num_rows == 0) {
                        $sql = 'INSERT INTO employee_salary (UserID, Salary) VALUES (?, ?)';
                        } else {
                            $sql = 'UPDATE employee_salary SET UserID = ?, Salary = ?';
                        }
                        if($stmt = mysqli_prepare($conn, $sql)){
                       // Prepare an insert statement
                    
                        // Bind variables to the prepared statement as parameters
                        mysqli_stmt_bind_param($stmt, 'ii', $param_userid, $param_salary);
                        
                        // Set parameters
                        $param_userid = $userid;
                        $param_salary = $salary;
                        
                    
                            // Attempt to execute the prepared statement
                            if(mysqli_stmt_execute($stmt)){
                                
                                header('Location: ../Others/Payslip.php?id='.base64_encode($userid));
                                
                            } else{
                                echo "Oops! Something went wrong. Please try again later.";
                            }
                    
                            // Close statement
                            mysqli_stmt_close($stmt);
                        }
                    
                    
                    // Close connection
                    mysqli_close($conn);
                        }   elseif (isset($_POST['sales'])) {

                            // Assign and Call the form names
                            $userid = $_POST["userid"];
                            $gain = $_POST["salesnumber"];
                        
                               // Prepare an insert statement
                            $sql = 'INSERT INTO sales (UserID, Sales_Gain, Date) VALUES (?, ?, ?)';
                             
                            if($stmt = mysqli_prepare($conn, $sql)){
                                // Bind variables to the prepared statement as parameters
                                mysqli_stmt_bind_param($stmt, 'iis', $param_userid, $param_gain, $param_date);
                                
                                // Set parameters
                                
                                $param_userid = $userid;
                                $param_gain = $gain;
                                $param_date = $currentdatetime;
                                
                                // Attempt to execute the prepared statement
                                if (mysqli_stmt_execute($stmt)){
                                    $_SESSION['success'] = 1;
                                    header("location: ../Manager/Sales.php");
                                    
                                } else{
                                    echo "Oops! Something went wrong. Please try again later.";
                                }
                        
                                // Close statement
                                mysqli_stmt_close($stmt);
                        
                            }
                            // Close connection
                            mysqli_close($conn);
                         }  elseif (isset($_POST['removesale'])) {

                            // Assign and Call the form names
                        
                            $saleid = trim($_POST["saleid"]);
                        
                               // Prepare an insert statement
                            $sql = "DELETE FROM sales WHERE Sales_ID = ?";
                             
                            if($stmt = mysqli_prepare($conn, $sql)){
                                // Bind variables to the prepared statement as parameters
                                mysqli_stmt_bind_param($stmt, 'i', $param_saleid);
                                
                                // Set parameters
                                $param_saleid = $saleid;
                        
                                // Attempt to execute the prepared statement
                                if(mysqli_stmt_execute($stmt)){
                                    $_SESSION['success'] = 1;
                                    header("location: ../Manager/Sales.php");
                                    
                                } else{
                                    echo "Oops! Something went wrong. Please try again later.";
                                }
                        
                                // Close statement
                                mysqli_stmt_close($stmt);
                            }
                        
                        
                        // Close connection
                        mysqli_close($conn);
                    }   elseif (isset($_POST['sales'])) {

                            // Assign and Call the form names
                            $userid = $_POST["userid"];
                            $gain = $_POST["salesnumber"];
                        
                               // Prepare an insert statement
                            $sql = 'INSERT INTO sales (UserID, Sales_Gain) VALUES (?, ?)';
                             
                            if($stmt = mysqli_prepare($conn, $sql)){
                                // Bind variables to the prepared statement as parameters
                                mysqli_stmt_bind_param($stmt, 'ii', $param_userid, $param_gain);
                                
                                // Set parameters
                                
                                $param_userid = $userid;
                                $param_gain = $gain;
                                
                                // Attempt to execute the prepared statement
                                if (mysqli_stmt_execute($stmt)){
                                    $_SESSION['success'] = 1;
                                    header("location: ../Manager/Sales.php");
                                    
                                } else{
                                    echo "Oops! Something went wrong. Please try again later.";
                                }
                        
                                // Close statement
                                mysqli_stmt_close($stmt);
                        
                            }
                            // Close connection
                            mysqli_close($conn);
                         }  elseif (isset($_POST['removesale'])) {

                            // Assign and Call the form names
                        
                            $saleid = trim($_POST["saleid"]);
                        
                               // Prepare an insert statement
                            $sql = "DELETE FROM sales WHERE Sales_ID = ?";
                             
                            if($stmt = mysqli_prepare($conn, $sql)){
                                // Bind variables to the prepared statement as parameters
                                mysqli_stmt_bind_param($stmt, 'i', $param_saleid);
                                
                                // Set parameters
                                $param_saleid = $saleid;
                        
                                // Attempt to execute the prepared statement
                                if(mysqli_stmt_execute($stmt)){
                                    $_SESSION['success'] = 1;
                                    header("location: ../Manager/Sales.php");
                                    
                                } else{
                                    echo "Oops! Something went wrong. Please try again later.";
                                }
                        
                                // Close statement
                                mysqli_stmt_close($stmt);
                            }
                        
                        
                        // Close connection
                        mysqli_close($conn);
                    }  elseif (isset($_POST['markabsents'])) {

                        // Assign and Call the form names
                    
                        $today = date('l');
                    
                           // Prepare an insert statement
                        $sql = "INSERT INTO `emp_absent` (UserID) SELECT u.UserID FROM `user` u INNER JOIN work_schedule w ON w.UserID = u.UserID WHERE u.UserID NOT IN (SELECT emp_num FROM emp_attendance WHERE curr_date = CURDATE()) AND Access_level < 3 AND w.$today = 1 AND u.UserID NOT IN (SELECT UserID FROM emp_absent WHERE DATE_FORMAT(Date, '%Y-%d-%m') != CURDATE())";

                        if($stmt = mysqli_prepare($conn, $sql)){
                            
                            
                            if(mysqli_stmt_execute($stmt)){
                                header("location: ../Manager/ManagerAttendancePage.php");
                                
                            } else{
                                echo "Oops! Something went wrong. Please try again later.";
                            }
                    
                            // Close statement
                            mysqli_stmt_close($stmt);
                        }
                    
                    
                    // Close connection
                    mysqli_close($conn);
                }   elseif (isset($_POST['userpass'])) {

                    // Assign and Call the form names
                    
                    $userid = $_POST["userid"];
                    $password = trim($_POST["password"]);

                       // Prepare an insert statement
                    $sql = "UPDATE user SET Password = ? WHERE UserID = ? ";
                    
                    if($stmt = mysqli_prepare($conn, $sql)){
                        mysqli_stmt_bind_param($stmt, 'si', $param_password, $param_userid);
                        

                        $param_userid = $userid;
                        $param_password = password_hash($password, PASSWORD_DEFAULT);

                        
                        if(mysqli_stmt_execute($stmt)){
                            $_SESSION['success'] = 1;
                            $_SESSION['password'] = $password; 
                            if ($_SESSION["access"] == 1){
                                header("location: ../Employee/ProfilePage.php");}
                            elseif ($_SESSION["access"] == 2) {
                                    header("location: ../admin/AdminProfile.php");
                                }
                            else {
                                header("location: ../Manager/ManagerProfile.php");
                            }
                            
                        } else{
                            echo "Oops! Something went wrong. Please try again later.";
                        }
                
                        // Close statement
                        mysqli_stmt_close($stmt);
                    }
                
                
                // Close connection
                mysqli_close($conn);
            }  elseif (isset($_POST['removeabsent'])) {

                // Assign and Call the form names
                $absentID = $_POST['absentID'];
            
                   // Prepare an insert statement
                $sql = "DELETE FROM `emp_absent` WHERE ID = ?";

                if($stmt = mysqli_prepare($conn, $sql)){
                    mysqli_stmt_bind_param($stmt, 'i', $param_id);
                        
                    $param_id = $absentID;
                    
                    if(mysqli_stmt_execute($stmt)){
                        $_SESSION['success'] = 1;
                        header("location: ../Manager/ManagerAttendancePage.php");
                        
                    } else{
                        echo "Oops! Something went wrong. Please try again later.";
                    }
            
                    // Close statement
                    mysqli_stmt_close($stmt);
                }
            
            
            // Close connection
            mysqli_close($conn);
        }   elseif (isset($_POST['passres'])) {

            // Assign and Call the form names
            $userid = $_POST["userid"];
            $password = "123";
        
               // Prepare an insert statement
            $sql = "UPDATE user SET Password = ? WHERE UserID = ?";

            if($stmt = mysqli_prepare($conn, $sql)){
                mysqli_stmt_bind_param($stmt, 'si', $param_password, $param_id);
                    
                $param_id = $userid;
                $param_password = password_hash($password, PASSWORD_DEFAULT);
                
                
                if(mysqli_stmt_execute($stmt)){
                    $_SESSION['success'] = 1;
                    header("location: ../Manager/List.php");
                } else{
                    echo "Oops! Something went wrong. Please try again later.";
                }
        
                // Close statement
                mysqli_stmt_close($stmt);
            }
        
        
        // Close connection
        mysqli_close($conn);
    }
?>
