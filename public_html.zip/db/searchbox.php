<?php 
	session_start();
	
    require_once "../db/DBConn.php";

    $searchTerm = $_GET['term']; 
 
// Fetch matched data from the database 
$query = $conn->query("SELECT * FROM user WHERE Last_Name LIKE '%".$searchTerm."%' ORDER BY name ASC"); 
 
// Generate array with skills data 
$skillData = array(); 
if($query->num_rows > 0){ 
    while($row = $query->fetch_assoc()){ 
        $data['UserID'] = $row['UserID']; 
        $data['value'] = $row['Last_Name']; 
        array_push($skillData, $data); 
    } 
} 
 
// Return results as json encoded array 
echo json_encode($skillData); 
?>