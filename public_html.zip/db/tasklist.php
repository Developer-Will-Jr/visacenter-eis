<?php 
	session_start();
	
    require_once "../db/DBConn.php";

	// initialize variables
	$department = $subject = $details = $deadline = $postdate = $priority = $posted_by = $status = "";
    date_default_timezone_set('Asia/Kolkata');
    
    if (isset($_POST['create'])) {

    // Assign and Call the form names
    $subject = $_POST["subject"];
    $department = $_POST["department"];
    $priority = $_POST["priority"];
    $deadline = $_POST["deadline"];
    $details = $_POST["details"];
    $userid = $_SESSION["id"];

	   // Prepare an insert statement
    $sql = 'INSERT INTO tasklist (Department, Subject, Details, Priority_level, Status, Post_Date, Deadline, Branch, Posted_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)';
     
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, 'sssssssss', $param_department, $param_subject, $param_details, $param_priority, $param_status, $param_postdate, $param_deadline, $param_branch, $param_postedby);
        
        // Set parameters
        
        $param_department = $department;
        $param_subject = $subject;
        $param_details = $details;
        $param_priority = $priority;
        $param_status = "Pending";
        $param_postdate = date('d-m-y h:i:s');
        $param_deadline = $deadline;
        $param_branch = "Nueva Ecija";
        $param_postedby = $userid;
        
        // Attempt to execute the prepared statement
        if (mysqli_stmt_execute($stmt)){
            // Redirect to login page
            header("location: ../admin/AdminTaskPage.php?s=1");
            
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }

        // Close statement
        mysqli_stmt_close($stmt);

    }
    // Close connection
    mysqli_close($conn);
 }