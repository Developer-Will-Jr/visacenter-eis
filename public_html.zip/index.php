<?php
// Initialize the session
session_start();
// Check if the user is already logged in, if yes then redirect him to login page
if(isset($_SESSION["access"]) && $_SESSION["access"] === 1){
    header("location: Employee/Dashboard.php");
    exit;
} elseif (isset($_SESSION["access"]) && $_SESSION["access"] === 2){
    header("location: Admin/AdminDashboard.php");
    exit;
} elseif (isset($_SESSION["access"]) && $_SESSION["access"] === 3){
    header("location: Manager/Dashboard.php");
    exit;
} elseif (isset($_SESSION["SystemAdmin"]) && $_SESSION["SystemAdmin"] === true){
  header("location: SystemAdmin/Home.php");
  exit;
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>

    <!-- Stylesheets -->
    <link rel="stylesheet" href="Styles/style.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet"/>
    <!-- MDB -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.0.0/mdb.min.css" rel="stylesheet"/>

<style>


    .gradient-custom-2 {
/* fallback for old browsers */

background: 
    linear-gradient(
      rgba(0, 0, 0, 0.6),
      rgba(0, 0, 0, 0.6)
    ),
    url(Images/loginpic.webp);
}

.whitefont h4, p{
  color: #fff;
}

@media (min-width: 768px) {
.gradient-form {
height: 100vh !important;
}
}
@media (min-width: 769px) {
.gradient-custom-2 {
border-top-right-radius: .3rem;
border-bottom-right-radius: .3rem;
}
}
</style>

</head>
<body>

<section class="h-100 gradient-form" style="background-color: #eee;">
        <div class="container py-5 h-100">
          <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-xl-10">
              <div class="card rounded-3 text-black">
                <div class="row g-0">
                  <div class="col-lg-6">
                    <div class="card-body p-md-5 mx-md-4">
      
                      <div class="text-center">
                        <img src="Images/logo.webp"
                          style="width: 80px;" alt="logo">
                          <div style="cursor: default">
                        <h4 class="mt-1 pb-1">The Visa Center</h4>
                        <h6 class="mt-1 pb-1 fw-normal fst-italic">Towards Brighter Future!</h6>
                      <form action="db/dbLogin.php" method="post"> 
                        <div class="text-center">
                        <h6 style="color: #000"><u>Login Your EIS Account</u></h6>
                        <br>
                        </div>
                        </div>
                        <?php
                        if (isset($_SESSION["login_error_msg"])){ ?>
                        <span style="color: red;"><?php echo $_SESSION['login_error_msg'] ?></span>
                        <?php } ?>
                        </div>
                        <div class="form-outline mb-4">
                          <input type="text" id="inputUsername" name="username" class="form-control" placeholder="Username" value="<?php if (isset($_SESSION["user_val"])){ echo $_SESSION["user_val"] ?><?php }?>" required>
                          <label class="form-label" for="form2Example11">Username</label>
                        </div>
      
                        <div class="form-outline mb-3">
                          <input type="password" id="mypass" name="password" class="form-control" placeholder="Password" value="" required>
                          <label class="form-label" for="form2Example22">Password</label>
                        </div>

                        <div class="text-center pt-1 pb-1">
                          <button type="submit" class="btn btn-success btn-block fa-lg buttons mb-3" name="login">Login</button>
                          
                          <input type="hidden" name="ipaddress" id="ipaddress">
                          
                      </form>
                      <div class="form-check mt-3">
                          <input type="checkbox" class="form-check-input" onclick="showPassword()">
                          <label class="form-label" for="exampleCheck1">Show Password</label>
                          </div>
                      <button type="button" class="btn btn-primary" data-mdb-toggle="modal" data-mdb-target="#exampleModal">Forgot Password?</button>
                      <br>
                      </div>
                      
                    </div>
                  </div>
                  <div class="col-lg-6 d-flex align-items-center gradient-custom-2">
                    <div class="whitefont px-3 py-4 p-md-5 mx-md-4">
                      <h4 class="mb-4">A KEY TO SUCCESSFUL IMMIGRATION</h4>
                      <p class="mb-0 text-wrap">The Visa Center is a team of relocation professionals with an in-depth knowledge of the immigration industry; a team that has successfully disposed of resettlement solutions to satisfied clients. At The Visa Center, we have set ourselves apart from other immigration consultants as our code of conduct and ethics are underlined by complete transparency and are strictly adhered to by our result-oriented team.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Forgot Password</h5>
        <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body text-center">Forgot Password? Email us to reset your password
      <div class="row mt-3">

<!--Grid column-->
<div class="col-md-15 mb-md-0 mb-5">
    <form id="contact-form" name="contact-form" action="db/dbLogin.php" method="POST">

        <!--Grid row-->
        <div class="row">

            <!--Grid column-->
            <div class="col-md-12 mb-4">
                <div class="md-form mb-0">
                    <input type="text" id="name" name="empid" class="form-control text-center" required>
                    <label for="name" class="">Your Employee ID Number</label>
                </div>
            </div>
            <!--Grid column-->

            <!--Grid column-->

        </div>
        <div class="row">
          
            <!--Grid column-->
            <div class="col-md-12 mb-4">
                <div class="md-form mb-0">
                    <input type="text" id="email" name="email" class="form-control text-center" required>
                    <label for="email" class="">Your email</label>
                </div>
            </div>
        </div>

        <!--Grid row-->
        <div class="row">
            <div class="col-md-12 mb-4">
                <div class="md-form mb-0">
                    <input type="text" id="subject" name="subject" class="form-control text-center" value="Request For Password Reset" readonly>
                    <label for="subject" class="">Subject</label>
                </div>
            </div>
        </div>
        <!--Grid row-->

        <!--Grid row-->
        <div class="row">

            <!--Grid column-->
            <div class="col-md-12 mb-4">

                <div class="md-form">
                    <textarea type="text" id="message" name="message" rows="2" class="form-control md-textarea text-center" style="resize: none;"></textarea>
                    <label for="message">Your message</label>
                </div>
            </div>
        </div>
        After Sending an email wait for the confirmation reply to access your account again.
        <!--Grid row-->

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Close</button>
        <a type="submit" class="btn btn-primary" name="forgot" href="javascript:void(0)">Send</a>
    </form>
      </div>
    </div>
  </div>
</div>

      <!-- MDB Script -->
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.0.0/mdb.min.js"></script>
      <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script>
        $.ajax({ url:"https://api.ipify.org/?format=json", success: function(data){
          document.getElementById("ipaddress").value=data.ip;
        }
      });

      </script>
      <script>
        
      function showPassword() {
          var x = document.getElementById("mypass");
          if (x.type === "password") {
            x.type = "text";
          } else {
            x.type = "password";
          }
        }
      </script>
</body>
</html>