<?php session_start(); 

                              
?>
<?php 
  include 'connection.php';
   ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <title>Employees Attendance</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">


</head>

<body>

<!--display on realtime table-->
<div id="link_wrapper">
    <div class="container mt-5 border rounded-3 p-4">
        <div class="row">
            <?php

            $connector = new mysqli("localhost", "root", "", "attendance_db")
                or die("Unable to connect");
            //execute the SQL query and return records
         
            ?>
            <!-- ---------------------------------------------------------------------------------------------------------------------------- -->
            <div class="container mt-2 mb-4 table-responsive-xl">

                <table class="table table-striped table-hover table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">EMPLOYEE NUMBER</th>
                            <th scope="col">LAST NAME</th>
                            <th scope="col">FIRST NAME</th>
                            <th scope="col">MIDDLE NAME</th>
                            <th scope="col">DATE</th>
                            <th scope="col">TIME IN</th>
                            <th scope="col">TIME OUT</th>
                            <th scope="col">OVERTIME HOURS</th>
                            <th scope="col">WORKING HOURS</th>
                            <th scope="col">TOTAL HOURS</th>
                            <th scope="col">STATUS</th>
                            <th scope="col">ACTIVITY</th>
                            <th scope="col">OPERATIONS</th>

                        </tr>
                    </thead>
                    <tbody class="table-group-divider">
                        <tr>

                            
                             <?php
                             $id = "2020-001-09";
                            $query = "SELECT id, emp_num, last_name, first_name, middle_name, curr_date
                            , time_in, time_out, overtime_hours, working_hours, total_hours, status, activity FROM emp_attendance WHERE emp_num = '$id' ";
                            $query_result = mysqli_query($connector, $query);
                            


                            while ($row = mysqli_fetch_assoc($query_result)) {
                               

                                echo '
                                <td>'.$row['emp_num'] .'</td>
                                <td>'.$row['last_name'].'</td>
                                <td>'.$row['first_name'].'</td>
                                <td>'.$row['middle_name'].'</td>
                                <td>'.$row['curr_date'].'</td>
                                <td>'.$row['time_in'].'</td>
                                <td>'.$row['time_out'].'</td>
                                <td>'.$row['overtime_hours'].'</td>
                                <td>'.$row['working_hours'].'</td>
                                <td>'.$row['total_hours'].'</td>
                                <td>'.$row['status'].'</td>
                                <td>'.$row['activity'].'</td>
                                <td><button class="btn btn-primary" class="text-light"><a href="update.php?updateid='.$row['id'].'" class="text-light">Update</a></button></td>


                                '

                                
                            ?>


                        </tr>
                    </tbody>
                <?php }
                                mysqli_close($connector); ?>
                </table>
            </div>
        </div>
    </div>
</div>
       
 <div class="container d-flex justify-content-center mt-4">
        <div class="row">
            <div class="col">
                <form action="export.php" method="post">
                    <input type="submit" value="Export" class="btn btn-success">
                </form>
                <!-- <a href="date.php" class="btn btn-primary">Date</a> -->
            </div>
        </div>
    </div>


</body>

</html>

<!--JS function on realtime -->

