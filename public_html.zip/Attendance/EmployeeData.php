    <?php 
  include 'connection.php';
   ?>
                              

<body>
  
    
    <div class="container mt-6 border rounded-3 p-4">
        <div class="row">
            <?php

            $connector = new mysqli("localhost", "root", "", "attendance_db")
                or die("Unable to connect");
            //execute the SQL query and return records
            $sql = "SELECT * FROM emp_attendance";
            $result = mysqli_query($connector, $sql);
            ?>
            <!-- ---------------------------------------------------------------------------------------------------------------------------- -->
            <div class="container mt-8 mb-4 table-responsive-xl">

                <table class="table table-striped table-hover table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">EMPLOYEE NUMBER</th>
                            <th scope="col">LAST NAME</th>
                            <th scope="col">FIRST NAME</th>
                            <th scope="col">MIDDLE NAME</th>
                            <th scope="col">DATE</th>
                            <th scope="col">TIME IN</th>
                            <th scope="col">TIME OUT</th>
                            <th scope="col">OVERTIME HOURS</th>
                            <th scope="col">WORKING HOURS</th>
                            <th scope="col">TOTAL HOURS</th>
                            <th scope="col">STATUS</th>
                            <th scope="col">ACTIVITY</th>
                            <th scope="col">LOCATION</th>
                            <th scope="col">OPERATIONS</th>

                        </tr>
                    </thead>
                    <tbody class="table-group-divider">
                        <tr>
                            <?php

                            
                            
                            $query = "SELECT * FROM employee_records";
                            $query_result = mysqli_query($connector, $query);
                            


                            while ($row = mysqli_fetch_assoc($result)) {
                                $id=$row['id'];
                                $empname = $row['emp_num'];
                                $lastname = $row['last_name'];
                                $firstname = $row['first_name'];
                                $middlename = $row['middle_name'];
                                $currdate =$row['curr_date'];
                                $timein =$row['time_in'];
                                $timeout =$row['time_out'];
                                $othours =$row['overtime_hours'];
                                $whours =$row['working_hours'];
                                $totalhours =$row['total_hours'];
                                $status =$row['status'];
                                $loc =$row['Location'];
                                $active =$row['activity'];

                                echo '
                                <td>'.$empname.'</td>
                                <td>'.$lastname.'</td>
                                <td>'.$firstname.'</td>
                                <td>'.$middlename.'</td>
                                <td>'.$currdate.'</td>
                                <td>'.$timein.'</td>
                                <td>'.$timeout.'</td>
                                <td>'.$othours.'</td>
                                <td>'.$whours.'</td>
                                <td>'.$totalhours.'</td>
                                <td>'.$status.'</td>
                                <td>'.$active.'</td>
                                <td>'.$loc.'</td>
                                <td><button class="btn btn-primary" class="text-light"><a href="update.php?updateid='.$id.'" class="text-light">Update</a></button></td>


                                '

                                
                            ?>

                        </tr>
                    </tbody>
                <?php }
                                mysqli_close($connector); ?>
                </table>
            </div>
        </div>
    </div>

</body>




