<?php
session_start();

$_SESSION['id'] = $_POST['id_num'];
$emp_num = $_SESSION['id'];

// var_dump($emp_num);
// echo($emp_num);
// exit();

date_default_timezone_set('Asia/Taipei');
$conn = new mysqli("localhost", "u456912403_visacenter", "Icongroup2023", "u456912403_eis");

//Check if connection is successful
if ($conn->connect_error) {
    die("Connection failed: "
        . $conn->connect_error);
}
if (isset($_POST['id_num'])) {
        $loc =$_POST['location'];
        }

    if (empty($_POST['id_num'])) {
        echo '<script type="text/javascript">';
        echo 'alert("Please input valid employee number");';
        echo 'window.location.href = "index.php";';
        echo '</script>';
    

    } else {
        $time_now = date("g:i:s A");
        $date_now = date("Y-m-d");

        $sql = "SELECT * FROM user WHERE UserID = '$emp_num'";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                $query = "SELECT * FROM user WHERE UserID = '$emp_num'";
                $query_result = mysqli_query($conn, $query);
                while ($row = mysqli_fetch_assoc($result)) {
                    $last_name = $row['Last_Name'];
                    $first_name = $row['First_Name'];
                    $middle_name = $row['Middle_Name'];
                }

                $test_query = "SELECT * FROM emp_attendance WHERE emp_num = '$emp_num' AND curr_date = '$date_now'";
                $test_query_result = mysqli_query($conn, $test_query);
                if (mysqli_num_rows($test_query_result) == 0) {
                    $query_1 = "INSERT INTO emp_attendance (emp_num, last_name, first_name, middle_name, curr_date) VALUES ('$emp_num', '$last_name', '$first_name', '$middle_name', '$date_now')";
                    $query_1_result = mysqli_query($conn, $query_1);
                } elseif (mysqli_num_rows($test_query_result) > 1) {
                    $query_5 = "UPDATE emp_attendance SET curr_date = '$date_now' WHERE emp_num = '$emp_num'";
                    $query_5_result = mysqli_query($conn, $query_5);
                }

                $end_query = "SELECT * FROM emp_attendance WHERE '$emp_num' AND curr_date = '$date_now'";
                $end_query_result = mysqli_query($conn, $end_query);

                while ($end_row = mysqli_fetch_assoc($end_query_result)) {
                    if (empty($end_row['time_out'])) {
                        $dupe_query = "SELECT * FROM emp_attendance WHERE emp_num = '$emp_num' AND curr_date = '$date_now'";
                        $dupe_result = mysqli_query($conn, $dupe_query);
                        while ($dupe_row = mysqli_fetch_assoc($dupe_result)) {

                            if (empty($dupe_row['time_in'])) {
                                $query_in = "UPDATE emp_attendance SET time_in = '$time_now' WHERE emp_num = '$emp_num' AND curr_date = '$date_now'";
                                $query_in_result = mysqli_query($conn, $query_in);  

                                $in = new DateTime($time_row['time_in']);
                                $timestart = new DateTime('09:00:59');
                                $minlate = $timestart->diff($in);

                                if ($in <= $timestart){
                                    $stat =  'On-time';
                                    $minutes_of_late = '00:00:00';

                                }

                                elseif ($in > $timestart){
                                    $stat = 'Late';
                                    $minutes_of_late =  $minlate->format("%H:%i:%S");

                                }

                                $query_status = "UPDATE emp_attendance SET status = '$stat', minutes_of_late = '$minutes_of_late', Location = '$loc' WHERE emp_num = '$emp_num' AND curr_date = '$date_now'";   
                                $query_status_result = mysqli_query($conn, $query_status);  
                                
                                if ($_SESSION["access"] == 1){
                                    header("location: ../Employee/Dashboard.php");
                                    
                                } else {
                                    
                                header("location: ../admin/AdminDashboard.php");
                                    
                                }
                                
                                
                                exit();

                            } elseif (!empty($dupe_row['time_in'])) {
                                $query_out = "UPDATE emp_attendance SET time_out = '$time_now' WHERE emp_num = '$emp_num' AND curr_date = '$date_now'";
                                $query_out_result = mysqli_query($conn, $query_out);

                                $time_sql = "SELECT * FROM emp_attendance WHERE emp_num = '$emp_num'";
                                $time_query = mysqli_query($conn, $time_sql);
                                while ($time_row = mysqli_fetch_assoc($time_query)) {
                                    $a = new DateTime($time_row['time_in']);
                                    $b = new DateTime($time_row['time_out']);
                                    
                                }

                                $interval = $a->diff($b); 
                                $working_hours_a =  $interval->format("%H:%i:%S");
                                $total_hours_a =  $interval->format("%H:%i:%S");

                                $time_end = new DateTime('6:00 pm');

                                if ($working_hours_a >=4){

                                $working_hours_b = date('H:i:s', strtotime($working_hours_a. ' -1 hours'));
                               
                                } else{
                                    $working_hours_b = $working_hours_a;
                                }


                                $interval_b = $time_end->diff($b);
                                $interval_c = $b->diff($b);

                                if($b <= $time_end){
                                        $extra_working_hours =  $interval_c->format("%%H:%i:%S");
                                        $ot_hours = date('H:i', strtotime($extra_working_hours));

                                }
                                else{
                                        $extra_working_hours =  $interval_b->format("%H:%i:%S");
                                        $ot_hours = date('H:i', strtotime($extra_working_hours));
                                }


                                if ($total_hours_a >=4) {
                                     $total_hours_b = date('H', strtotime($total_hours_a. '-1 hours'));
                                } else {
                                     $total_hours_b = date('H', strtotime($total_hours_a));
                                } 



                                $query_time = "UPDATE emp_attendance SET working_hours = '$working_hours_b', total_hours = '$total_hours_b',  overtime_hours = '$ot_hours' WHERE emp_num = '$emp_num' AND curr_date = '$date_now'";
                                $query_time_result = mysqli_query($conn, $query_time);  

                                if ($_SESSION["access"] == 1){
                                    header("location: ../Employee/Dashboard.php");
                                    
                                } else {
                                    
                                header("location: ../admin/AdminDashboard.php");
                                    
                                }
                                exit();
                            
                            }
                        }
                    } elseif (!empty($end_row['time_out'])) {
                        echo '<script type="text/javascript">';
                        echo 'alert("You already timed in and out for the day");';
                        echo 'window.location.href = "../";';
                        echo '</script>';
                    }
                }
            } else {
                echo '<script type="text/javascript">';
                echo 'alert("Invalid employee number, Please try again");';
                echo 'window.location.href = "TimeInOut.php";';
                echo '</script>';
            }
        } else {
            echo "Error: Database not Found";
        }
    }

