<?php
// Initialize the session
session_start();

// Include config file
require_once "../db/DBConn.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <script src="https://cdnjs.cloudfare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <title>My Attendance</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">

</head>

<body>

<button onclick="document.location='TimeInOut.php'">Time in/Time out</button>
    
    <div class="container mt-5 border rounded-3 p-4">
        <div class="row">
            <?php

            $userid = $_SESSION["id"]; //query the userID of the user to sort the attendance

            $sql = "SELECT * FROM emp_attendance WHERE emp_num='$userid'";
            $result = mysqli_query($conn, $sql);
            ?>
            <!-- ---------------------------------------------------------------------------------------------------------------------------- -->
            <div class="container mt-2 mb-4 table-responsive-xl">

                <table class="table table-striped table-hover table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">DATE</th>
                            <th scope="col">TIME IN</th>
                            <th scope="col">TIME OUT</th>
                            <th scope="col">OVERTIME HOURS</th>
                            <th scope="col">WORKING HOURS</th>
                            <th scope="col">TOTAL HOURS</th>
                            <th scope="col">STATUS</th>

                        </tr>
                    </thead>
                    <tbody class="table-group-divider">
                        <tr>
                            <?php
                            
                            $query = "SELECT * FROM emp_attendance";
                            $query_result = mysqli_query($conn, $query);
                            
                            while ($row = mysqli_fetch_assoc($query_result)) {
                            ?>
                                <td><?php echo $row['curr_date'] ?></td>
                                <td><?php echo $row['time_in'] ?></td>
                                <td><?php echo $row['time_out'] ?></td>
                                <td><?php echo $row['overtime_hours'] ?></td>
                                <td><?php echo $row['working_hours'] ?></td>
                                <td><?php echo $row['total_hours']. " Hour/s" ?></td>
                                <td><?php echo $row['status'] ?></td>
                        </tr>
                    </tbody>
                <?php }
                                mysqli_close($conn); ?>
                </table>
            </div>
        </div>
    </div>
 <div class="container d-flex justify-content-center mt-4">
        <div class="row">
            <div class="col">
                <form action="export.php" method="post">
                    <input type="submit" value="Export" class="btn btn-success">
                </form>
                <!-- <a href="date.php" class="btn btn-primary">Date</a> -->
            </div>
        </div>
    </div>


</body>

</html>