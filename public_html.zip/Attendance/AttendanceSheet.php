<?php session_start(); 


require_once "../db/DBConn.php";                         
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <title>Employees Attendance</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">


</head>

<body>

<!--display on realtime table-->
<div id="link_wrapper"></div>
       
 <div class="container d-flex justify-content-center mt-4">
        <div class="row">
            <div class="col">
                <form action="export.php" method="post">
                    <input type="submit" value="Export" class="btn btn-success">
                </form>
                <!-- <a href="date.php" class="btn btn-primary">Date</a> -->
            </div>
        </div>
    </div>


</body>

</html>

<!--JS function on realtime -->
<script>
function loadXMLDoc() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("link_wrapper").innerHTML =
      this.responseText;
    }
  };
  xhttp.open("GET", "employeedata.php", true);
  xhttp.send();
}

setInterval(function(){
    loadXMLDoc();
    //1 sec
},1000)

window.onload = loadXMLDoc;
</script>

