<?php session_start(); 


require_once "../db/DBConn.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <title>Time In/Time Out</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">


</head>

<body onload="getLocation()">


<script>

  function getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(showPosition, showError);
    } else { 
      x.innerHTML = "Geolocation is not supported by this browser.";
    }
  }
  function showPosition(position) {

    document.getElementById("latitude").value = position.coords.latitude.toFixed(3);
    document.getElementById("longitude").value = position.coords.longitude.toFixed(3);
  }

  function showError(error) {
    switch(error.code) {
      case error.PERMISSION_DENIED:
        x.innerHTML = "User denied the request for Geolocation."
        break;
      case error.POSITION_UNAVAILABLE:
        x.innerHTML = "Location information is unavailable."
        break;
      case error.TIMEOUT:
        x.innerHTML = "The request to get user location timed out."
        break;
      case error.UNKNOWN_ERROR:
        x.innerHTML = "An unknown error occurred."
        break;
    }
  }
  </script>


    <div class="d-flex justify-content-center">
        <div class="row mt-4">
            <div class="col mt-4">
                <div class="container border border-dark rounded-3 p-5">
                  <?php  
                              $tz = 'Asia/Taipei';
                              $timestamp = time();
                              $time_now = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string
                              $dt = new DateTime("now", new DateTimeZone($tz)); //first argument "must" be a string

                              $time_now->setTimestamp($timestamp); //adjust the object to correct timestamp
                              $dt->setTimestamp($timestamp); //adjust the object to correct timestamp

                              echo $time_now->format('Y-m-d');
                              echo " ";
                              echo $dt->format('H:i:s');
                              ?>
                              
                    <form action="save.php" method="post">
                        <div class="input-group input-group-lg">
                        

                            <input type="hidden" name="id_num" value="<?php echo $_SESSION["id"]; ?>"> <!-- Echo UserID who logged in to value --> 
                            <input type="hidden" id="latitude" name="latitude">
                            <input type="hidden" id="longitude" name="longitude">

                        </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container d-flex justify-content-center mt-4">
        <div class="row">
            <div class="col">

               <!-- button disable and enable, status in table should be 0  or 1 for it to be enable and disabled. PS: Check the database --> 

                    <input type="submit" value="Time in" class="btn btn-success" id="id_num"> 
                    <input type="submit" value="Time out" class="btn btn-success" id="id_num">

                <!-- <a href="date.php" class="btn btn-primary">Date</a> -->

            </div>
        </div>
    </div>
    </form>
<button onclick="document.location='employeeattendance.php'">Back</button>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="script.js"></script>

</html>