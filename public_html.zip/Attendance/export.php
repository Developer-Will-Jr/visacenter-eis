<?php
date_default_timezone_set('Asia/Taipei');
$conn = new mysqli("localhost", "root", "", "Attendance_db");

//Check if connection is successful
if ($conn->connect_error) {
    die("Connection failed: "
        . $conn->connect_error);
}

$date_now = date("Y-m-d");

$filename = "Attendance ". $date_now .".xls"; // File Name
// Download file
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Content-Type: application/vnd.ms-excel");
$query = "SELECT * FROM emp_attendance";
$user_query = mysqli_query($conn, $query);
// Write data to file
$flag = false;
while ($row = mysqli_fetch_assoc($user_query)) {
    if (!$flag) {
        // display field/column names as first row
        echo implode("\t", array_keys($row)) . "\r\n";
        $flag = true;
    }
    echo implode("\t", array_values($row)) . "\r\n";
}