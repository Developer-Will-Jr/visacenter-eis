document.getElementById("id_num").focus();


$(function () {
  var $id = $("#id_num");
  $id.keyup(function (e) {
    if ($id.val().length >= 7) {
      $(this.form).submit();
    }
  });
});