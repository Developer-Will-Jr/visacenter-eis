<?php

$conn = new mysqli("localhost", "root", "", "attendance_db");

//Check if connection is successful
if ($conn->connect_error) {
    die("Connection failed: "
        . $conn->connect_error);
}
        
        $id = $_GET['updateid'];
    if (isset($_POST['submit'])) {
        $timetype =$_POST['timetype'];
        $timein =$_POST['time'];
       

        $updatedtimein = date('h:i:s A', strtotime($timein));

        if ($timetype == 1) {

        $query_update="UPDATE emp_attendance set id=$id, time_in ='$updatedtimein' Where id=$id";
        $query_update_result =  mysqli_query($conn, $query_update);
            
        }
        elseif($timetype == 2) {

        $act = 'Off-duty';
        $query_update="UPDATE emp_attendance set id=$id, time_out ='$updatedtimein', activity = '$act' Where id=$id";
        $query_update_result =  mysqli_query($conn, $query_update);
            
        }

                                $time_sql = "SELECT * FROM emp_attendance WHERE id=$id";
                                $time_query = mysqli_query($conn, $time_sql);
                                while ($time_row = mysqli_fetch_assoc($time_query)) {
                                    $a = new DateTime($time_row['time_in']);
                                    $b = new DateTime($time_row['time_out']);
                                 }

                                $timestart = new DateTime('9:00');

                                // if in is > out, assume out is on the next day
                                if ($a <= $timestart){
                                    $stat =  'On-time';
                                }

                                elseif ($a > $timestart){
                                    $stat = 'Late';
                                }

                                $status_result = $stat;

                                $interval = $a->diff($b); 
                                $working_hours_a =  $interval->format("%H:%i:%S");
                                $total_hours_a =  $interval->format("%H:%i:%S");

                                $time_end = new DateTime('6:00 pm');

                                if ($working_hours_a >=4){

                                $working_hours_b = date('H:i:s', strtotime($working_hours_a. ' -1 hours'));
                               
                                } else{
                                    $working_hours_b = $working_hours_a;
                                }


                                $interval_b = $time_end->diff($b);

                                if($b <= $time_end){
                                        $ot_hours = "00:00:00";

                                }
                                else{
                                        $extra_working_hours =  $interval_b->format("%H:%i:%S");
                                        $ot_hours = date('H:i', strtotime($extra_working_hours));
                                }


                                if ($total_hours_a >=4) {
                                     $total_hours_b = date('H', strtotime($total_hours_a. '-1 hours'));
                                } else {
                                     $total_hours_b = date('H', strtotime($total_hours_a));
                                } 

                                $query_status = "UPDATE emp_attendance SET Status = '$status_result', working_hours = '$working_hours_b', total_hours = '$total_hours_b',  overtime_hours = '$ot_hours' WHERE id=$id";   
                                $query_status_result = mysqli_query($conn, $query_status);


        if ($query_update_result && $query_status_result ) {
            echo '<script type="text/javascript">';
            echo 'alert("UPDATED");';
            echo 'window.location.href = "update.php?updateid='.$id.'";';
            echo '</script>';
        }

        else{
            die(mysqli_error($conn));
        }



    }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <title>Update</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">


</head>

<body>
    <div class="d-flex justify-content-center">
        <div class="row mt-4">
            <div class="col mt-4">
                <div class="container border border-dark rounded-3 p-5">
                    <form method="post">
                        <select name="timetype" required>
                            <option value="">--- Choose a time ---</option>
                            <option value="1">Time in</option>
                            <option value="2">Time out</option>
                        </select>
                        <div class="input-group input-group-lg">
                            <span class="input-group-text">Time:</span>
                            <input type="time" class="form-control" autofocus aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg" name="time" required>
                        </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container d-flex justify-content-center mt-4">
        <div class="row">
            <div class="col">
                    <input type="submit" value="Update" class="btn btn-success" name="submit" >
                <!-- <a href="date.php" class="btn btn-primary">Date</a> -->
            </div>
        </div>
    </div>
    </form>
<button onclick="document.location='attendancesheet.php'">Back</button>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="script.js"></script>

</html>