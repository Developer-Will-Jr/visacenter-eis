<?php

// $conn = new mysqli("localhost", "root", "", "ojt2");

// //Check if connection is successful
// if ($conn->connect_error) {
//     die("Connection failed: "
//         . $conn->connect_error);
// }

// $sql = "SELECT * FROM emp_attendance WHERE emp_num = '17-1255'";
// $query = mysqli_query($conn, $sql);
// while ($row = mysqli_fetch_assoc($query)){
//     // $bday = $row['b_day'];
//     // $newDate = date("m/d/Y", strtotime($bday));
//     $a = new DateTime($row['time_in']);
//     $b = new DateTime($row['time_out']);
// }


// $interval = $a->diff($b);

// echo $interval->format("%H:%M:%S");
// exit();



//date in mm/dd/yyyy format; or it can be in other formats as well
// $birthDate = "12/17/1983";
//explode the date to get month, day and year
// $birthDate = explode("/", $newDate);
// //get age from date or birthdate
// $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[0], $birthDate[1], $birthDate[2]))) > date("md")
//     ? ((date("Y") - $birthDate[2]) - 1)
//     : (date("Y") - $birthDate[2]));
// echo "Age is:" . $age;
